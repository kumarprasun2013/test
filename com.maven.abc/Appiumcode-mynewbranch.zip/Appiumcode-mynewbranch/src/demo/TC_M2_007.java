package demo;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.wellsfargo.test.TestCase.ReportData;
import com.wellsfargo.test.domain.TestCase;
import com.wellsfargo.test.domain.TestSteps;
import com.wellsfargo.test.framework.ITestCase;

import com.wellsfargo.test.framework.Utils;

public class TC_M2_007 extends ReportData implements ITestCase{
	public TestCase run() throws Exception, Throwable {
		
		//Validate More menu options -> Replace My Card link
		TestCase testCase = Utils.createTestCase("TC_M2_007");
		List<TestSteps> testSteps = new ArrayList<TestSteps>();
		Thread.sleep(20000);
		
		//Click on more menu
		WebElement obj=driver.findElement(By.xpath("/html/body/div[2]/button[2]/i"));
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(obj, "menu is clicked", "1"));
			System.out.println("Click on the menu");
		}else{
			testSteps.add(ReportData.clickWebIos(obj, "menu is clicked", "1"));
			System.out.println("Click on  the menu");
		}
		Thread.sleep(20000);
		
		//Click on Other services
			WebElement AccountServices=driver.findElement(By.xpath("//span[.='Account Services']"));
				//WebElement AccountServices=driver.findElement(By.xpath("//h3[.='Other Services']"));
				if(TESTING_DEVICE_TYPE.equals("Android")){
					
					testSteps.add(ReportData.tapOnElement(AccountServices, "Other services is clicked", "1"));
					System.out.println("Other services are clicked");
				}else{
					testSteps.add(ReportData.clickWebIos(AccountServices, "Other services is clicked", "1"));
					System.out.println("Other services are clicked");
				}
				Thread.sleep(20000);
				//Click on Replace card in the section
				
				WebElement Replacecard=driver.findElement(By.xpath("//span[.='Replace My Card']"));
			if(TESTING_DEVICE_TYPE.equals("Android")){
					testSteps.add(ReportData.tapOnElement(Replacecard, "Replace card option is clicked", "2"));
					System.out.println("Replace card is clicked");
				}else{
					testSteps.add(ReportData.clickWebIos(Replacecard, "Replace card option is clicked", "2"));
					System.out.println("Replace card is clicked");
				}
				Thread.sleep(20000);
				//Check whether the  Replace Card is landed
				WebElement Replacecardpage=driver.findElement(By.xpath("//*[@id='main-container']/h1"));
				if(Replacecardpage.isDisplayed()){
					System.out.println("The Replace card page is landed successfully");
				}else{
					System.out.println("Please check the application");	
				}
				Thread.sleep(20000);
		testCase.setTestStepList(testSteps);
		return testCase;
	}
}
package demo;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.wellsfargo.test.TestCase.ReportData;
import com.wellsfargo.test.domain.TestCase;
import com.wellsfargo.test.domain.TestSteps;
import com.wellsfargo.test.framework.ICommonConstants;
import com.wellsfargo.test.framework.ITestCase;
import com.wellsfargo.test.framework.Utils;



public class SignOnIos extends ReportData implements ITestCase {
	
public TestCase run() throws Exception, Throwable {

	TestCase testCase = Utils.createTestCase("SignOn");	
	List<TestSteps> testSteps = new ArrayList<TestSteps>();
		

		String[][] recData = Utils.readXlSheet(ICommonConstants.signOnSheet);

		String UN = recData[1][0];
		// System.out.print(UN);
		String PWD = recData[1][1];
		// Enter username
				WebElement userName = driver.findElement(By.xpath("//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATextField[1]"));
				testSteps.add(ReportData.enterText(userName, UN, "userName", "1"));

				// enter password
				WebElement pwd = driver.findElement(By.xpath("//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIASecureTextField[1]"));
				testSteps.add(ReportData.enterText(pwd, PWD, "password", "2"));

				// Click on signon
				WebElement SignOn = driver.findElement(By.xpath("//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAButton[3]"));
				testSteps.add(ReportData.clickButton(SignOn, "Sign On", "3"));
				testCase.setTestStepList(testSteps);
				return testCase;
	}

}
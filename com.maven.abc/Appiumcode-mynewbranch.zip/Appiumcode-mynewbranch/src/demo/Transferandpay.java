package demo;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.wellsfargo.test.TestCase.ReportData;
import com.wellsfargo.test.domain.TestCase;
import com.wellsfargo.test.domain.TestSteps;
import com.wellsfargo.test.framework.ITestCase;
import com.wellsfargo.test.framework.Utils;

public class Transferandpay extends ReportData implements ITestCase {


	public TestCase run() throws Exception, Throwable {
		TestCase testCase = Utils.createTestCase("Transfer and Pay");	
		List<TestSteps> testSteps = new ArrayList<TestSteps>();
		//Click on the menu
		WebElement menu = driver.findElement(By.xpath("/html/body/div[2]/button[2]/i"));
		System.out.println("More button visible");
		Thread.sleep(5000);
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(menu, "Moremenu", "1"));

		}else{
			testSteps.add(ReportData.clickWebIos(menu, "Moremenu", "1"));
		}

		//Select Transfer and pay
		Thread.sleep(20000);
		WebElement Transferandpay=driver.findElement(By.xpath("//span[.='Transfer & Pay']"));

		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(Transferandpay, " Transfer and pay", "2"));

		}else{
			testSteps.add(ReportData.clickWebIos(Transferandpay, "Transfer and pay", "2"));
		}

		//Select Transfer Money
		Thread.sleep(10000);
		WebElement Transfermoney=driver.findElement(By.xpath("//span[.='Transfer Money']"));
		Thread.sleep(5000);
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(Transfermoney, " Transfer money", "3"));

		}else{
			testSteps.add(ReportData.clickWebIos(Transfermoney, "Transfer money", "3"));
		}

		Thread.sleep(10000);

		//Check whether transfermoney page is displayed
		driver.findElement(By.xpath("//h1[.='Transfer Money']"));
		System.out.println("Transfermoneypage" +"is" + "landed successfully");
		Thread.sleep(5000);
		//Transfer Account-from Account
		WebElement FromAccountdropdown=driver.findElement(By.xpath("/html/body/main/div/div/div/div[2]/div[1]/form/div[1]/div/div[1]/div"));
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(FromAccountdropdown, " FromAccountdropdown", "4"));

		}else{
			testSteps.add(ReportData.clickWebIos(FromAccountdropdown, "FromAccountdropdown", "4"));
		}
		Thread.sleep(20000);
		//Select the Account for transfer					
		WebElement FromAccount=driver.findElement(By.xpath("/html/body/div[5]/div/section/ul[1]/li[1]/div"));
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(FromAccount, " FromAccount", "5"));

		}else{
			testSteps.add(ReportData.clickWebIos(FromAccount, "FromAccount", "5"));
		}
		Thread.sleep(20000);
		//Transfer Account-dropdown
		WebElement ToAccountdropdown=driver.findElement(By.xpath("/html/body/main/div/div/div/div[2]/div[1]/form/div[2]/div/div[1]/div"));
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(ToAccountdropdown, " ToAccountdropdown", "6"));

		}else{
			testSteps.add(ReportData.clickWebIos(ToAccountdropdown, "ToAccountdropdown", "6"));
		}

		//Select the Destination Account
		Thread.sleep(20000);
		WebElement ToAccount=driver.findElement(By.xpath("/html/body/div[5]/div/section/ul[1]/li[1]/div"));
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(ToAccount, " ToAccount", "7"));

		}else{
			testSteps.add(ReportData.clickWebIos(ToAccount, "ToAccount", "7"));
		}
		Thread.sleep(10000);
		//Enter the Amount
		WebElement TransferAmount=driver.findElement(By.xpath("//*[@id='homeTransferAmount']"));
		testSteps.add(ReportData.enterText(TransferAmount, "1000.00", "Amount to be transferred", "8"));



		Thread.sleep(20000);
		//Click on Continue button
		WebElement continuebutton=driver.findElement(By.xpath("//button[@type='submit']"));
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(continuebutton, " continuebutton", "9"));

		}else{
			testSteps.add(ReportData.clickWebIos(continuebutton, "continuebutton", "9"));
		}
		Thread.sleep(20000);
		//Verify the transfer page landed
		driver.findElement(By.xpath("//h1[.='Verify Transfer']"));
		System.out.println("The confirmation page for transfer and pay is landed succesfully");
		Thread.sleep(5000);
		//Click on Make Transfer
		WebElement MakeTransfer=driver.findElement(By.xpath("//button[.='Make Transfer']"));
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(MakeTransfer, " MakeTransfer", "10"));

		}else{
			testSteps.add(ReportData.clickWebIos(MakeTransfer, "MakeTransfer", "10"));
		}

		Thread.sleep(5000);
		//Validate Transfer confirmation page
		driver.findElement(By.xpath("//h1[.='Transfer Confirmation']"));
		System.out.println("The transfer confirmation page is displayed successfully");




		testCase.setTestStepList(testSteps);
		return testCase;
	}
}	
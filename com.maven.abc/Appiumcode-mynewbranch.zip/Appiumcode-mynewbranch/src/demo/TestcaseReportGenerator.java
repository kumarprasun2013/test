package demo;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

import com.wellsfargo.test.domain.TestCase;



public class TestcaseReportGenerator {
	private static TestcaseReportGenerator instance = new TestcaseReportGenerator();

	private TestcaseReportGenerator() {
		//singleton
	}

	public static TestcaseReportGenerator instance() {
		return instance;
	}
	public static void main(String[] args) {
		System.out.println("Start Testcase report");
		TestCase testCase = new TestCase();
		

		TestcaseReportGenerator.instance().generateReport(testCase,"TestCase.html");
		System.out.println("Done testcase report");
}
	public void generateReport(TestCase testCase,String testCaseName) {
		Velocity.init();
		VelocityContext context = new VelocityContext();
		context.put("testCase", testCase);
		String fileName = testCaseName+".html";

		Template template = null;
		try {
			template = Velocity.getTemplate("TestcaseReport.vm");
		} catch (Exception e) {
			e.printStackTrace();
		}

		StringWriter sw = new StringWriter();
		template.merge(context, sw);

		try {
			FileUtils.write(new File(fileName), sw.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static final class TestResult {
		private String dateTime;
		private String iteration;
		private String startIteration;
		private String endIteration;
		private String executionMode;
		private String executedOn;
		private String deviceName;
		private String User;
		
		private String actualDuration;
		private String totalDuration;
		

		public String getDateTime() {
			return dateTime;
		}

		public void setDateTime(String dateTime) {
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			 dateTime=dateFormat.format(date);
			this.dateTime = dateTime;
		}

		public String getIteration() {
			return iteration;
		}

		public void setIteration(String iteration) {
			this.iteration = iteration;
		}

		public String getStartIteration() {
			return startIteration;
		}

		public void setStartIteration(String startIteration) {
			this.startIteration = startIteration;
		}

		public String getEndIteration() {
			return endIteration;
		}

		public void setEndIteration(String endIteration) {
			this.endIteration = endIteration;
		}

		public String getExecutionMode() {
			return executionMode;
		}

		public void setExecutionMode(String executionMode) {
			this.executionMode = executionMode;
		}

		public String getExecutedOn() {
			return executedOn;
		}

		public void setExecutedOn(String executedOn) {
			this.executedOn = executedOn;
		}

		public String getDeviceName() {
			return deviceName;
		}

		public void setDeviceName(String deviceName) {
			this.deviceName = deviceName;
		}

		public String getUser() {
			return User;
		}

		public void setUser(String User) {
			this.User = User;
		}

		

		public String getActualDuration() {
			return actualDuration;
		}

		public void setActualDuration(String actualDuration) {
			this.actualDuration = actualDuration;
		}

		public String getTotalDuration() {
			return totalDuration;
		}

		public void setTotalDuration(String totalDuration) {
			this.totalDuration = totalDuration;
		}

		
		
	}


}

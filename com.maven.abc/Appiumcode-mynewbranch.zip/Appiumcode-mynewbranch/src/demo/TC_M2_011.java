package demo;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.wellsfargo.test.TestCase.ReportData;
import com.wellsfargo.test.domain.TestCase;
import com.wellsfargo.test.domain.TestSteps;
import com.wellsfargo.test.framework.ITestCase;
import com.wellsfargo.test.framework.PageWait;
import com.wellsfargo.test.framework.Utils;

public class TC_M2_011 extends ReportData implements ITestCase{
	public TestCase run() throws Exception, Throwable {
	//	Validate More Menu options -> Nickname Accounts link
		TestCase testCase = Utils.createTestCase("TC_M2_011");
		List<TestSteps> testSteps = new ArrayList<TestSteps>();
	
		//Click on more menu
		driver.findElement(By.cssSelector("body > header > div.masthead-menu-box > div > a"));
		Switchview.switchtoNative();
		Thread.sleep(10000);
		driver.tap(1,1000, 145, 10);
		Switchview.switchtoWebview();
		Thread.sleep(20000);
//Click on Settings
		//WebElement Settings=driver.findElement(By.xpath("//span[.='Settings']"));
				WebElement Settings=driver.findElement(By.xpath("//a[text()='Settings']"));
				if(TESTING_DEVICE_TYPE.equals("Android")){
					testSteps.add(ReportData.tapOnElement(Settings, "Settings is clicked", "1"));
					System.out.println("Settings are clicked");
				}else{
					testSteps.add(ReportData.clickWebIos(Settings, "Settings is clicked", "1"));
					System.out.println("Settings are clicked");
				}
				Thread.sleep(20000);
//Click on   Nickname Accounts
				PageWait.fluentWait(By.xpath("//a[text()='Nickname Accounts']"));
				Thread.sleep(10000);
				WebElement NicknameAccounts=driver.findElement(By.xpath("//a[text()='Nickname Accounts']"));
				if(TESTING_DEVICE_TYPE.equals("Android")){
					testSteps.add(ReportData.tapOnElement(NicknameAccounts, "Textbanking option is clicked", "2"));
					System.out.println("NicknameAccounts is clicked");
				}else{
					testSteps.add(ReportData.clickWebIos(NicknameAccounts, "Textbanking option is clicked", "2"));
					System.out.println("NicknameAccounts is clicked");
				}
				Thread.sleep(20000);
				//Check whether the travel plan page is landed successfully
				WebElement NicknameAccountspage=driver.findElement(By.xpath("//*[@id='travelNErrors']/h2"));
				if(NicknameAccountspage.isDisplayed()){
					System.out.println("The NicknameAccountspage is landed successfully");
				}else{
					System.out.println("Please check the application");	
				}
testCase.setTestStepList(testSteps);
return testCase;
	}
}

package demo;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.wellsfargo.test.TestCase.ReportData;
import com.wellsfargo.test.domain.TestCase;
import com.wellsfargo.test.domain.TestSteps;
import com.wellsfargo.test.framework.ITestCase;
import com.wellsfargo.test.framework.PageWait;
import com.wellsfargo.test.framework.Utils;

public class TC_M2_002 extends ReportData implements ITestCase{ 
	public TestCase run() throws Exception, Throwable {
		TestCase testCase = Utils.createTestCase("TC_M2_002");
		List<TestSteps> testSteps = new ArrayList<TestSteps>();
		Thread.sleep(10000);
		//Validate moremenu->Account summary link
		
		//Click on more menu
		PageWait.fluentWait(By.xpath("/html/body/div[2]/button[2]/i"));
		WebElement obj=driver.findElement(By.xpath("/html/body/div[2]/button[2]/i"));
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(obj, "menu is clicked", "1"));
			System.out.println("Click on the menu");
		}else{
			testSteps.add(ReportData.clickWebIos(obj, "menu is clicked", "1"));
			System.out.println("Click on  the menu");
		}
		Thread.sleep(10000);
		//Click on Account summary link
		WebElement Accountsummary=driver.findElement(By.xpath("//span[.='Account Summary']"));
		if(TESTING_DEVICE_TYPE.equals("Android")){
			testSteps.add(ReportData.tapOnElement(Accountsummary, "Account summary is clicked", "1"));
			System.out.println("Click on Account summary in the menu");
		}else{
			testSteps.add(ReportData.clickWebIos(Accountsummary, "Account summary is clicked", "1"));
			System.out.println("Click on Account summary in the menu");
		}
		Thread.sleep(10000);
		//Check whether Accountsummary page is landed
		WebElement Accountsummarypage=driver.findElement(By.xpath("//h1[.='Account Summary']"));
		if(Accountsummarypage.isDisplayed()){
			System.out.println("The Accountsummarypage is landed successfully");
		}else{
			System.out.println("The Accountsummarypage is not avaiable.please check the application");
		}
		testCase.setTestStepList(testSteps);
		return testCase;
}
}
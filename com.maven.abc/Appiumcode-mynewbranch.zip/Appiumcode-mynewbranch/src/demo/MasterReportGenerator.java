package demo;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;

import org.apache.commons.io.FileUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

import com.wellsfargo.test.domain.TestCase;
import com.wellsfargo.test.domain.TestResult;

public class MasterReportGenerator {

	private static MasterReportGenerator instance = new MasterReportGenerator();

	private MasterReportGenerator() {
		// singleton
	}

	public static MasterReportGenerator instance() {
		return instance;
	}

	public static void main(String[] args) {
		System.out.println("Start master report");

		TestResult testResult = new TestResult();
		testResult.setDateTime("TODO");
		testResult.setIteration("TODO");
		testResult.setStartIteration("TODO");
		testResult.setEndIteration("TODO");
		testResult.setExecutionMode("TODO");
		testResult.setExecutedOn("TODO");
		testResult.setDeviceName("TODO");
		testResult.setUser("TODO");
		testResult.setOnError("TODO");
		testResult.setRunConfiguration("TODO");
		testResult.setNumOfThreads("TODO");
		testResult.setActualDuration("TODO");
		testResult.setTotalDuration("TODO");
		//testResult.addTestCase(testcase);

		TestCase testcase = new TestCase();
		testcase.setTestName("testcase1");
		testcase.setTestCaseId("testcaseId1");
		testcase.setLinkUrl("Testcase.html");
		testcase.setDescription("testcase1 Description");
		testcase.setExecutionTime("00: 12: 14");
		testcase.setPlatform("Android");
		testcase.setPass(true);
		

		testcase = new TestCase();
		testcase.setTestName("testcase2");
		testcase.setTestCaseId("testcaseId2");
		testcase.setLinkUrl("Testcase.html");
		testcase.setDescription("testcase2 Description");
		testcase.setExecutionTime("01: 12: 14");
		testcase.setPlatform("IOS");
		testcase.setPass(false);
		

		MasterReportGenerator.instance().generateReport(testResult);
		System.out.println("Done master report");
	}

	public void generateReport(TestResult testResult) {
		Velocity.init();
		VelocityContext context = new VelocityContext();
		context.put("testResult", testResult);

		Template template = null;
		try {
			template = Velocity.getTemplate("MasterReport.vm");
		} catch (Exception e) {
			e.printStackTrace();
		}

		StringWriter sw = new StringWriter();
		template.merge(context, sw);

		try {
			FileUtils.write(new File("MasterReport.html"), sw.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

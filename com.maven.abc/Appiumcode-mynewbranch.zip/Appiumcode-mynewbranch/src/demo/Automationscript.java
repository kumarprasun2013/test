package demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.testng.annotations.Test;

import com.wellsfargo.test.TestCase.ReportData;
import com.wellsfargo.test.domain.TestCase;
import com.wellsfargo.test.domain.TestResult;
import com.wellsfargo.test.framework.DriverAndroid;
import com.wellsfargo.test.framework.DriverIos;
import com.wellsfargo.test.framework.ITestCase;



public class Automationscript extends ReportData {
	@Test
	public void demo() throws Throwable{
		TestResult testResult = ReportData.createTestResult("3.16");
		List<TestCase> testCaseList = new ArrayList<TestCase>();
		testResult.setTestCases(testCaseList);
		//Launch the app checking the device type on the phone
		if(TESTING_DEVICE_TYPE.equals("Android")){
			DriverAndroid DriverAndroid=new DriverAndroid();
			DriverAndroid.app();

		}else{
			DriverIos DriverIos=new DriverIos();
			DriverIos.launchapp();
		}
		ITestCase testCase = null;
		Thread.sleep(5000);
		

		//Sign on the app with user name and password
		if(TESTING_DEVICE_TYPE.equals("Android")){

			testCase = new SignOnAndroid();
			testCaseList.add(testCase.run());
			Thread.sleep(5000);
		}else{
			testCase = new SignOnIos();
			testCaseList.add(testCase.run());
		}
		Thread.sleep(20000);


		//Switch to Webview


		@SuppressWarnings("unchecked")
		Set <String> contextNames=driver.getContextHandles();
		Iterator<String> contextIterator=contextNames.iterator();
		while(contextIterator.hasNext()){
			String contextName = contextIterator.next().toString();
			System.out.println(contextName);
			if (contextName.contains("WEBVIEW_")|| contextName.contains("WEBVIEW_com") )
			{				driver.context(contextName);
			System.out.println("The context is changed to" +contextName);

			}	
		}

		Thread.sleep(20000);
		

		//Execute test case TC_M2_002
		testCase=new TC_M2_002();
		testCaseList.add(testCase.run());

		

		//Execute test case TC_M2_007
		testCase=new TC_M2_007();
		testCaseList.add(testCase.run());

	
		//Execute test case TC_M2_011
		testCase=new TC_M2_011();
		testCaseList.add(testCase.run());


		//Transfer and pay
		testCase=new Transferandpay();
		testCaseList.add(testCase.run());

		ReportData.generateReport(testResult);

	}



}

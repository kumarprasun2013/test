package demo;

import java.util.Iterator;
import java.util.Set;

import com.wellsfargo.test.TestCase.ReportData;



public class Switchview extends ReportData {
	
		public  static void switchtoWebview() throws InterruptedException{
			@SuppressWarnings("unchecked")
			Set <String> contextNames=driver.getContextHandles();


			Iterator<String> contextIterator=contextNames.iterator();
			while(contextIterator.hasNext()){
				String contextName = contextIterator.next().toString();
				System.out.println(contextName);
				if (contextName.contains("WEBVIEW_")|| contextName.contains("WEBVIEW_com") )
				{
					driver.context(contextName);
					System.out.println("The context is changed to" +contextName);
					

				}

			}
		}

		public static void switchtoNative() throws InterruptedException{
			@SuppressWarnings("unchecked")
			Set <String> contextNames=driver.getContextHandles();


			Iterator<String> contextIterator=contextNames.iterator();
			while(contextIterator.hasNext()){
				String contextName = contextIterator.next().toString();
				System.out.println(contextName);
				if (contextName.contains("NATIVE_")|| contextName.contains("android.mobile.native") )
				{
					driver.context(contextName);
					System.out.println("Swiched to native");


				}
			}
		}
	}

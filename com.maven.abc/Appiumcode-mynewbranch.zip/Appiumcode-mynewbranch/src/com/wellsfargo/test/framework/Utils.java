package com.wellsfargo.test.framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.wellsfargo.test.domain.TestCase;

import io.appium.java_client.AppiumDriver;

public class Utils {

	public static TestCase createTestCase(String testCaseName) {
		TestCase testCase = new TestCase();
		String urlLink = testCaseName + ".html";
		testCase.setTestName(testCaseName);
		testCase.setTestCaseId(testCaseName);
		testCase.setLinkUrl(urlLink);
		testCase.setDescription(testCaseName);
		testCase.setExecutionTime(getCurrentTime());
		testCase.setPlatform(ICommonConstants.TESTING_DEVICE_TYPE);
		testCase.setEndIteration("1");
		testCase.setStartIteration("1");
		testCase.setExecutedOn(ICommonConstants.TESTING_DEVICE_TYPE);
		testCase.setIterationMode("RUN_ONE_ITERATION_ONLY");
		testCase.setUser("padmasudha");
		
		testCase.setPass(true);
		return testCase;

	}
	
	public static  void switchToWebview(@SuppressWarnings("rawtypes") AppiumDriver driver ) throws InterruptedException {
		@SuppressWarnings("unchecked")
		Set <String> contextNames=driver.getContextHandles();
		Iterator<String> contextIterator=contextNames.iterator();
		while(contextIterator.hasNext()){
			String contextName = contextIterator.next().toString();
			System.out.println(contextName);
			if (contextName.contains("WEBVIEW_")|| contextName.contains("WEBVIEW_com") )
			{
				driver.context(contextName);
				Thread.sleep(10000);
				
			}
		}
	}
	@SuppressWarnings("rawtypes")
	public  void switchtoNative(AppiumDriver driver) throws Exception {
		@SuppressWarnings("unchecked")
		Set <String> contextNames=driver.getContextHandles();
		Iterator<String> contextIterator=contextNames.iterator();
		while(contextIterator.hasNext()){
			String contextName = contextIterator.next().toString();
			System.out.println(contextName);
			if (contextName.contains("NATIVE_APP") )
			{
				driver.context(contextName);
				System.out.println(contextName);


			}	

		}
		
	}
	
	
	/**
	 * 
	 * @return
	 */
	public static String getCurrentTime() {
		String str_time;
		Date exec_time = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		str_time = dateFormat.format(exec_time);
		return str_time;
	}

	/*
	 * Name Of the Method: readXlSheet Brief Description: Read the XL content
	 * Arguments: dtTablePath--> dtatTable Path, sheetName --> Name of the Sheet
	 * Creation Date - July 20-2016 Last Modification Date - July 20-2016
	 * Created by - Padmasudha
	 */

	public static String[][] readXlSheet(String sheetName) throws IOException {

		/* Step 1: Get the XL Path */
		File xlFile = new File(ICommonConstants.testDataURL);

		/* step2: Access the Xl File */
		FileInputStream xlDoc = new FileInputStream(xlFile);

		/* Step3: Access the work book (POI jar file) */
		HSSFWorkbook wb = new HSSFWorkbook(xlDoc);

		/* Step4: Access the Sheet */
		HSSFSheet sheet = wb.getSheet(sheetName);

		int iRowCount = sheet.getLastRowNum() + 1;
		int iColCount = sheet.getRow(0).getLastCellNum();

		String[][] xlData = new String[iRowCount][iColCount];

		for (int i = 0; i < iRowCount; i++) {

			for (int j = 0; j < iColCount; j++) {
				xlData[i][j] = sheet.getRow(i).getCell(j).getStringCellValue();
			}
			wb.close();
		}
		return xlData;

	}

}

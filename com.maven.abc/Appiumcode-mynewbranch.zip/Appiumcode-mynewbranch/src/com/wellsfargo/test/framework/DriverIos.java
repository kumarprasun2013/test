package com.wellsfargo.test.framework;

import java.net.MalformedURLException;
import java.net.URL;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.wellsfargo.test.TestCase.ReportData;



public class DriverIos extends ReportData {
	public void launchapp() throws MalformedURLException{
		DesiredCapabilities capabilities = new DesiredCapabilities();
		//capabilities.setCapability("deviceName", "M2 Dev");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "M2Dev");
		capabilities.setCapability("platformVersion", "9.3.2");
		capabilities.setCapability("udid", "bae4e109b3945bf7dff0743afec279b251178824");
		capabilities.setCapability("platformName", "iOS");
		driver = new IOSDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

		   
		
		  
		//capabilities.setCapability("autoWebview", "true");
		//driver  =new IOSDriver(new URL("http://127.0.0.1:4728/wd/hub"),capabilities);
		//driver .manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);


	}

}

package com.wellsfargo.test.framework;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.wellsfargo.test.TestCase.ReportData;
import io.appium.java_client.android.AndroidDriver;

public class DriverAndroid extends ReportData{
	@SuppressWarnings("rawtypes")
	public void app() throws MalformedURLException{
		
		
		//launching app in Android		 
		File app=new File("/Users/u521867/Documents/Lifebloodacc/Apkfiles/AndroidApp-5.5.0.133-4.16.0-phone-sit-universal-releaseAppium.apk");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName", "SAMSUNG SM-G900V");
		capabilities.setCapability("platformVersion", "4.4.4");
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("app", app.getAbsolutePath());
	driver =new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
	
	
	driver .manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);

}
}

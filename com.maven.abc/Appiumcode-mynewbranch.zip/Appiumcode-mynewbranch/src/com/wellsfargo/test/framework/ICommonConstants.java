package com.wellsfargo.test.framework;

public interface ICommonConstants {

	String ANDROID = "Android";
	String IOS = "Ios";
	String PASS = "PASS";
	String FAIL = "FAIL";

	String testDataURL = "/Users/u521867/Documents/Lifebloodacc/TestData/Accountsummary.xls";
	String signOnSheet = "sheet1";

	

	

	// Set the device type
	String TESTING_DEVICE_TYPE = IOS;
}

package com.wellsfargo.test.framework;

import com.wellsfargo.test.domain.TestCase;

import io.appium.java_client.AppiumDriver;

public interface ITestCase extends ICommonConstants{

	public TestCase run() throws Exception, Throwable ;
	
}

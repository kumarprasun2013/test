package com.wellsfargo.test.TestCase;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import com.wellsfargo.test.domain.TestCase;
import com.wellsfargo.test.domain.TestResult;
import com.wellsfargo.test.domain.TestSteps;
import com.wellsfargo.test.framework.ICommonConstants;
import com.wellsfargo.test.framework.Utils;

import demo.Switchview;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;

public class ReportData  implements ICommonConstants {
	@SuppressWarnings("rawtypes")
	public static AppiumDriver driver;
	private static String ENTER_TEXT = "Enter Text";
	private static String DESC_PASS = " is entered in ";
	private static String DESC_FAIL = " is not found. Please check the elements.";

	public static TestResult createTestResult(String Release) {
		TestResult testResult = new TestResult();
		testResult.setIteration(Release);
		testResult.setStartIteration("08-15-2016");
		testResult.setEndIteration("1");
		testResult.setExecutionMode("Appium Automation");
		testResult.setExecutedOn("Real Device");
		testResult.setDeviceName("Android/Ios");
		testResult.setUser("Padmasudha");
		testResult.setOnError("NEXT_Iteration");
		testResult.setRunConfiguration("Regression");
		testResult.setNumOfThreads("1");
		testResult.setDateTime(Utils.getCurrentTime());
		return testResult;

	}
	
	public static boolean retryingFindClick(String by) {
        boolean result = false;
        int attempts = 0;
        while(attempts < 2) {
            try {
                driver.findElement(By.xpath(by)).click();
                result = true;
                break;
            } catch(StaleElementReferenceException e) {
            }
            attempts++;
        }
        return result;
}
	
	
	
	
	
	
	
	
	
/**
 * Method Name:Set coeffxs
 * @throws InterruptedException 
 */
	private static double nativeX;    
	private static double nativeY;
	private static double coeffX;
	private static double coeffY;
	public  static void setCoeffs(WebElement element) throws InterruptedException {
		Switchview.switchtoNative();
		double topDeviceBarSize =0;
		
		if (driver.findElement(By.xpath("//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]")).isDisplayed()) {
			
		 topDeviceBarSize = driver.findElement(By.xpath("//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]"))
		.getLocation().getY();
		}
		nativeX = driver.manage().window().getSize().getWidth();
		nativeY = (driver.manage().window().getSize().getHeight())-topDeviceBarSize;
		Switchview.switchtoWebview();
		double webX = driver.findElement(By.xpath("//body")).getSize().getWidth();
		double webY = driver.findElement(By.xpath("//body")).getSize().getHeight();
		coeffX = nativeX/webX;
		coeffY = nativeY/webY;
		System.out.println("extention is set");
			Switchview.switchtoWebview();
			
			int coordinateX = (int) Math.round((element.getLocation().getX()*coeffX)
					+ (((element.getSize().width)*coeffX) / 2));
			System.out.println("coordinateX" + "is"+ coordinateX);
			int coordinateY = (int) Math.round((element.getLocation().getY()*coeffY)
					+ topDeviceBarSize + (((element.getSize().height)*coeffY) / 2));
			System.out.println("coordinateY" + "is"+ coordinateY);
			 if (coordinateY >= nativeY){ //we need this is the element is out of sight
				 ReportData.scrolldown(element);
				
				 Thread.sleep(10000);
				 int coordinateY1 = (int) Math.round((element.getLocation().getY()*coeffY)
							+ topDeviceBarSize + (((element.getSize().height)*coeffY) / 2));
				// int coordinateYnew = (int) Math.round((element.getLocation().getY()*coeffY)
						//	 + (((element.getSize().height)*coeffY) / 2) -2*(topDeviceBarSize+45));
			//coordinateY = scrolldown( element); 
				 System.out.println("@@@ Clicking on Element " + element);
					Switchview.switchtoNative();
					
					driver.tap(1, coordinateX, coordinateY1+45, 1);
					System.out.println("@@@ With coordinates " + coordinateX + " " + coordinateY1+45);
					Switchview.switchtoWebview();	 
				 
			 }else{
				 Thread.sleep(20000);
					System.out.println("@@@ Clicking on Element " + element);
					Switchview.switchtoNative();
					
					driver.tap(1, coordinateX, coordinateY+45, 1);
					System.out.println("@@@ With coordinates " + coordinateX + " " + coordinateY+45);
					Switchview.switchtoWebview();	 
			 }
			 
		
		}
	
	public   static void   scrolldown(WebElement element) throws InterruptedException {
//		Switchview Switchview=new Switchview();
//				Switchview.switchtoNative();
//				Dimension dimensions = driver.manage().window().getSize();
//			Double screenHeightStart = dimensions.getHeight() * 0.5;
//				int scrollStart = screenHeightStart.intValue();
//			Double screenHeightEnd = dimensions.getHeight() * 0.2;
//			int scrollEnd = screenHeightEnd.intValue();
//				driver.swipe(0,scrollStart,0,scrollEnd,2000);
//				Switchview.switchtoWebview();
//			return scrollEnd;
		// Create instance of Javascript executor
		 
		JavascriptExecutor je = (JavascriptExecutor) driver;
			// now execute query which actually will scroll until that element is not appeared on page.
		 
		je.executeScript("arguments[0].scrollIntoView(true);",element);
		System.out.println("The element is scrolled up");
		 
		
	}
/*
 * Method name:tap on the element
 */
	public static  TestSteps tapOnElement(WebElement element,String objName, String stepNo) throws InterruptedException  {
		TestSteps stepsStatus = new TestSteps();
		stepsStatus.setTime(Utils.getCurrentTime());
		stepsStatus.setNo(stepNo);
		stepsStatus.setName("CLICK");
		StringBuilder descBuillder = new StringBuilder();
if (element.isDisplayed()){
	
		ReportData.setCoeffs(element);
		stepsStatus.setStatus(ICommonConstants.PASS);
		descBuillder.append(objName);
	descBuillder.append(" is Clicked.");
		stepsStatus.setDesc(descBuillder.toString());
	
		System.out.println("Pass:  is clicked.");
	
	}else
	{
		stepsStatus.setStatus(ICommonConstants.FAIL);
		descBuillder.append(objName);
		descBuillder.append("is not displayed. Please check application.");
		stepsStatus.setDesc(descBuillder.toString());
		System.out.println("Fail: "+" object didnot display. Please check the application");

	}
	return stepsStatus;

		}
	

	/**
	 * 
	 * Method Name : clickButton Brief Description - to click a button
	 * Arguments: obj---> button object to be clicked, objName ---> name of the
	 * object Creation Date - July 20-2016 Last Modification Date - July 20-2016
	 * Created by - Padmasudha
	 */
	public static TestSteps enterText(WebElement obj, String textVal, String objName, String stepNo)
			throws IOException {

		TestSteps stepsStatus = new TestSteps();
		stepsStatus.setTime(Utils.getCurrentTime());
		stepsStatus.setNo(stepNo);
		stepsStatus.setName(ENTER_TEXT);
		StringBuilder descBuillder = new StringBuilder();
		descBuillder.append(textVal);
		if (obj.isDisplayed()) {
			obj.sendKeys(textVal);
			stepsStatus.setStatus(ICommonConstants.PASS);
			descBuillder.append(DESC_PASS);
			descBuillder.append(objName);
			stepsStatus.setDesc(descBuillder.toString());
		} else {
			stepsStatus.setStatus(ICommonConstants.FAIL);
			descBuillder.append(DESC_FAIL);
			stepsStatus.setDesc(descBuillder.toString());
		}
		return stepsStatus;

	}

	/*
	 * Method Name : clickButton Brief Description - to click a button
	 * Arguments: obj---> button object to be clicked, objName ---> name of the
	 * object Creation Date - July 20-2016 Last Modification Date - July 20-2016
	 * Created by - Padmasudha
	 */
	public static TestSteps clickButton(WebElement obj, String objName, String stepNo) throws IOException {

		TestSteps stepsStatus = new TestSteps();
		stepsStatus.setTime(Utils.getCurrentTime());
		stepsStatus.setNo(stepNo);
		stepsStatus.setName("CLICK");
		StringBuilder descBuillder = new StringBuilder();
		if (obj.isDisplayed()) {
			obj.click();
			stepsStatus.setStatus(ICommonConstants.PASS);
			descBuillder.append(objName);
			descBuillder.append(" is Clicked.");
			stepsStatus.setDesc(descBuillder.toString());
		} else {
			stepsStatus.setStatus(ICommonConstants.FAIL);
			descBuillder.append(objName);
			descBuillder.append(" not found.");
			stepsStatus.setDesc(descBuillder.toString());
		}
		return stepsStatus;

	}
	

	/*
	 * Method Name: validateText Brief Description: Check if Actual text matches
	 * Expected text ot not. Arguments: obj ---> object, expectedText -->
	 * expected text message, objName ---->Name of the Object Creation Date -
	 * July 20-2016 Last Modification Date - July 20-2016 Created by -
	 * Padmasudha
	 */

	public static TestSteps validateText(WebElement obj, String expectedText, String objName, String stepNo)
			throws Throwable {

		TestSteps stepsStatus = new TestSteps();
		stepsStatus.setTime(Utils.getCurrentTime());
		stepsStatus.setNo(stepNo);
		stepsStatus.setName("Validate Text");
		StringBuilder descBuillder = new StringBuilder();

		if (obj.isDisplayed()) {
			String actualText = obj.getText();
			if (actualText.equals(expectedText)) {
				stepsStatus.setStatus(ICommonConstants.PASS);
				descBuillder.append("Actual Text matching the Expected Text");
				stepsStatus.setDesc(descBuillder.toString());

			} else {
				stepsStatus.setStatus(ICommonConstants.FAIL);
				descBuillder.append("Actual Text is not matching the Expected Text");
				stepsStatus.setDesc(descBuillder.toString());

			}
		} else {
			stepsStatus.setStatus(ICommonConstants.FAIL);
			descBuillder.append(objName);
			descBuillder.append("is not displayed. Please check application.");
			stepsStatus.setDesc(descBuillder.toString());

		}
		return stepsStatus;

	}
	


	/*
	 * Method  Name : clickwebButton 
	 * Brief Description - to click a button for Ios
	 * Arguments: obj---> button object to be clicked, objName ---> name of the object 
	 *Creation Date - July 20-2016
	 * Last Modification Date - July 20-2016
	 * Created by - Padmasudha
	 */
	public static  TestSteps clickWebIos (WebElement obj,String objName, String stepNo) throws IOException{
		TestSteps stepsStatus = new TestSteps();
		stepsStatus.setTime(Utils.getCurrentTime());
		stepsStatus.setNo(stepNo);
		stepsStatus.setName("CLICK");
		StringBuilder descBuillder = new StringBuilder();
		if (obj.isDisplayed()){
			//Select the object
			Point point = obj.getLocation();
			Dimension size=obj.getSize();
			int tapX = point.getX()+(size.getWidth()/2);
			
			int tapY = point.getY()+(size.getHeight()/2);
			// Execute tap
			String originalContext = driver.getContext();
			driver.context("NATIVE_APP");
			TouchAction action = new TouchAction(driver);
			descBuillder.append(objName);
			descBuillder.append(" is Clicked.");
			stepsStatus.setDesc(descBuillder.toString());
			action.tap(tapX, tapY).perform();
			stepsStatus.setStatus(ICommonConstants.PASS);
			System.out.println("Pass:  " +"The element is  clicked");
			//descBuillder.append(objName);
			//descBuillder.append(" is Clicked.");
			//stepsStatus.setDesc(descBuillder.toString());
			driver.context(originalContext);

			

		}
		else{
			
			stepsStatus.setStatus(ICommonConstants.FAIL);
			descBuillder.append(objName);
			descBuillder.append("is not displayed. Please check application.");
			stepsStatus.setDesc(descBuillder.toString());
			System.out.println("Fail: "+" object didnot display. Please check the application");


		}
		return stepsStatus;
	}


	
	

	






	public static void generateReport(TestResult testResult) {

		Velocity.init();
		
		if (CollectionUtils.isNotEmpty(testResult.getTestCases())) {
			for (TestCase testCase : testResult.getTestCases()) {
				VelocityContext localContext = new VelocityContext();
				localContext.put("testCase", testCase);
				Template template = null;
				try {
					template = Velocity.getTemplate("TestcaseReport.vm");
				} catch (Exception e) {
					e.printStackTrace();
				}

				StringWriter sw = new StringWriter();
				template.merge(localContext, sw);

				try {
					FileUtils.write(new File(testCase.getLinkUrl()), sw.toString());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		VelocityContext masterContext = new VelocityContext();

		masterContext.put("testResult", testResult);

		Template template = null;
		try {
			template = Velocity.getTemplate("MasterReport.vm");
		} catch (Exception e) {
			e.printStackTrace();
		}

		StringWriter sw = new StringWriter();
		template.merge(masterContext, sw);

		try {
			FileUtils.write(new File("MasterReport.html"), sw.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	
	public static void main(String[] args) {
		System.out.println("Start master report");

		TestResult testResult = new TestResult();
		testResult.setDateTime("TODO");
		testResult.setIteration("TODO");
		testResult.setStartIteration("TODO");
		testResult.setEndIteration("TODO");
		testResult.setExecutionMode("TODO");
		testResult.setExecutedOn("TODO");
		testResult.setDeviceName("TODO");
		testResult.setUser("TODO");
		testResult.setOnError("TODO");
		testResult.setRunConfiguration("TODO");
		testResult.setNumOfThreads("TODO");
		testResult.setActualDuration("TODO");
		testResult.setTotalDuration("TODO");
		List<TestCase> testCases = new ArrayList<TestCase>();
		testResult.setTestCases(testCases);

		TestCase testcase = new TestCase();
		testcase.setTestName("testcase1");
		testcase.setTestCaseId("testcaseId1");
		testcase.setLinkUrl("testcase1.html");
		testcase.setDescription("testcase1 Description");
		testcase.setExecutionTime("00: 12: 14");
		testcase.setPlatform(TESTING_DEVICE_TYPE);
		testcase.setPass(true);
		
		{
			List<TestSteps> testStepList = new ArrayList<TestSteps>();
			TestSteps testStep = new TestSteps();
			testStep.setName("teststep1");
			testStep.setNo("1");
			testStep.setStatus("TODO");
			testStep.setTime("TODO");
			testStep.setDesc("Desc");
			testStepList.add(testStep);
			
			testcase.setTestStepList(testStepList);
		}
		testCases.add(testcase);

		testcase = new TestCase();
		testcase.setTestName("testcase2");
		testcase.setTestCaseId("testcaseId2");
		testcase.setLinkUrl("Testcase.html");
		testcase.setDescription("testcase2 Description");
		testcase.setExecutionTime("01: 12: 14");
		testcase.setPlatform(TESTING_DEVICE_TYPE);
		testcase.setPass(false);
		{
			List<TestSteps> testStepList = new ArrayList<TestSteps>();
			TestSteps testStep = new TestSteps();
			testStep.setName("teststep2");
			testStep.setNo("1");
			testStep.setStatus("TODO");
			testStep.setTime("TODO");
			testStep.setDesc("Desc");
			testStepList.add(testStep);
			
			testcase.setTestStepList(testStepList);
		}
		testCases.add(testcase);

		generateReport(testResult);
		System.out.println("Done master report");
	}

}

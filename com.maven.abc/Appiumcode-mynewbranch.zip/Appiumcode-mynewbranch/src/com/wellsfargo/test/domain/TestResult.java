package com.wellsfargo.test.domain;

import java.util.List;

public class TestResult {

	private String dateTime;
	private String iteration;
	private String startIteration;
	private String endIteration;
	private String executionMode;
	private String executedOn;
	private String deviceName;
	private String User;
	private String onError;
	private String runConfiguration;
	private String numOfThreads;
	private String actualDuration;
	private String totalDuration;
	List<TestCase> testCases;

	public String getDateTime() {

		return dateTime;
	}

	public void setDateTime(String dateTime) {

		this.dateTime = dateTime;
	}

	public String getIteration() {
		return iteration;
	}

	public void setIteration(String iteration) {
		this.iteration = iteration;
	}

	public String getStartIteration() {
		return startIteration;
	}

	public void setStartIteration(String startIteration) {
		this.startIteration = startIteration;
	}

	public String getEndIteration() {
		return endIteration;
	}

	public void setEndIteration(String endIteration) {
		this.endIteration = endIteration;
	}

	public String getExecutionMode() {
		return executionMode;
	}

	public void setExecutionMode(String executionMode) {
		this.executionMode = executionMode;
	}

	public String getExecutedOn() {
		return executedOn;
	}

	public void setExecutedOn(String executedOn) {
		this.executedOn = executedOn;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getUser() {
		return User;
	}

	public void setUser(String User) {
		this.User = User;
	}

	public String getOnError() {
		return onError;
	}

	public void setOnError(String onError) {
		this.onError = onError;
	}

	public String getRunConfiguration() {
		return runConfiguration;
	}

	public void setRunConfiguration(String runConfiguration) {
		this.runConfiguration = runConfiguration;
	}

	public String getNumOfThreads() {
		return numOfThreads;
	}

	public void setNumOfThreads(String numOfThreads) {
		this.numOfThreads = numOfThreads;
	}

	public String getActualDuration() {
		return actualDuration;
	}

	public void setActualDuration(String actualDuration) {
		this.actualDuration = actualDuration;
	}

	public String getTotalDuration() {
		return totalDuration;
	}

	public void setTotalDuration(String totalDuration) {
		this.totalDuration = totalDuration;
	}

	public List<TestCase> getTestCases() {
		return testCases;
	}

	public void setTestCases(List<TestCase> testCases) {
		this.testCases = testCases;
	}

}

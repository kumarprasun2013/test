package com.wellsfargo.test.domain;

import java.util.ArrayList;
import java.util.List;


public class TestCase {
	private String testName;
	private String testCaseLink;
	private String dateTime;
	private String testCaseId;
	private String linkUrl;
	private String description;
	private String executionTime;
	private String deviceName;
	private String platform;
	private String startIteration;
	private String executionMode;
	private String endIteration;
	private String iterationMode;
	private String executedOn;
	private String user;
	
	List<TestSteps> testStepList = new ArrayList<TestSteps>();
	public String getDateTime() {

		return dateTime;
	}

	public void setDateTime(String dateTime) {

		this.dateTime = dateTime;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}

	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getExecutionTime() {
		return executionTime;
	}

	public void setExecutionTime(String executionTime) {
		this.executionTime = executionTime;
	}

	public String getPlatform() {
		
		return platform;
	}
	public String getTestCaseLink() {
		return testCaseLink;
	}

	public void setTestCaseLink(String testCaseLink) {
		this.testCaseLink = testCaseLink;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public boolean isPass() {
		return isPass;
	}

	public void setPass(boolean isPass) {
		this.isPass = isPass;
	}

	private boolean isPass;

	public String getStartIteration() {
		
		return startIteration;
	}

	public void setStartIteration(String startIteration) {
		this.startIteration = startIteration;
	}

	public String getExecutionMode() {
		return executionMode;
	}

	public void setExecutionMode(String executionMode) {
		executionMode=
		this.executionMode = executionMode;
	}

	public String getEndIteration() {
		return endIteration;
	}

	public void setEndIteration(String endIteration) {
		this.endIteration = endIteration;
	}

	public String getIterationMode() {
		return iterationMode;
	}

	public String setIterationMode(String iterationmode) {
		iterationmode="RUN_ONE_ITERATION_ONLY";
		return iterationmode;
	}

	public String getExecutedOn() {
		return executedOn;
	}
	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public void setExecutedOn(String executedOn) {
		this.executedOn = executedOn;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public List<TestSteps> getTestStepList() {
		return testStepList;
	}

	public void setTestStepList(List<TestSteps> testStepList) {
		this.testStepList = testStepList;
	}

	 
}

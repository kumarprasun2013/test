package com.wellsfargo.test.domain;

public class TestSteps {
	
	public String no;
	public String name;
	public String desc;
	public String status;
	public String time;

	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTime() {
		return time;
	}
	public  void setTime(String time) {
		
		this.time=time;
		
	}

}

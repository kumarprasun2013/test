package com.rest.test;

import java.io.IOException;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;

public class RestApiTest {
	
	@Test
	public void testApiAttribute() throws JsonParseException, JsonMappingException, IOException{
		
			String res=RestAssured.expect().body("name",Matchers.equalTo("iPad 3")).when().get("http://localhost:8088/RESTfulExample/json/product/get").andReturn().asString();
			System.out.println(res);
			User mapper=new ObjectMapper().readValue(res, User.class);
			
			System.out.println(mapper.getName());
			System.out.println(mapper.getQty());
			
		
			/*String jString = "{\"a\": 1, \"b\": \"str\"}";
			JSONObject jObj = new JSONObject(jString);
			Object aObj = jObj.get("a");
			if(aObj instanceof Integer){
			    System.out.println(aObj);
			}*/
			
	}

}

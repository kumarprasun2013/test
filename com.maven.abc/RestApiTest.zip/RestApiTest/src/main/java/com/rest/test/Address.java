package com.rest.test;

public class Address {
	
	private String houseName;

}

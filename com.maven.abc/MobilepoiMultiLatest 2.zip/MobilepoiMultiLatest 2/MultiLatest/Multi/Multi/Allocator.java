import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.sql.rowset.CachedRowSet;
import javax.swing.JOptionPane;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.perfectomobile.selenium.MobileDriver;
import com.perfectomobile.selenium.api.IMobileDevice;
import com.sun.jna.Platform;

import commonMethods.CommonMethodsInPOI;
import Driver.DriverScript;
import SeleniumHelper.SeleniumHelper;
import SupportLibraries.CRAFT_DB;
import SupportLibraries.CRAFT_PDFResults;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.GlobalVariables;
import SupportLibraries.KeywordImplementation;
import SupportLibraries.Settings;
import SupportLibraries.TestConfigurations;
import SupportLibraries.Util;

import java.io.*;

import org.apache.poi.hssf.usermodel.*;

import Driver.DriverScript;
import SeleniumHelper.SeleniumHelper;
import SupportLibraries.CRAFT_DB;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.GlobalVariables;
import SupportLibraries.KeywordImplementation;
import SupportLibraries.Util;

import java.util.Iterator;
import java.util.Properties;

import javax.swing.JOptionPane;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;


public class Allocator extends SeleniumHelper{

	public static boolean summaryFlag = false;


	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		//selenium.start();
		//selenium.setTimeout("70000");
		String dbRunManagerpath = null;
		String dbDatatablepath = null;
		String devicelistpath=null;
		String remoteResultPath=null;
		String path = null;
		TestConfigurations  testConfig = null,testConfigMainThread = null;
		ExecutorService executor,executorsingle = null;


		try
		{
			path = new File(".").getCanonicalPath();

		}
		catch(IOException ex)
		{
			System.out.println(ex.getMessage());
		}
		String resultPath =null;
		String ExcelResPath=null;
		String HtmlResPath=null;
		String PDFResultPath=null;
		String ScreenshotsPath=null;
		String PerfectoResultPath=null;
		String ScreenshotsConsolidatedPath=null;
		String HtmlResultSummaryFile=null;
		String ExcelResultSummaryFile=null;
		String PDFResultSummaryFile=null;
		String HtmlTestCaseResultFile=null;
		String PDFTestCaseResultFile=null;
		String ExcelTestCaseResultFile=null;
		Util.homePath = path;
		Properties properties = null;
		properties = Settings.getInstance();
//		String path1 = System.getProperty("user.dir");
//		String relativePath = new File(System.getProperty("user.dir")).getAbsolutePath();
//       if (relativePath.contains("supportlibraries")) {
//	     relativePath = new File(System.getProperty("user.dir")).getParent();}
		if (Util.debug)
		{
			JOptionPane.showMessageDialog(null, "path = "+path, "Message", JOptionPane.OK_OPTION);
		}

		
		String timestamp = "Run_"+Util.getCurrentDatenTime("MM-dd-yyyy")+"_"+Util.getCurrentDatenTime("hh-mm-ss_a");

		GlobalVariables.setTimestamp(timestamp);
		if(properties.getProperty("CreateRemoteResultFolder").contains("true"))
		{
			remoteResultPath = properties.getProperty("RemoteResultFolderPath");
			resultPath = remoteResultPath+ Util.getFileSeparator()+ "Results"+ Util.getFileSeparator()+timestamp;
			ExcelResPath = resultPath+Util.getFileSeparator()+"Excel Results";
			HtmlResPath = resultPath+Util.getFileSeparator()+"HTML Results";
			PDFResultPath =resultPath+Util.getFileSeparator()+"PDF Results";
			ScreenshotsPath = resultPath+Util.getFileSeparator()+"Screenshots";
			ScreenshotsConsolidatedPath = resultPath+Util.getFileSeparator()+"Screenshots Consolidated";
			PerfectoResultPath = resultPath+Util.getFileSeparator()+"Perfecto Results";
			HtmlResultSummaryFile=HtmlResPath+Util.getFileSeparator()+"Summary.html";
			ExcelResultSummaryFile=ExcelResPath+Util.getFileSeparator()+"Summary.xls";
			PDFResultSummaryFile = PDFResultPath+Util.getFileSeparator()+"Summary.pdf";
			System.out.println("Remote folder  is true");
		}
		else
		{
			remoteResultPath = path;
	//		String errorLogFile = reportPath + Util.getFileSeparator()+ "ErrorLog.txt";
			resultPath = remoteResultPath+ Util.getFileSeparator()+ "Results"+ Util.getFileSeparator()+timestamp;
			ExcelResPath = resultPath+Util.getFileSeparator()+"Excel Results";
			HtmlResPath = resultPath+Util.getFileSeparator()+"HTML Results";
			PDFResultPath =resultPath+Util.getFileSeparator()+"PDF Results";
			ScreenshotsPath = resultPath+Util.getFileSeparator()+"Screenshots";
			ScreenshotsConsolidatedPath = resultPath+Util.getFileSeparator()+"Screenshots Consolidated";
			PerfectoResultPath = resultPath+Util.getFileSeparator()+"Perfecto Results";
			HtmlResultSummaryFile=HtmlResPath+Util.getFileSeparator()+"Summary.html";
			ExcelResultSummaryFile=ExcelResPath+Util.getFileSeparator()+"Summary.xls";
			PDFResultSummaryFile = PDFResultPath+Util.getFileSeparator()+"Summary.pdf";
			
		}
		//String resultPath = remoteResultPath+"\\Results\\"+timestamp;


		try 
		{      
			if (Util.debug)
			{
				JOptionPane.showMessageDialog(null, "Inside try -Allocator.java", "Message", JOptionPane.OK_OPTION);
			}
			//new File(ExcelResPath).mkdirs();
			new File(HtmlResPath).mkdirs();
			new File(PDFResultPath).mkdir();
			new File(ScreenshotsPath).mkdirs();
			new File(PerfectoResultPath).mkdirs();
			new File(ScreenshotsConsolidatedPath).mkdirs();
			
			CRAFT_PDFResults.pdfSummaryFile=PDFResultSummaryFile;
			CRAFT_PDFResults.pdfResultFolderPath=PDFResultPath;
			CRAFT_Report.createSummaryHeader(HtmlResultSummaryFile,ExcelResultSummaryFile);
			
			dbRunManagerpath = path+Util.getFileSeparator()+"Run Manager"+".xls";
			//String query="SELECT * FROM [Main$] where Execute = TRUE";
			
			testConfigMainThread=new TestConfigurations();
			testConfigMainThread.setHtmlResultSummaryFile(HtmlResultSummaryFile);
			testConfigMainThread.setExcelResultSummaryFile(ExcelResultSummaryFile);
			testConfigMainThread.setDbDatatablePath(dbRunManagerpath);
			GlobalVariables.getConfigMap().put("main", testConfigMainThread);
			
			
			int rowCount,rowsOfScenarioSheet;
			FileInputStream file = new FileInputStream(new File(dbRunManagerpath));
			HSSFWorkbook workbookRunManager = new HSSFWorkbook(file);
		 
			HSSFSheet sheet = workbookRunManager.getSheetAt(0);
			
			rowCount = sheet.getLastRowNum();
			String scenario = null;
			int i = 1;
			CommonMethodsInPOI a = new CommonMethodsInPOI();
			while(i<=rowCount)
			{
				int cellExecute = a.getIndex(sheet, "Execute");
				boolean execute= sheet.getRow(i).getCell(cellExecute).getBooleanCellValue();
				if(execute)
				{
					int CellTestScenario = a.getIndex(sheet, "Test Scenarios");
					scenario = sheet.getRow(i).getCell(CellTestScenario).getStringCellValue();
							
					HSSFSheet sheetScenario = workbookRunManager.getSheet(scenario);
					dbDatatablepath = path+Util.getFileSeparator()+"Datatables"+Util.getFileSeparator()+scenario+".xls";
					CRAFT_DB.dbpath=dbDatatablepath;
					rowsOfScenarioSheet = sheetScenario.getPhysicalNumberOfRows();
					int j = 1;
					while(j<rowsOfScenarioSheet)
					{
						int cellExecuteScenario = a.getIndex(sheetScenario, "Execute");
						boolean executeCell = sheetScenario.getRow(j).getCell(cellExecuteScenario).getBooleanCellValue();
						if(executeCell)
						{
							String testcase = sheetScenario.getRow(j).getCell(a.getIndex(sheetScenario, "Test Cases")).getStringCellValue();
							GlobalVariables.setCurrenttestcase(testcase);
							String testcaseID = sheetScenario.getRow(j).getCell(a.getIndex(sheetScenario, "TestCaseID")).getStringCellValue();
							GlobalVariables.setCurrenttestcaseID(testcaseID);
							String desc = sheetScenario.getRow(j).getCell(a.getIndex(sheetScenario, "Description")).getStringCellValue();
							GlobalVariables.settestcasedesc(desc);
							String iterationMode = sheetScenario.getRow(j).getCell(a.getIndex(sheetScenario, "Iteration Mode")).getStringCellValue();
							String Devicename = sheetScenario.getRow(j).getCell(a.getIndex(sheetScenario, "DeviceName")).getStringCellValue();
							String thread = sheetScenario.getRow(j).getCell(a.getIndex(sheetScenario, "Thread")).getStringCellValue();
							String st1,end1;
							int startIteration=1, endIteration=1;
				
		

							if (Util.debug)
							{
								System.out.println(iterationMode);
							}
							FileInputStream dataTableFile = new FileInputStream(new File(dbDatatablepath));
							HSSFWorkbook workbookDataTable = new HSSFWorkbook(dataTableFile);
							HSSFSheet dataSheet = workbookDataTable.getSheet("Test Data");

							if (iterationMode.equals("Run all iterations"))
							{

								startIteration=1;
								endIteration =  a.getDistinctRowCount(dataSheet,"TC_ID",testcase);
							}
							else if (iterationMode.equals("Run one iteration only"))
							{
								startIteration=1;
								endIteration=1;
							}
							else
							{
								st1 =sheet.getRow(i).getCell(a.getIndex(sheetScenario, "Start Iteration")).getStringCellValue();
								try
								{
									startIteration =(int)Float.parseFloat(st1);
								}
								catch(Exception ex)
								{
								}
								end1 =sheet.getRow(i).getCell(a.getIndex(sheetScenario, "End Iteration")).getStringCellValue();
								try
								{
									endIteration =(int)Float.parseFloat(end1);
								}
								catch(Exception ex)
								{
								}
							}

							GlobalVariables.setStartIteration(startIteration);
							GlobalVariables.setEndIteration(endIteration);
							
							//setting devicelist excel path and fetching values
							devicelistpath = path+Util.getFileSeparator()+"Datatables"+Util.getFileSeparator()+"DeviceList"+".xls";
							FileInputStream devicefile = new FileInputStream(new File(devicelistpath));
							HSSFWorkbook workbookdevicefile = new HSSFWorkbook(devicefile);
							HSSFSheet devicesheet = workbookdevicefile.getSheetAt(0);
							
							int rowCountdevice;
							rowCountdevice = devicesheet.getLastRowNum();
							
							int k = 1;
							while(k<=rowCountdevice)
							{
								int cellDevicename = a.getIndex(devicesheet, "DeviceName");
								String DevicenameCell = devicesheet.getRow(k).getCell(cellDevicename).getStringCellValue();
								if(Devicename.equals(DevicenameCell)){
									String DeviceID = devicesheet.getRow(k).getCell(a.getIndex(devicesheet, "DeviceID")).getStringCellValue();
									String Platform = devicesheet.getRow(k).getCell(a.getIndex(devicesheet, "Platform")).getStringCellValue();
									String DeviceType = devicesheet.getRow(k).getCell(a.getIndex(devicesheet, "DeviceType")).getStringCellValue();
									String DeviceVersion = devicesheet.getRow(k).getCell(a.getIndex(devicesheet, "Device Version")).getStringCellValue();
									System.out.println(DeviceID);
							

							
							testConfig = new TestConfigurations();
							testConfig.setResultPath(resultPath);
							testConfig.setExcelResPath(ExcelResPath);
							testConfig.setHtmlResPath(HtmlResPath);
							testConfig.setScreenshotsPath(ScreenshotsPath);
							testConfig.setPerfectoResultPath(PerfectoResultPath);
							testConfig.setScreenshotsConsolidatedPath(ScreenshotsConsolidatedPath);
							testConfig.setHtmlResultSummaryFile(HtmlResultSummaryFile);
							testConfig.setExcelResultSummaryFile(ExcelResultSummaryFile);
							testConfig.setScenario(scenario);
							testConfig.setThread(thread);
							testConfig.setBrowser(DeviceID);
							testConfig.setDeviceType(DeviceType);
							testConfig.setDeviceVersion(DeviceVersion);
							testConfig.setPlatForm(Platform);
							testConfig.setDevicename(Devicename);
							testConfig.setCurrentTestCase(testcase);
							testConfig.setCurrentTestCaseID(testcaseID);
							testConfig.setTestCaseDesc(desc);
							testConfig.setStartIteration(startIteration);
							testConfig.setEndIteration(endIteration);
							testConfig.setDbDatatablePath(dbDatatablepath);
							testConfig.setDbtableSheet(dataSheet);
							
							//testConfig.setTestConfigs(testConfigs);
							if(Util.getValue("CreateRemoteResultFolder", "Creating remote folder").contains("true"))
							{

								HtmlTestCaseResultFile=HtmlResPath+Util.getFileSeparator()+testConfig.getCurrentTestCase()+"_"+testConfig.getDevicename()+".html";
								ExcelTestCaseResultFile=  ExcelResPath+Util.getFileSeparator()+testConfig.getCurrentTestCase()+".xls";   
								PDFTestCaseResultFile = PDFResultPath+Util.getFileSeparator()+testConfig.getCurrentTestCase()+"_"+testConfig.getDevicename()+".pdf"; 
								//System.out.println("Creating remote result");
							}
							else
							{
								HtmlTestCaseResultFile=HtmlResPath+Util.getFileSeparator()+testConfig.getCurrentTestCase()+"_"+testConfig.getDevicename()+".html";
								ExcelTestCaseResultFile=  ExcelResPath+Util.getFileSeparator()+testConfig.getCurrentTestCase()+".xls";   
								PDFTestCaseResultFile = PDFResultPath+Util.getFileSeparator()+testConfig.getCurrentTestCase()+"_"+testConfig.getDevicename()+".pdf";
							}
							testConfig.setExcelTestCaseResultFile(ExcelTestCaseResultFile);
							testConfig.setHtmlTestCaseResultFile(HtmlTestCaseResultFile);
							testConfig.setPDfResult(new CRAFT_PDFResults(PDFTestCaseResultFile));
//							System.out.println("below PDF");
					   GlobalVariables.configMap.put(testConfig.getCurrentTestCase()+testConfig.getPlatForm()+testConfig.getBrowser()+testConfig.getThread(), testConfig);
								}
								k++;
								
							}
						}
						j++;
					}
				}
				i++;
			}//outer while
			
//			IMobileDevice device=null;
//			MobileDriver perfectodriver = null;
//			DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
//			testConfig.setPerfectodriver(new MobileDriver("wf.perfectomobile.com","soumen.mondal@wellsfargo.com", "Wells#13",desiredCapabilities));
//			testConfig.setDevice(testConfig.getPerfectodriver().getDevice(testConfig.getBrowser()));
			
			testConfigMainThread.setCraftHtmlSummaryStartCount(Util.getLastsetTimeinmili());
			executor = Executors.newFixedThreadPool(Integer.parseInt(Util.getValue("ThreadPool", "")));
			System.out.println("Multi");
			
			System.out.println("Number of Test cases===>"+(GlobalVariables.configMap.size()-1));
			System.out.println();
			for (String key : GlobalVariables.configMap.keySet()) 
			{
				if(key!="main" && !(key.contains("Single")))
					
					//executor.submit(new DriverScript(key));
					
					executor.execute(new DriverScript(key));

			}//for
			
	
			executor.shutdown();
			System.out.println("Executor==>"+executor.awaitTermination(Integer.parseInt(Util.getValue("AwaitTermination", "")), TimeUnit.HOURS));
			
			executorsingle = Executors.newFixedThreadPool(1);
			
//			System.out.println("Single");
			
			System.out.println("Number of Test cases===>"+(GlobalVariables.configMap.size()-1));
			System.out.println();
			for (String key : GlobalVariables.configMap.keySet()) 
			{
				if(key!="main" && key.contains("Single"))
					
					executorsingle.submit(new DriverScript(key));

			}//for
			
	
			executorsingle.shutdown();
//			System.out.println("Executor Single==>"+executorsingle.awaitTermination(Integer.parseInt(Util.getValue("AwaitTermination", "")), TimeUnit.HOURS));
			

			

			//executor.shutdown();
			
			
			CRAFT_Report.closeSummary();
			summaryFlag = true;

		}
		catch (Exception ex)
		{
			System.out.println(ex.toString());
			ex.printStackTrace();
		}
		finally
		{
			if(!summaryFlag)
			{
				CRAFT_Report.closeSummary();
				
			}
			if(Util.getValue("killprocess", "").equalsIgnoreCase("true"))
			{
				//Util.killProcess();

			}
			if (Util.debug)
			{
			//	JOptionPane.showMessageDialog(null, path, "", JOptionPane.OK_OPTION);
			}

			System.exit(0);

		}
	}

}


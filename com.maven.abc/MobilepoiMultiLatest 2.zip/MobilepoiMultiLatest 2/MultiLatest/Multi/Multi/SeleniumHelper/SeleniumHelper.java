package SeleniumHelper;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.perfectomobile.httpclient.MediaType;
import com.perfectomobile.selenium.MobileDriver;
import com.perfectomobile.selenium.MobileProxy;
import com.perfectomobile.selenium.api.IMobileDevice;
import com.perfectomobile.selenium.api.IMobileDriver;
import com.perfectomobile.selenium.api.IMobileWebDriver;
import com.perfectomobile.selenium.options.MobileDeviceFindOptions;
import com.perfectomobile.selenium.options.MobileScreenshotOptions;
//import org.openqa.selenium.WebDriverBackedSelenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import SupportLibraries.GlobalVariables;
import SupportLibraries.KeywordImplementation;
import SupportLibraries.Settings;
import SupportLibraries.TestConfigurations;
import SupportLibraries.Util;

import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.Selenium;


public class SeleniumHelper {
	

	public static Wait<IMobileDriver> wait;

	public static AppiumDriver driver1 = null;
	public static IMobileWebDriver driver= null;
//	private volatile boolean value=(Boolean) null;

	protected static org.openqa.selenium.WebElement query;
	
	//properties = Settings.getInstance();
	
	
	
	//properties = Settings.getInstance();

	public static AppiumDriver getappiumdriver(String strBrowser)
	{
		
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try {
			
			String Executionmode=Util.getValue("ExecutionMode", "Perfecto");
			if(Executionmode.trim().toUpperCase().equals("PERFECTO"))
			{
			  
			System.out.println("In launch device");
			//proxy settings
			//MobileProxy proxy = new MobileProxy("proxy.wellsfargo.com", 8080, "soumen.mondal@wellsfargo.com", "Wells#13");
			DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
			//desiredCapabilities.setCapability(CapabilityType.PROXY, proxy);
			testConfig.setPerfectodriver(new MobileDriver("wf.perfectomobile.com","soumen.mondal@wellsfargo.com", "Wells#13",desiredCapabilities));
			System.out.println("In launch device");
			testConfig.setDevice(testConfig.getPerfectodriver().getDevice(strBrowser));
			testConfig.getDevice().open();
			System.out.println("Device Launched");
			Thread.sleep(20000);
			testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver("Wells fargo")
			.open();
			Thread.sleep(10000);
	      //  driver=testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver();
			}
			
			 else if(Executionmode.trim().toUpperCase().equals("APPIUM")){
				 
			//	AppiumDriver driver = null;
					//mobileProperties = Settings.getMobilePropertiesInstance();
				//	String appPath = installApplication(installApp);
					Properties properties = null;
					properties = Settings.getInstance();
					DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
					
						String ExecutionPlatform =testConfig.getPlatForm();
						if (ExecutionPlatform.trim().toUpperCase().equals("ANDROID")) {

							desiredCapabilities.setCapability("platformName", "Android");
							desiredCapabilities.setCapability("deviceName", strBrowser);
							// desiredCapabilities.setCapability("udid",deviceName);
							desiredCapabilities.setCapability("platformVersion", testConfig.getDeviceVersion());
							//desiredCapabilities.setCapability("app", appPath);
							desiredCapabilities.setCapability("appPackage",
									properties.getProperty("Application_Package_Name"));
							desiredCapabilities
									.setCapability("appActivity", properties
											.getProperty("Application_MainActivity_Name"));
							try {
								driver1 = new AndroidDriver(new URL(properties.getProperty("appiumURL")),
										desiredCapabilities);
								
							} catch (MalformedURLException e) {
								e.printStackTrace();
								throw new Exception(
										"The android driver invokation has problem, please re-check the capabilities or Start Appium");
							}
						}
						

							else if (ExecutionPlatform.trim().toUpperCase().equals("IOS")) {

							desiredCapabilities.setCapability("platformName", "ios");
							desiredCapabilities.setCapability("platformVersion", testConfig.getDeviceVersion());
							desiredCapabilities.setCapability("deviceName", strBrowser);
							// desiredCapabilities.setCapability("udid",deviceName);
						//	desiredCapabilities.setCapability("app",properties.getProperty("iPhoneApplicationPath"));
						   desiredCapabilities.setCapability("bundleId", "com.wf.enterprise.ipad");
							desiredCapabilities.setCapability("deviceName", "iPad");
							desiredCapabilities.setCapability("udid", "4c97c642b53a43d35df30169a7c690514f1dbe8f");
						   // cap.setCapability("udid", "6655c1d5-585d-85eb-409b-11f9692520f8f30672ee");
						        
							desiredCapabilities.setCapability("platformVersion", "9.3");
							desiredCapabilities.setCapability("newCommandTimeout", 120);
							try {
								driver1 = new IOSDriver(new URL(properties.getProperty("appiumURL")),
										desiredCapabilities);

							} catch (MalformedURLException e) {
								e.printStackTrace();
								throw new Exception(
										"The IOS driver invokation has problem, please re-check the capabilities or Start Appium");
						   }
					}
		} 
			}catch (Exception ex) {
			System.out.println("NoLaunch for device");
		}
		
		
		return driver1;
	}

	public static IMobileWebDriver getDriver(String strBrowser)
	{
		
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try {
			
			String Executionmode=Util.getValue("ExecutionMode", "Perfecto");
			if(Executionmode.trim().toUpperCase().equals("PERFECTO"))
			{
			  
			System.out.println("In launch device");
			//proxy settings
			MobileProxy proxy = new MobileProxy("proxy.wellsfargo.com", 8080, "soumen.mondal@wellsfargo.com", "Wells#13");
			DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
			desiredCapabilities.setCapability(CapabilityType.PROXY, proxy);
			testConfig.setPerfectodriver(new MobileDriver("wf.perfectomobile.com","soumen.mondal@wellsfargo.com", "Wells#13",desiredCapabilities));
			System.out.println("In launch device");
			testConfig.setDevice(testConfig.getPerfectodriver().getDevice(strBrowser));
			testConfig.getDevice().open();
			System.out.println("Device Launched");
			Thread.sleep(20000);
			testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver("Wells fargo")
			.open();
			Thread.sleep(10000);
	         driver=testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver();
			}
			
			 else if(Executionmode.trim().toUpperCase().equals("APPIUM")){
				 
			//	AppiumDriver driver = null;
					//mobileProperties = Settings.getMobilePropertiesInstance();
				//	String appPath = installApplication(installApp);
					Properties properties = null;
					properties = Settings.getInstance();
					DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
					
						String ExecutionPlatform =testConfig.getPlatForm();
						if (ExecutionPlatform.trim().toUpperCase().equals("ANDROID")) {

							desiredCapabilities.setCapability("platformName", "Android");
							desiredCapabilities.setCapability("deviceName", strBrowser);
							// desiredCapabilities.setCapability("udid",deviceName);
							desiredCapabilities.setCapability("platformVersion", testConfig.getDeviceVersion());
							//desiredCapabilities.setCapability("app", appPath);
							desiredCapabilities.setCapability("appPackage",
									properties.getProperty("Application_Package_Name"));
							desiredCapabilities
									.setCapability("appActivity", properties
											.getProperty("Application_MainActivity_Name"));
							try {
								driver1 = new AndroidDriver(new URL(properties.getProperty("appiumURL")),
										desiredCapabilities);
								
							} catch (MalformedURLException e) {
								e.printStackTrace();
								throw new Exception(
										"The android driver invokation has problem, please re-check the capabilities or Start Appium");
							}
						}
						

							else if (ExecutionPlatform.trim().toUpperCase().equals("IOS")) {

							desiredCapabilities.setCapability("platformName", "ios");
							desiredCapabilities.setCapability("platformVersion", testConfig.getDeviceVersion());
							desiredCapabilities.setCapability("deviceName", strBrowser);
							// desiredCapabilities.setCapability("udid",deviceName);
						//	desiredCapabilities.setCapability("app",properties.getProperty("iPhoneApplicationPath"));
//						   desiredCapabilities.setCapability("bundleId", properties.getProperty("iPhoneBundleID"));
							desiredCapabilities.setCapability("deviceName", "iPhone 6");
							desiredCapabilities.setCapability("udid", "D273A7C7-3E3D-403E-BF7A-447B4E80B44E");
						   // cap.setCapability("udid", "6655c1d5-585d-85eb-409b-11f9692520f8f30672ee");
						        
							desiredCapabilities.setCapability("platformVersion", "9.3");
							desiredCapabilities.setCapability("app", "settings");
							desiredCapabilities.setCapability("newCommandTimeout", 120);
							try {
								driver1 = new IOSDriver(new URL(properties.getProperty("appiumURL")),
										desiredCapabilities);
								driver=(IMobileWebDriver) driver1;

							} catch (MalformedURLException e) {
								e.printStackTrace();
								throw new Exception(
										"The IOS driver invokation has problem, please re-check the capabilities or Start Appium");
						   }
					}
		} 
			}catch (Exception ex) {
			System.out.println("NoLaunch for device");
		}
		
		
		return driver;
		
	}
	
	
	public static Boolean checkDeviceAvailability(MobileDriver driver1, String deviceID)
    {
          Boolean res= false;
          
          MobileDeviceFindOptions findOptions = new MobileDeviceFindOptions();
          List<IMobileDevice> devices = driver1.findDevices(findOptions);
          
      for(IMobileDevice device : devices)
          if (device.getDeviceId().equals(deviceID))
                res =true;
      
          return res;
    }
	
	
	//Function to take screenshot
	
	public static synchronized void takeScreenShot(String path)
	{
			TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
			
			String Executionmode=Util.getValue("ExecutionMode", "Perfecto");
			if(Executionmode.trim().toUpperCase().equals("PERFECTO"))
			{
			
				if (testConfig.getDriver()== null) {
					try {
						throw new Exception("Report.driver is not initialized!");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				File scrFile = null;
				
				try {
				String deviceName = testConfig.getBrowser();
				MobileScreenshotOptions screenshotOptions = new MobileScreenshotOptions();
				scrFile = testConfig.getPerfectodriver().getDevice(deviceName).getScreenshotAs(OutputType.FILE, screenshotOptions);

					} catch (Exception ex) {
						ex.printStackTrace();
					}

				try {
					FileUtils.copyFile(scrFile, new File(path), true);
				} catch (IOException e) {
					e.printStackTrace();
					try {
						throw new Exception(
								"Error while writing screenshot to file");
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}}
				
				
				if(Executionmode.trim().toUpperCase().equals("APPIUM"))
				{
				
					if (testConfig.getDriver1()== null) {
						try {
							throw new Exception("Report.driver is not initialized!");
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					File scrFile1 = null;
					
					try {
					String deviceName = testConfig.getBrowser();
					//MobileScreenshotOptions screenshotOptions = new MobileScreenshotOptions();
					//scrFile1 = testConfig.getPerfectodriver().getDevice(deviceName).getScreenshotAs(OutputType.FILE, screenshotOptions);
					scrFile1=((TakesScreenshot) testConfig.getDriver1()).getScreenshotAs(OutputType.FILE);
					

						} catch (Exception ex) {
							ex.printStackTrace();
						}

					try {
						FileUtils.copyFile(scrFile1, new File(path), true);
					} catch (IOException e) {
						e.printStackTrace();
						try {
							throw new Exception(
									"Error while writing screenshot to file");
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}}
				
				
	}
	
	
	public static void downloadAddtionalReport() {
		
		if (Util.getValue("PerfectoReport", "true").equalsIgnoreCase("true")){
			TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
			Util.downloadReport(testConfig.getPerfectodriver(),testConfig.getPerfectoResultPath()+getFileSeparator()+""+ testConfig.getCurrentTestCase() + "_"+ testConfig.getDevicename() + ".pdf");
		}
	}
	
	public static String getFileSeparator() {
		return System.getProperty("file.separator");
	}

	
	public static void consolidateScreenshotsInWordDoc() {
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		String screenshotsConsolidatedFolderPath = testConfig.getScreenshotsConsolidatedPath();

		WordDocumentManager documentManager = new WordDocumentManager(screenshotsConsolidatedFolderPath, testConfig.getCurrentTestCase() + "_"+ testConfig.getDevicename());

		String screenshotsFolderPath = testConfig.getScreenshotsPath();
		File screenshotsFolder = new File(screenshotsFolderPath);

		FilenameFilter filenameFilter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String fileName) {
				TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
				
				return fileName.contains(testConfig.getCurrentTestCase()+"_"+testConfig.getDevicename());
			}
		};

		File[] screenshots = screenshotsFolder.listFiles(filenameFilter);
		if (screenshots != null && screenshots.length > 0) {
			documentManager.createDocument();

			for (File screenshot : screenshots) {
				documentManager.addPicture(screenshot);
			}
		}
	}
	
	
	
	public static void consolidateScreenshotsInPDF(boolean isMobile) {
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		String screenshotsConsolidatedFolderPath = testConfig.getScreenshotsConsolidatedPath();

		PDFDocumentManager pdfDocument = new PDFDocumentManager(screenshotsConsolidatedFolderPath, testConfig.getCurrentTestCase() + "_"+ testConfig.getDevicename());

		String screenshotsFolderPath = testConfig.getScreenshotsPath();
		File screenshotsFolder = new File(screenshotsFolderPath);

		FilenameFilter filenameFilter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String fileName) {
				TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
				return fileName.contains(testConfig.getCurrentTestCase()+"_"+testConfig.getDevicename());
			}
		};

		File[] screenshots = screenshotsFolder.listFiles(filenameFilter);
		if (screenshots != null && screenshots.length > 0) {
			pdfDocument.createDocument(screenshots, isMobile);
		}

	}
	

	
	
	
	
	
	
	
	
	public  static void CloseDriver()
	{
		
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		
		try
		{
			//Killing driver instance
			if(testConfig.getDriver()!=null)
			{
				testConfig.getDriver().quit();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

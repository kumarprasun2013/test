package SupportLibraries;

import java.io.*;
import java.util.*;
import java.text.*;

import org.openqa.selenium.Platform;
import org.openqa.selenium.os.WindowsUtils;

import Driver.*;
import SeleniumHelper.SeleniumHelper;
import SupportLibraries.CRAFT_Report.Status;
/**
 * Description   : Functional Test Script
 * @author 163497
 */
public class CRAFT_HTMLResults 
{
	public static String SummaryHtmlfile = null;
	static String h1color="";
	static String h2color="";
	static String fontColor="";

	public CRAFT_HTMLResults() {
		// TODO Auto-generated constructor stub
	}

	//#############################################################################
	//Function Name    	: setColorsforResults
	//Description     	: Function to set the rquired colors for results
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	private static synchronized void setColorsforResults()
	{
		String theme = Util.getValue("ReportsTheme", "default");
		if(theme.equals("AUTUMN"))
		{
			h1color="#7E5D56";
			h2color="#EDE9CE";
			fontColor="#F6F3E4";
		}
		else if (theme.equalsIgnoreCase("OLIVE"))
		{
			h1color="#686145";
			h2color="#EDE9CE";
			fontColor="#E8DEBA";
		}
		else if (theme.equalsIgnoreCase("CLASSIC"))
		{
			h1color="#687C7D";
			h2color="#C6D0D1";
			fontColor="#EDEEF0";
		}
		else if (theme.equalsIgnoreCase("RETRO"))
		{
			h1color="#CE824E";
			h2color="#F3DEB1";
			fontColor="#F8F1E7";
		}
		else if (theme.equalsIgnoreCase("MYSTIC"))
		{
			h1color="#4D7C7B";
			h2color="#FFFFAE";
			fontColor="#FAFAC5" ;
		}
		else if (theme.equalsIgnoreCase("SERENE"))
		{
			h1color="#7B597A";
			h2color="#ADE0FF";
			fontColor="#C5AFC6";
		}
		else if (theme.equalsIgnoreCase("REBEL"))
		{
			h1color="#953735";
			h2color="#A6A6A6";
			fontColor="#D9D9D9";

		}
		else if (theme.equalsIgnoreCase("qwe"))
		{
			h1color="#12579D";
			h2color="#BCE1FB";
			fontColor="#FFFFFF" ;
		}
		else
		{
			h1color="#004de6";
			h2color="#004de6";
			fontColor="#8A4117";
		}
	}


	//#############################################################################
	//Function Name    	: createTestCaseHeader
	//Description     	: Function to create the testcase header
	//Input Parameters 	: TestCaseHtmlfile,Screenshotpath
	//Return Value    	: void
	//Author		: 
	//Date Created		: 
	//#############################################################################



	public synchronized static void createTestCaseHeader(String TestCaseHtmlFile,String Screenshotpath)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

		//inc=1;
		testConfig.setCraftHtmlResultInc(1);
		//ScreenShotPath = Screenshotpath;
		//CRAFT_HTMLResults.TestCaseHtmlfile = TestCaseHtmlFile;
		FileOutputStream out; // declare a file output object
		PrintStream p; // declare a print stream object
		setColorsforResults();
		try
		{
			// Create a new file output stream
			// connected to "myfile.txt"
			out = new FileOutputStream(testConfig.getHtmlTestCaseResultFile());

			// Connect print stream to the output stream
			p = new PrintStream( out );

			String header="<html><head><title>Test Case Automation Execution Results</title>";
			header +="</head><Body>"+
					"<p align = center><table border=1 bordercolor=#000000 id=table1 width=1000 height=100 >"+

			"<tr><td COLSPAN = 6 bgcolor = "+h1color+">";
			header+="<p align=center><font color="+fontColor+" size=4 face= Copperplate Gothic Bold>"+testConfig.getCurrentTestCase()+" Automation Execution Results </font><font face= Copperplate Gothic Bold></font> </p>";
			header +="</td></tr>"+
					"<tr>"+
					"<td COLSPAN = 6 bgcolor = "+h1color+">"+
					"<p align=justify><b><font color="+fontColor+"size=2 face= Verdana>DATE:"+ Util.getCurrentDatenTime("dd MMMMM yyyy")+
					"</font></b></p><p align=Left><b><font color="+fontColor+"size=2 face= Verdana>     Device Name =  "+ testConfig.getDevicename()+"||"+"            DeviceID = "+testConfig.getBrowser()   +"</font></b></p>"
					+"<p align=Left><b><font color="+fontColor+"size=2 face= Verdana>     Device version  =  "+ testConfig.getDeviceVersion()+"||"+"      DeviceType = "+testConfig.getDeviceType()   +"||"+"          Platform = "+testConfig.getPlatForm()   +"</font></b></p>"
					+ "</td></tr>";
			
			header+="<tr bgcolor="+h2color+">"+
					"<td><b>Step No</b></td>"+
					"<td><b>Step Name</b></td>"+
					"<td><b>Description	</b></td>"+
					"<td><b>Status</b>	</td>"+
					"<td><b>Time	</b></td>"+
					"</tr>";	

			p.println (header);

			p.close();

			//start = Util.getLastsetTimeinmili();  //Used to calculate the total time taken to execute testcase
			testConfig.setCraftHtmlResultStartCount(Util.getLastsetTimeinmili());
			testConfig.getPDFResult().createPDFTestCaseHeader();
		}
		catch (Exception ex)
		{
			System.err.println ("Error writing to file");
			ex.printStackTrace();
		}
	}

	//#############################################################################
	//Function Name    	: createSummaryHeader
	//Description     	: Function to  create the summary header
	//Input Parameters 	: SummaryHtmlfile
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################
	public synchronized static void createSummaryHeader(String SummaryHtmlFile)
	{
		CRAFT_HTMLResults.SummaryHtmlfile = SummaryHtmlFile;


		FileOutputStream out; // declare a file output object
		PrintStream p; // declare a print stream object
		setColorsforResults();
		String tmpBrowser;
		tmpBrowser = Util.getValue("Browser", "Internet Explorer");
		if((tmpBrowser.toUpperCase()).indexOf("EXPLORE")!= -1)
		{
			tmpBrowser = "(Internet Explorer)";
		}
		else if((tmpBrowser.toUpperCase()).indexOf("FIREFOX")!= -1)
		{
			tmpBrowser = "(Mozilla Firefox)";
		}
		else if((tmpBrowser.toUpperCase()).indexOf("CHROME")!= -1)
		{
			tmpBrowser = "(Google Chrome)";
		}
		else if((tmpBrowser.toUpperCase()).indexOf("SAFARI")!= -1)
		{
			tmpBrowser = "(Apple Safari)";
		}

		try
		{
			// Create a new file output stream
			out = new FileOutputStream(SummaryHtmlfile);

			// Connect print stream to the output stream
			p = new PrintStream( out );
			String header="<html><head><title>Automation Execution Results</title>";
			header +="</head><Body>"+
					"<p align = center><table border=2 bordercolor=#000000 id=table1 width=900 height=31 bordercolorlight=#000000>"+
					"<tr><td COLSPAN = 7 bgcolor = "+h1color+">";
			header+= "<p align=center><font color="+fontColor+" size=4 face= Copperplate Gothic Bold>"+Util.getValue("ProjectName", "CRAFT Project")+" Automation Execution Results "+ "     " +"</font><font face= Copperplate Gothic Bold></font> </p>";
			header +="</td></tr>"+
					"<tr>"+
					"<td COLSPAN = 7 bgcolor = "+h1color+">"+
					"<p align=justify><b><font color="+fontColor+" size=2 face= Verdana>DATE:"+ Util.getCurrentDatenTime("dd MMMMM yyyy 'at' HH:mm:ss") +  
					"<p align=justify><b><font color="+fontColor+" size=2 face= Verdana>No of Threads : "+ Util.getValue("ThreadPool", "1") + 
					"<p align=justify><b><font color="+fontColor+" size=2 face= Verdana>ExecutionMode : "+ Util.getValue("ExecutionMode", "Perfecto") + 
					
					"</td></tr>";
			header+="<tr bgcolor="+h2color+"><td><b>Test Automation Flow</b></td>"+
					"<td><b>Test CaseID</b>	</td>"+
					"<td><b>Description</b>	</td>"+
					"<td><b>Execution Time</b></td>"+
					"<td><b>DeviceName</b></td>"+
					"<td><b>PlatForm</b></td>"+
					"<td><b>Status</b>	</td>"+
					"</tr>";
			

			p.println (header);
			CRAFT_PDFResults.createPDFSummaryHeader();
			p.close();	
		}
		catch (Exception ex)
		{
			System.err.println ("Error writing to file");
			ex.printStackTrace();

		}

	}


	//#############################################################################
	//Function Name    	: addRowtoSummary
	//Description     	: Function to add a row to summary
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		:
	//Date Created	: 
	//#############################################################################

	public  static synchronized void addRowtoSummary()
	{
		BufferedWriter bw = null;
		String row = null;
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		TestConfigurations mainTestConfig= GlobalVariables.getConfigMap().get("main");
		String tmpColor;
		try {
			// bw = new BufferedWriter(new FileWriter(SummaryHtmlfile, true));
			bw = new BufferedWriter(new FileWriter(testConfig.getHtmlResultSummaryFile(), true));
			String status = "";
			//if (Fail>0)
			if(testConfig.getCraftHtmlResultFailCount()>0)
			{
				mainTestConfig.setCraftHtmlResultOverallFailCount(mainTestConfig.getCraftHtmlResultOverallFailCount()+1);
				//overallFail++;
				testConfig.setTestCaseResult("FAIL");
				status = "FAIL";
				tmpColor = "<font color = red><B>";
			}
			//else if (Pass > 0)
			else   if(testConfig.getCraftHtmlResultPassCount()>0)
			{
				//overallPass++;
				mainTestConfig.setCraftHtmlResultOverallPassCount(mainTestConfig.getCraftHtmlResultOverallPassCount()+1);
				testConfig.setTestCaseResult("PASS");
				status = "PASS";
				tmpColor = "<font color = green><B>";
			}
			else
			{
				status = "DONE";
				tmpColor = "<font color = black><B>";
			}
			row = "<tr><td><a href='" + testConfig.getCurrentTestCase()+"_"+testConfig.getDevicename() +".html" + "'" + "target=" + "about_blank" + ">"+testConfig.getCurrentTestCase()+"</a></td><td>"+testConfig.getCurrentTestCaseID()+"</td><td>"+testConfig.getTestCaseDesc()+"</td><td>"+testConfig.getCraftHtmlResultDuration()+"</td><td>"+testConfig.getDevicename()+"</td><td>"+testConfig.getPlatForm()+"</td><td>"+tmpColor+status+"</td></tr>";

			//Pass =0;
			//Fail =0;
			testConfig.setCraftHtmlResultPassCount(0);
			testConfig.setCraftHtmlResultFailCount(0);
			bw.write(row);
			bw.newLine();
			CRAFT_PDFResults.addRowToSummaryResult(testConfig.getCurrentTestCase()+"_"+testConfig.getDevicename(), testConfig.getCurrentTestCaseID(), testConfig.getTestCaseDesc(), testConfig.getCraftHtmlResultDuration(), testConfig.getBrowser(), testConfig.getPlatForm(), status);

		}
		catch (Exception e)
		{

		}
		finally
		{
			try
			{
				bw.close();
			}
			catch (Exception e)
			{

			}
		}
	}

	//#############################################################################
	//Function Name    	: addRowtoTestCase
	//Description     	: Function to add row to testcase
	//Input Parameters 	: strStepName, strDescription,strStatus
	//Return Value    	: None
	//Author		: 
	//Date Created		: 
	//#############################################################################

	public synchronized static void addRowtoTestCase(String strStepName,String strDescription,Status strStatus)
	{
		boolean tempflag = false; 
		String ScreenShotPath1 = "";
		String screenshotName="";
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		testConfig.setCraftHtmlResultInc(testConfig.getCraftHtmlResultInc()+1);
		if (strStatus.equals(Status.PASS))
		{
			//Pass++;
			testConfig.setCraftHtmlResultPassCount(testConfig.getCraftHtmlResultPassCount()+ 1 ) ;
			if(Util.getValue("TakeScreenShotForPass", "").equals("Yes"))
			{
				String devicename = testConfig.getDevicename();
				String tcIteration=String.valueOf(testConfig.getCurrentIteration());
				screenshotName = testConfig.getCurrentTestCase()+"_"+devicename+"_"+tcIteration+"_"+testConfig.getCraftHtmlResultInc()+".png";;
				//ScreenShotPath1 = ScreenShotPath+ "\\"+screenshotName;
				ScreenShotPath1 = testConfig.getScreenshotsPath()+Util.getFileSeparator()+screenshotName;
				SeleniumHelper.takeScreenShot(ScreenShotPath1);
				//inc++;
				testConfig.setCraftHtmlResultInc(testConfig.getCraftHtmlResultInc());
			}
			
		}
		if (strStatus.equals(Status.FAIL))
		{
			//Fail++;
			testConfig.setCraftHtmlResultFailCount(testConfig.getCraftHtmlResultFailCount()+ 1 ) ;
			String devicename = testConfig.getDevicename();
			String tcIteration=String.valueOf(testConfig.getCurrentIteration());
			screenshotName = testConfig.getCurrentTestCase()+"_"+devicename+"_"+tcIteration+"_"+testConfig.getCraftHtmlResultInc()+".png";;
			//ScreenShotPath1 = ScreenShotPath+ "\\"+screenshotName;
			ScreenShotPath1 = testConfig.getScreenshotsPath()+Util.getFileSeparator()+screenshotName;
			SeleniumHelper.takeScreenShot(ScreenShotPath1);
			//inc++;
			testConfig.setCraftHtmlResultInc(testConfig.getCraftHtmlResultInc());
			
		}
		
		
		BufferedWriter bw = null;
		String row = null;
		try {
			int strStepNo = testConfig.getCraftHtmlResultStepNo();
			String timeStamp =null;
			bw = new BufferedWriter(new FileWriter(testConfig.getHtmlTestCaseResultFile(), true));
			// row = "<tr><td>"+DriverScript.iteration+"</td><td>"+DriverScript.subiteration+"</td><td>"+strStepName+"</td><td>"+strDescription+"</td><td>"+strStatus+"</td><td>"+Util.getcurrentdate("H:mm:ss")+"</td></tr>";
			if ((strStepName.toUpperCase()).equals("START COMPONENT")|| (strStepName.toUpperCase()).equals("END COMPONENT"))
			{
				row = "<tr><td bgcolor = #EBDDE2><font color=#7E5D56 size=2 face= Verdana>"+testConfig.getCraftHtmlResultStepNo()+"</td><td bgcolor = #EBDDE2><font color=#7E5D56 size=2 face= Verdana>"+strStepName+"</font></td><td bgcolor = #EBDDE2><font color=#7E5D56 size=2 face= Verdana>"+strDescription+"</font></td>";
				tempflag = true;
			}
			else
			{
				row = "<tr><td>"+testConfig.getCraftHtmlResultStepNo()+"</td><td>"+strStepName+"</td><td>"+strDescription+"</td>";
			}
			// stepNo++;
			testConfig.setCraftHtmlResultStepNo(testConfig.getCraftHtmlResultStepNo()+1);
			if (strStatus.equals(Status.FAIL))
			{
				//int i = DriverScript.subiteration -1;
				int i= (testConfig.getDriverScriptsubIteration())-1;
				//+ DriverScript.testcase +" "+DriverScript.iteration+" "+i+(inc-1)+".jpg" 
				row+="<td><a href='..\\Screenshots\\"+screenshotName+"'"+"target=" + "about_blank" + "><font color = red><b>"+strStatus+"</b></font></a></td>";
			} 
			else if (strStatus.equals(Status.PASS))
			{
				if(Util.getValue("TakeScreenShotForPass", "").equals("Yes"))
				{
					row+="<td><a href='..\\Screenshots\\"+screenshotName+"'"+"target=" + "about_blank" + "><font color = green><b>"+strStatus+"</b></font></a></td>";
				}
				else
				{
					row+="<td><font color = green><b>"+strStatus+"</b></font></td>";
				}
				        		 
			}
			else
			{
				row+="<td><b>"+strStatus+"</b></td>";
			}

			if(tempflag)
			{
				row+="<td bgcolor = #EBDDE2><font color=#7E5D56 size=2 face= Verdana>"+Util.getCurrentDatenTime("H:mm:ss")+"</font></td></tr>";
			}
			else
			{
				timeStamp = Util.getCurrentDatenTime("H:mm:ss");
				row+="<td>"+timeStamp+"</td></tr>";
			}
			bw.write(row);
			bw.newLine();
			testConfig.getPDFResult().createPDFTestCaseRow(strStepName, strDescription, strStatus, strStepNo, timeStamp,ScreenShotPath1);

		}
		catch (Exception e)
		{

		}
		finally
		{
			try
			{
				bw.close();
			}
			catch (Exception e)
			{

			}
		}


	}
	//#############################################################################
	//Function Name    	: insertIteration
	//Description     	: Function to insert Iteration
	//Input Parameters 	: iteration
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public static synchronized void insertIteration(String iteration)
	{
		BufferedWriter bw = null;
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try {
			// bw = new BufferedWriter(new FileWriter(TestCaseHtmlfile, true));
			bw = new BufferedWriter(new FileWriter(testConfig.getHtmlTestCaseResultFile(), true));

			String insertiter=  "<tr><td COLSPAN = 6> <center><b>Iteration: "+ iteration+
					"</b></center></td></tr>";

			bw.write(insertiter);
			// stepNo=1;
			testConfig.setCraftHtmlResultStepNo(1);
			testConfig.getPDFResult().insertIterationToRow(iteration);

		}catch (Exception e)
		{

		}
		finally
		{
			try
			{
				bw.close();
			}
			catch (Exception e)
			{

			}
		}

	}

	//#############################################################################
	//Function Name    	: closeSummary
	//Description     	: Function to close the summary file
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public static synchronized void closeSummary()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get("main");
		testConfig.setCraftHtmlSummaryEndCount(Util.getLastsetTimeinmili());
		long dur=testConfig.getCraftHtmlSummaryEndCount()-testConfig.getCraftHtmlSummaryStartCount();
		BufferedWriter bw = null;
		try {
			// bw = new BufferedWriter(new FileWriter(SummaryHtmlfile, true));
			bw = new BufferedWriter(new FileWriter(testConfig.getHtmlResultSummaryFile(), true));
			String closetags = "";
			//closetags+="<tr><td COLSPAN = 6> <center><B>Total Duration: "+ Util.getFormattedTime(intFinalDuration) +"</B></center></td></tr><tr><center> <B><td COLSPAN = 3> <font color = green>Passed:</font> "+overallPass+"</td><td  COLSPAN = 3><font color = red>Failed:</font> "+overallFail;
			closetags+="<tr><td COLSPAN = 7> <center><B>Actual Duration: "+ Util.getFormattedTime(dur) +"</B></center></td></tr><tr><td COLSPAN = 7> <center><B>Total Duration: "+ Util.getFormattedTime(testConfig.getcraftHtmlResultIntFinalDuration()) +"</B></center></td></tr><tr><center> <B><td COLSPAN = 3> <font color = green>Passed:</font> "+testConfig.getCraftHtmlResultOverallPassCount()+"</td><td  COLSPAN = 3><font color = red>Failed:</font> "+testConfig.getCraftHtmlResultOverallFailCount();
			
			// overallPass =0;
			//overallFail =0;
			//testConfig.setCraftHtmlResultOverallPassCount(0);
			//testConfig.setCraftHtmlResultOverallFailCount(0);

			closetags+="</b></center></td></tr></Table></Body></HTML>";
			bw.write(closetags);
			CRAFT_PDFResults.closeSummaryResult(Util.getFormattedTime(dur), Util.getFormattedTime(testConfig.getcraftHtmlResultIntFinalDuration()), testConfig.getCraftHtmlResultOverallPassCount(), testConfig.getCraftHtmlResultOverallFailCount());
		}
		catch (Exception e)
		{

		}
		finally
		{
			try
			{
				bw.close();
			}
			catch (Exception e)
			{

			}
		}
	}

	//#############################################################################
	//Function Name    	: closeTestCase
	//Description     	: Function to close testcase
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public synchronized static void closeTestCase()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		TestConfigurations mainTestConfig= GlobalVariables.getConfigMap().get("main");
		//end = Util.getLastsetTimeinmili();
		testConfig.setCraftHtmlResultEndCount(Util.getLastsetTimeinmili());
		//long dur = end - start;
		long dur=testConfig.getCraftHtmlResultEndCount()-testConfig.getCraftHtmlResultStartCount();
		mainTestConfig.setcraftHtmlResultIntFinalDuration(mainTestConfig.getcraftHtmlResultIntFinalDuration()+dur);
		testConfig.setCraftHtmlResultDuration( Util.getFormattedTime(dur));

		BufferedWriter bw = null;
		
		try {
			bw = new BufferedWriter(new FileWriter(testConfig.getHtmlTestCaseResultFile(), true));
			String closetags = "";
			//closetags+=  "<tr><td COLSPAN = 6> <center><B>Total Duration: "+ duration
			closetags+=  "<tr><td COLSPAN = 6> <center><b>Total Duration: "+ testConfig.getCraftHtmlResultDuration()
					+"</b></center></td></tr><tr><td COLSPAN = 5 align = right><b><font color = green align = right>PASS:</font>"+ testConfig.getCraftHtmlResultPassCount()+" </b></td></tr><tr><td COLSPAN = 5 align = right><b><font color = red>FAIL:</font> "+  testConfig.getCraftHtmlResultFailCount();
			closetags+="</b></td></tr></Table></p></Body></HTML>";
			bw.write(closetags);
			testConfig.getPDFResult().closePDFTestCase(testConfig.getCraftHtmlResultDuration(), testConfig.getCraftHtmlResultPassCount(), testConfig.getCraftHtmlResultFailCount());
			
		}catch (Exception e)
		{

		}
		finally
		{
			try
			{
				bw.close();
			}
			catch (Exception e)
			{

			}
		}
		
	}
}


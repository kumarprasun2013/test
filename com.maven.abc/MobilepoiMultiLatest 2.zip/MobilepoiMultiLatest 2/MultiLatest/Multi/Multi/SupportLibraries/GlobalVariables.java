package SupportLibraries;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFSheet;

public class GlobalVariables
{
	private static String CurrentScenario=null;
	private static String Currenttestcase=null;
	private static String CurrenttestcaseID=null;
	private static String testcasedesc=null;
	private static int startIteration=1;
	private static int endIteration=1;
	private static int currentIteration=1;
	private static String timestamp=null;
	private static boolean VerificationFlag=true;
//	private static HSSFSheet dbtableSheet = null;
	public static Map<String ,TestConfigurations> configMap=new LinkedHashMap<String,TestConfigurations>() ;
	
	
	
	public static Map<String, TestConfigurations> getConfigMap() {
		return configMap;
	}

	

	public GlobalVariables() 
	{
		VerificationFlag=true;
	}
	
	public static void setCurrentScenario(String Scenario)
	{
		CurrentScenario=Scenario;
	}
	public static String getCurrentScenario()
	{
		return CurrentScenario;
	}
	public static void setCurrenttestcase(String testcase)
	{
		Currenttestcase=testcase;
	}
	public static String getCurrenttestcase()
	{
		return Currenttestcase;
	}
	public static void setCurrenttestcaseID(String testcaseID)
	{
		CurrenttestcaseID=testcaseID;
	}
	public static String getCurrenttestcaseID()
	{
		return CurrenttestcaseID;
	}
	public static void settestcasedesc(String desc)
	{
		testcasedesc=desc;
	}
	public static String gettestcasedesc()
	{
		return testcasedesc;
	}
	public static void setStartIteration(int startItr)
	{
		startIteration=startItr;
	}
	public static int getStartIteration()
	{
		return startIteration;
	}
	public static void setEndIteration(int endItr)
	{
		endIteration=endItr;
	}
	public static int getEndIteration()
	{
		return endIteration;
	}
	public static void setCurrentIteration(int CurrentItr)
	{
		currentIteration=CurrentItr;
	}
	public static int getCurrentIteration()
	{
		return currentIteration;
	}
	public static void setTimestamp(String time)
	{
		timestamp=time;
	}
	public static String getTimestamp()
	{
		return timestamp;
	}
	
	public static void setVerificationFlag(boolean flag)
	{
		VerificationFlag = flag;
	}
	
	public static boolean getVerificationFlag()
	{
		return VerificationFlag;
	}
	

}

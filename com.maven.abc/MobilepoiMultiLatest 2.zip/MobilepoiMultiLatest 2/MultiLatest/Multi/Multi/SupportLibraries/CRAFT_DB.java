package SupportLibraries;
import com.sun.rowset.CachedRowSetImpl;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.ExecutionException;






import SupportLibraries.CRAFT_Report.Status;

import java.lang.reflect.Method;

import javax.sql.rowset.CachedRowSet;
import javax.swing.JOptionPane;

import commonMethods.*;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Description   : Functional Test Script
 * @author 163497
 */
public class CRAFT_DB 
{

	public static String dbpath;

	public CRAFT_DB()
	{

	}

	//#############################################################################
	//Function Name    	: putData
	//Description     	: Function to write output parameters to   test data sheet
	//Input Parameters 	: colName
	//Return Value    	: String
	//Author		: 
	//Date Created	: 
	//#############################################################################
	public static synchronized  void putData(String colName,String strValue) 
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

		//String updateQuery= "UPDATE ["+ sheet +"$] SET "+ colName +"='"+ strValue +"' where TC_ID ='"+ testConfig.getCurrentTestCase() +"'";
		String updateQuery= "UPDATE ["+ testConfig.getDriverScripTestDataSheet() +"$] SET "+ colName +"='"+ strValue +"' where TC_ID ='"+ testConfig.getCurrentTestCase() +"'";
		//+ and Iteration ='"+iterationno+"'";


		putDat(colName, updateQuery);
	}

	//#############################################################################
	//Function Name    	: putDat
	//Description     	: Function to help the putdata function to write output values to testdata sheet.
	//Input Parameters 	: colName, query
	//Return Value    	: StrData
	//Author		: 
	//Date Created	: 
	//#############################################################################
	private static synchronized  void putDat(String colName,String query)
	{

		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

		Statement st1 = null;
		int rowsUpdated;

		try 
		{

			getConnected();
			st1 = testConfig.getConnection().createStatement();
			rowsUpdated= st1.executeUpdate(query);
			//c1.commit();


		}
		catch (SQLException e) 
		{

			//CRAFT_Report.LogInfo("Upadating data to  Datatable", "Testcase : "+testConfig.getCurrentTestCase() +" ColumnName : "+colName+" SubiterationNo : "+subiter +"    Exception : "+e.toString(),Status.Failed_to_update_data);
			CRAFT_Report.LogInfo("Upadating data to  Datatable", "Testcase : "+testConfig.getCurrentTestCase() +" ColumnName : "+colName+" SubiterationNo : "+testConfig.getCraftDbsubIteration() +"    Exception : "+e.toString(),Status.Failed_to_update_data);
			System.out.println(colName +"-"+testConfig.getDriverScripTestDataSheet()+"-"+testConfig.getCurrentTestCase()+"-"+ testConfig.getCraftDbIterationNo());
			e.printStackTrace();

		}
		finally
		{
			try 
			{

				st1.close();
				closeConnection();


			} catch (SQLException e) {

				e.printStackTrace();
			}

		}

	}
	

	//#############################################################################
	//Function Name    	: getConnected
	//Description     	: Function to connect to the database
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################
	private static synchronized void getConnected()
	{
		//closeConnection();

		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

		try {

			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver");
			//c1= java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+dbpath+";READONLY=FALSE");
			testConfig.setConnection(java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+testConfig.getDbDatatablePath()+";READONLY=FALSE"));
		} 
		catch (Exception e) {
			System.out.println(testConfig.getDbDatatablePath());
			e.printStackTrace();

			try {
				//c1.close();
				testConfig.getConnection().close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}

		}


	}
	//#############################################################################
	//Function Name    	: getConnected
	//Description     	: Function to connect to the database
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################
	private static synchronized void getConnected(String dbPath)
	{
		//closeConnection();

		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try {

			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver");
			//c1= java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+dbpath+";READONLY=FALSE");
			testConfig.setConnection(java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+dbPath+";READONLY=FALSE"));
		} 
		catch (Exception e) {
			System.out.println(testConfig.getDbDatatablePath());
			e.printStackTrace();

			try {
				//c1.close();
				testConfig.getConnection().close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}

		}
	}



	//#############################################################################
	//Function Name    	:  closeConnection
	//Description     	: Function to close the connection
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 141950 (Vijay Krishnan Ramaswamy)
	//Date Created		: 31/10/2008
	//#############################################################################
	private static synchronized void closeConnection()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try {
			testConfig.getConnection().close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
	//#############################################################################
	//Function Name    	: executequery
	//Description     	: Function to execute the query
	//Input Parameters 	: query, dbpath
	//Return Value    	: CachedRowSet
	//Author		: 
	//Date Created		: 
	//#############################################################################
	public synchronized static CachedRowSet executeQuery(String query,String dbpath)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		//CRAFT_DB.dbpath=dbpath;
		Statement st1 = null;
		ResultSet rs =null;
		CachedRowSetImpl css=null;
		getConnected();
		try {
			st1 = testConfig.getConnection().createStatement();
			if(Util.debug)
			{
				JOptionPane.showMessageDialog(null, "query = "+query);
			}
			rs= st1.executeQuery(query);
			css= new CachedRowSetImpl();
			css.populate(rs);

		} catch (SQLException e) {

			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return css;
	}
	//#############################################################################
	//Function Name    	: getData
	//Description     	: Function to get the data from the testdata sheet
	//Input Parameters 	: colName
	//Return Value    	: String
	//Author		: 
	//Date Created	: 
	//#############################################################################
	public static synchronized String getData(String colName) 
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
	   HSSFSheet sheet = testConfig.getDbtableSheet();
		CommonMethodsInPOI a = new CommonMethodsInPOI();
	    String query = a.getCellValue(testConfig.getCurrentTestCase(), colName, sheet, testConfig.getCraftDbIterationNo());
		return getDat(colName, query);
	}
	//#############################################################################
	//Function Name    	: getParametrizedData
	//Description     	: Function to get the parametrised  checkpoints from the parametrisedcheckpoint sheet
	//Input Parameters 	: colName
	//Return Value    	: Strdata
	//Author		: 
	//Date Created	: 
	//#############################################################################
	public static synchronized String getParametrizedData(String colName) 
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

		String query = "SELECT "+colName+" FROM ["+testConfig.getCraftDbPSheet()+ "$] where TC_ID ='"+testConfig.getCurrentTestCase()+"' and Iteration ='"+testConfig.getCraftDbIterationNo()+"'";
		return getDat(colName, query);
	}


	//#############################################################################
	//Function Name    	: remtime
	//Description     	: Function to get the remaining time
	//Input Parameters 	: data
	//Return Value    	: StrTime
	//Author		: 
	//Date Created		: 
	//#############################################################################
	private static synchronized String remTime(String data)
	{

		String[] time = data.split(":");
		if (time.length >2)
		{
			int index = data.indexOf(":");
			index = index-2;
			data = data.substring(0,index);
		}

		return data;
	}

	//#############################################################################
	//Function Name    	: getDat
	//Description     	: Function to help the getData function retrieve the data from the testdata sheet
	//Input Parameters 	: colName, query
	//Return Value    	: StrData
	//Author		: 
	//Date Created	: 
	//#############################################################################
	private static synchronized String getDat(String colName,String query)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		String refchar = Util.getValue("DataReferenceIdentifier","#");
		String data = null;
		ResultSet rs =null;
		Statement st1 = null;
		String dbpathbackup = testConfig.getDbDatatablePath();
		try {
			int i =0;
			while (i!=testConfig.getCraftDbsubIteration()-1)
			{
				data=query;
				i++;
			}
			data=query;
			if (data.startsWith(refchar))
			{
				String[] ref = data.split(refchar);
				//dbpath = dbpath.substring(0,dbpath.lastIndexOf("\\"))+ "\\Common Testdata.xls";
				dbpathbackup = dbpathbackup.substring(0,dbpathbackup.lastIndexOf("\\"))+Util.getFileSeparator()+"Common Testdata"+".xls";
				try
				{
				FileInputStream dataTableFile = new FileInputStream(new File(dbpathbackup));
				HSSFWorkbook workbookDataTable = new HSSFWorkbook(dataTableFile);
				HSSFSheet dataSheet = workbookDataTable.getSheet("Common Testdata");
				int rowCount = dataSheet.getLastRowNum();
				CommonMethodsInPOI a = new CommonMethodsInPOI();
				int colIndex = a.getIndex(dataSheet, colName);
				int j=0;			
				data = dataSheet.getRow(1).getCell(colIndex).getStringCellValue();
				
			     }
			
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		//	dbpath = dbpathbackup;
		    }
         }
		catch (Exception e) {

			CRAFT_Report.LogInfo("Fetching Data from Datatable", "Testcase : "+testConfig.getCurrentTestCase() +" ColumnName : "+colName+" SubiterationNo : "+testConfig.getCraftDbsubIteration() +"    Exception : "+e.toString(),Status.Failed_to_fetch_data);

			//S/ystem.out.println(e.toString());
			System.out.println(colName +"-"+testConfig.getDriverScripTestDataSheet()+"-"+testConfig.getCurrentTestCase()+"-"+ testConfig.getCraftDbIterationNo());
			e.printStackTrace();
		}
		return data;
     }
	
}


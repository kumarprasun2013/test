package SupportLibraries;

import io.appium.java_client.AppiumDriver;

import java.sql.Connection;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.openqa.selenium.WebDriver;

import com.perfectomobile.selenium.MobileDriver;
import com.perfectomobile.selenium.api.IMobileDevice;
import com.perfectomobile.selenium.api.IMobileWebDriver;

import SeleniumHelper.SeleniumHelper;

public class TestConfigurations extends SeleniumHelper {

	public IMobileDevice device=null;
	public String DeviceType=null;
	public String Devicename=null;
	public String getDevicename() {
		return Devicename;
	}

	public void setDevicename(String devicename) {
		Devicename = devicename;
	}

	public String getDeviceType() {
		return DeviceType;
	}

	public void setDeviceType(String deviceType) {
		DeviceType = deviceType;
	}

	public String getDeviceVersion() {
		return DeviceVersion;
	}

	public void setDeviceVersion(String deviceVersion) {
		DeviceVersion = deviceVersion;
	}

	public String DeviceVersion=null;
	public IMobileDevice getDevice() {
		return device;
	}

	public void setDevice(IMobileDevice device) {
		this.device = device;
	}
	
	public MobileDriver perfectodriver = null;


	
	public String getScreenshotsConsolidatedPath() {
		return ScreenshotsConsolidatedPath;
	}

	public void setScreenshotsConsolidatedPath(String screenshotsConsolidatedPath) {
		ScreenshotsConsolidatedPath = screenshotsConsolidatedPath;
	}

	public String ScreenshotsConsolidatedPath=null;
	public String CurrentScenario = null;
	public String CurrentTestCase = null;
	public String CurrentTestCaseID = null;
	public String testCaseDesc = null;
	public int startIteration = 1;
	public int endIteration = 1;
	public int currentIteration = 1;
	public int driverScriptsubIteration;
	public int craftDbsubIteration;
	public int craftDbIterationNo;
	public  String craftDbPSheet = null;

	public String timeStamp = null;
	public boolean VerificationFlag = true;
	public String dbDatatablePath = null;
	public String platForm = null;
	public String browser = null;
	public String version = null;
	public String testConfigs = null;
	public String scenario = null;
	public String thread= null;
	public CRAFT_ExcelResults craftExcelObj = null;
	public String HtmlTestCaseResultFile = null;
	public CRAFT_PDFResults pdfResult=null;
	public KeywordImplementation key=null;
	public HSSFSheet dbtableSheet = null;
	public HSSFSheet getDbtableSheet() {
		return dbtableSheet;
	}

	public void setDbtableSheet(HSSFSheet dbtableSheet) {
		this.dbtableSheet = dbtableSheet;
	}

	public KeywordImplementation getKey() {
		return key;
	}

	public void setKey(KeywordImplementation key) {
		this.key = key;
	}

	public String getThread() {
		return thread;
	}

	public void setThread(String thread) {
		this.thread = thread;
	}

	public String resultPath = null;
	public String ExcelResPath = null;
	public String HtmlResPath = null;
	public String ScreenshotsPath = null;
	public String getPerfectoResultPath() {
		return PerfectoResultPath;
	}

	public void setPerfectoResultPath(String perfectoResultPath) {
		PerfectoResultPath = perfectoResultPath;
	}

	public String PerfectoResultPath = null;
	public String HtmlResultSummaryFile = null;
	public String ExcelResultSummaryFile = null;
	public String ExcelTestCaseResultFile = null;

	public  Connection connection=null;
	public  boolean error = false;
	public int craftHtmlResultPassCount = 0;
	public int craftHtmlResultFailCount = 0 ;

	public long craftHtmlResultStartCount = 0;
	public long craftHtmlResultEndCount = 0 ;
	public long craftHtmlSummaryStartCount = 0;
	public long craftHtmlSummaryEndCount = 0 ;

	public String craftHtmlResultDuration ="";
	public int craftHtmlResultOverallPassCount = 0;
	public MobileDriver getPerfectodriver() {
		return perfectodriver;
	}

	public void setPerfectodriver(MobileDriver perfectodriver) {
		this.perfectodriver = perfectodriver;
	}

	public int craftHtmlResultOverallFailCount = 0 ;
	public int craftHtmlResultStepNo = 1;
	public  int craftHtmlResultInc =1;
	public  long craftHtmlResultIntFinalDuration;
	public String driverScriptParameterizedCheckPt;
	public  String[] funParam=null;


	public  String craftExcelResultTestCaseExcelfile=null;
	//Craft Report
	public  boolean craftReportError = false;
	//Selenium helper
	public IMobileWebDriver driver = null;
	public AppiumDriver driver1 = null;
	public AppiumDriver getDriver1() {
		return driver1;
	}

	public void setDriver1(AppiumDriver driver1) {
		this.driver1 = driver1;
	}

	public  org.openqa.selenium.WebElement query;
	public String testCaseResult;
	
	public String getTestCaseResult()
	{
		return testCaseResult;
	}
	public CRAFT_PDFResults getPDFResult()
	{
		return pdfResult;
	}
	public void  setPDfResult(CRAFT_PDFResults pdfResult)
	{
		this.pdfResult = pdfResult;
	}
	public void setTestCaseResult(String testCaseResult) 
	{
		this.testCaseResult = testCaseResult;
	}

	public boolean isCraftReportError() {
		return craftReportError;
	}

	public void setCraftReportError(boolean craftReportError) {
		this.craftReportError = craftReportError;
	}

	public String getCraftExcelResultTestCaseExcelfile() {
		return craftExcelResultTestCaseExcelfile;
	}

	public void setCraftExcelResultTestCaseExcelfile(
			String craftExcelResultTestCaseExcelfile) {
		this.craftExcelResultTestCaseExcelfile = craftExcelResultTestCaseExcelfile;
	}



	public long getCraftHtmlSummaryStartCount() {
		return craftHtmlSummaryStartCount;
	}

	public void setCraftHtmlSummaryStartCount(long craftHtmlSummaryStartCount) {
		this.craftHtmlSummaryStartCount = craftHtmlSummaryStartCount;
	}

	public long getCraftHtmlSummaryEndCount() {
		return craftHtmlSummaryEndCount;
	}

	public void setCraftHtmlSummaryEndCount(long craftHtmlSummaryEndCount) {
		this.craftHtmlSummaryEndCount = craftHtmlSummaryEndCount;
	}
	/*public int getCraftExcelResultPassCount() {
		return craftExcelResultPassCount;
	}

	public void setCraftExcelResultPassCount(int craftExcelResultPassCount) {
		this.craftExcelResultPassCount = craftExcelResultPassCount;
	}

	public int getCraftExcelResultFailCount() {
		return craftExcelResultFailCount;
	}

	public void setCraftExcelResultFailCount(int craftExcelResultFailCount) {
		this.craftExcelResultFailCount = craftExcelResultFailCount;
	}

	public int getCraftExcelResultOverallPassCount() {
		return craftExcelResultOverallPassCount;
	}

	public void setCraftExcelResultOverallPassCount(
			int craftExcelResultOverallPassCount) {
		this.craftExcelResultOverallPassCount = craftExcelResultOverallPassCount;
	}

	public int getCraftExcelResultOverallFailCount() {
		return craftExcelResultOverallFailCount;
	}

	public void setCraftExcelResultOverallFailCount(
			int craftExcelResultOverallFailCount) {
		this.craftExcelResultOverallFailCount = craftExcelResultOverallFailCount;
	}
*/
	/*public long getCraftExcelResultStartCount() {
		return craftExcelResultStartCount;
	}*/

/*	public void setCraftExcelResultStartCount(long craftExcelResultStartCount) {
		this.craftExcelResultStartCount = craftExcelResultStartCount;
	}
	
	public long getCraftExcelResultEndCount() {
		return craftExcelResultEndCount;
	}
	
	public void setCraftExcelResultEndCount(long craftExcelResultEndCount) {
		this.craftExcelResultEndCount = craftExcelResultEndCount;
	}
*/	/*public String getCraftExcelResultDuration() {
		return craftExcelResultDuration;
	}

	public void setCraftExcelResultDuration(String craftExcelResultDuration) {
		this.craftExcelResultDuration = craftExcelResultDuration;
	}*/


	public String[] getFunParam() {
		return funParam;
	}

	public void setFunParam(String[] funParam) {
		this.funParam = funParam;
	}

	public String getCraftDbPSheet() {
		return craftDbPSheet;
	}

	public void setCraftDbPSheet(String craftDbPSheet) {
		this.craftDbPSheet = craftDbPSheet;
	}
	public int getCraftDbIterationNo() {
		return craftDbIterationNo;
	}

	public void setCraftDbIterationNo(int craftDbIterationNo) {
		this.craftDbIterationNo = craftDbIterationNo;
	}

	public int getDriverScriptsubIteration() {
		return driverScriptsubIteration;
	}

	public void setDriverScriptsubIteration(int driverScriptsubIteration) {
		this.driverScriptsubIteration = driverScriptsubIteration;
	}

	public int getCraftDbsubIteration() {
		return craftDbsubIteration;
	}

	public void setCraftDbsubIteration(int craftDbsubIteration) {
		this.craftDbsubIteration = craftDbsubIteration;
	}

	public long getCraftHtmlResultIntFinalDuration() {
		return craftHtmlResultIntFinalDuration;
	}

	public void setCraftHtmlResultIntFinalDuration(
			long craftHtmlResultIntFinalDuration) {
		this.craftHtmlResultIntFinalDuration = craftHtmlResultIntFinalDuration;
	}


	public String driverScripTestDataSheet;
	public String getDriverScripTestDataSheet() {
		return driverScripTestDataSheet;
	}

	public void setDriverScripTestDataSheet(String driverScripTestDataSheet) {
		this.driverScripTestDataSheet = driverScripTestDataSheet;
	}


	public String getDriverScriptParameterizedCheckPt() {
		return driverScriptParameterizedCheckPt;
	}

	public void setDriverScriptParameterizedCheckPt(
			String driverScriptParameterizedCheckPt) {
		this.driverScriptParameterizedCheckPt = driverScriptParameterizedCheckPt;
	}

	public long getcraftHtmlResultIntFinalDuration() {
		return craftHtmlResultIntFinalDuration;
	}

	public void setcraftHtmlResultIntFinalDuration(long craftHtmlResultIntFinalDuration) {
		this.craftHtmlResultIntFinalDuration = craftHtmlResultIntFinalDuration;
	}

	public int getCraftHtmlResultStepNo() {
		return craftHtmlResultStepNo;
	}

	public void setCraftHtmlResultStepNo(int craftHtmlResultStepNo) {
		this.craftHtmlResultStepNo = craftHtmlResultStepNo;
	}

	public int getCraftHtmlResultInc() {
		return craftHtmlResultInc;
	}

	public void setCraftHtmlResultInc(int craftHtmlResultInc) {
		this.craftHtmlResultInc = craftHtmlResultInc;
	}

	public int getCraftHtmlResultOverallPassCount() {
		return craftHtmlResultOverallPassCount;
	}

	public void setCraftHtmlResultOverallPassCount(
			int craftHtmlResultOverallPassCount) {
		this.craftHtmlResultOverallPassCount = craftHtmlResultOverallPassCount;
	}

	public int getCraftHtmlResultOverallFailCount() {
		return craftHtmlResultOverallFailCount;
	}

	public void setCraftHtmlResultOverallFailCount(
			int craftHtmlResultOverallFailCount) {
		this.craftHtmlResultOverallFailCount = craftHtmlResultOverallFailCount;
	}

	public String getCraftHtmlResultDuration() {
		return craftHtmlResultDuration;
	}

	public void setCraftHtmlResultDuration(String craftHtmlResultDuration) {
		this.craftHtmlResultDuration = craftHtmlResultDuration;
	}

	public long getCraftHtmlResultEndCount() {
		return craftHtmlResultEndCount;
	}

	public long getCraftHtmlResultStartCount() {
		return craftHtmlResultStartCount;
	}

	public void setCraftHtmlResultStartCount(long craftHtmlResultStartCount) {
		this.craftHtmlResultStartCount = craftHtmlResultStartCount;
	}

	public void setCraftHtmlResultEndCount(long craftHtmlResultEndCount) {
		this.craftHtmlResultEndCount = craftHtmlResultEndCount;
	}

	public int getCraftHtmlResultFailCount() {
		return craftHtmlResultFailCount;
	}

	public void setCraftHtmlResultFailCount(int craftHtmlResultFailCount) {
		this.craftHtmlResultFailCount = craftHtmlResultFailCount;
	}

	public int getCraftHtmlResultPassCount() {
		return craftHtmlResultPassCount;
	}

	public void setCraftHtmlResultPassCount(int craftHtmlResultPassCount) {
		this.craftHtmlResultPassCount = craftHtmlResultPassCount;
	}

	public boolean getError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}



	public org.openqa.selenium.WebElement getQuery() {
		return query;
	}

	public void setQuery(org.openqa.selenium.WebElement query) {
		this.query = query;
	}

	public  IMobileWebDriver getDriver() {
		return driver;
	}

	public void setDriver(IMobileWebDriver driver) {
		this.driver = driver;
		
	}
	
	

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public String getResultPath() {
		return resultPath;
	}

	public void setResultPath(String resultPath) {
		this.resultPath = resultPath;
	}

	public String getExcelResPath() {
		return ExcelResPath;
	}

	public void setExcelResPath(String excelResPath) {
		ExcelResPath = excelResPath;
	}

	public String getHtmlResPath() {
		return HtmlResPath;
	}

	public void setHtmlResPath(String htmlResPath) {
		HtmlResPath = htmlResPath;
	}

	public String getScreenshotsPath() {
		return ScreenshotsPath;
	}

	public void setScreenshotsPath(String screenshotsPath) {
		ScreenshotsPath = screenshotsPath;
	}

	public String getHtmlResultSummaryFile() {
		return HtmlResultSummaryFile;
	}

	public void setHtmlResultSummaryFile(String htmlResultSummaryFile) {
		HtmlResultSummaryFile = htmlResultSummaryFile;
	}

	public String getExcelResultSummaryFile() {
		return ExcelResultSummaryFile;
	}

	public void setExcelResultSummaryFile(String excelResultSummaryFile) {
		ExcelResultSummaryFile = excelResultSummaryFile;
	}

	public CRAFT_ExcelResults getCraftExcelObj() {
		return craftExcelObj;
	}

	public void setCraftExcelObj(CRAFT_ExcelResults craftExcelObj) {
		this.craftExcelObj = craftExcelObj;
	}

	public String getHtmlTestCaseResultFile() {
		return HtmlTestCaseResultFile;
	}

	public void setHtmlTestCaseResultFile(String htmlTestCaseResultFile) {
		HtmlTestCaseResultFile = htmlTestCaseResultFile;
	}

	public String getExcelTestCaseResultFile() {
		return ExcelTestCaseResultFile;
	}

	public void setExcelTestCaseResultFile(String excelTestCaseResultFile) {
		ExcelTestCaseResultFile = excelTestCaseResultFile;
	}

	public String getCurrentScenario() {
		return CurrentScenario;
	}

	public void setCurrentScenario(String currentScenario) {
		CurrentScenario = currentScenario;
	}

	public String getCurrentTestCase() {
		return CurrentTestCase;
	}

	public void setCurrentTestCase(String currentTestCase) {
		CurrentTestCase = currentTestCase;
	}

	public String getCurrentTestCaseID() {
		return CurrentTestCaseID;
	}

	public void setCurrentTestCaseID(String currentTestCaseID) {
		CurrentTestCaseID = currentTestCaseID;
	}

	public String getTestCaseDesc() {
		return testCaseDesc;
	}

	public void setTestCaseDesc(String testCaseDesc) {
		this.testCaseDesc = testCaseDesc;
	}

	public int getStartIteration() {
		return startIteration;
	}

	public void setStartIteration(int startIteration) {
		this.startIteration = startIteration;
	}

	public int getEndIteration() {
		return endIteration;
	}

	public void setEndIteration(int endIteration) {
		this.endIteration = endIteration;
	}

	public int getCurrentIteration() {
		return currentIteration;
	}

	public void setCurrentIteration(int currentIteration) {
		this.currentIteration = currentIteration;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public boolean isVerificationFlag() {
		return VerificationFlag;
	}

	public void setVerificationFlag(boolean verificationFlag) {
		VerificationFlag = verificationFlag;
	}

	public String getDbDatatablePath() {
		return dbDatatablePath;
	}

	public void setDbDatatablePath(String dbDatatablePath) {
		this.dbDatatablePath = dbDatatablePath;
	}

	public String getPlatForm() {
		return platForm;
	}

	public void setPlatForm(String platForm) {
		this.platForm = platForm;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getTestConfigs() {
		return testConfigs;
	}

	public void setTestConfigs(String testConfigs) {
		this.testConfigs = testConfigs;
	}

	public String getScenario() {
		return scenario;
	}

	public void setScenario(String scenario) {
		this.scenario = scenario;
	}

	public TestConfigurations() {

	}

	public void setTestConfigurations(String configurations) {

		/*String[] strDilimited;
		String[] steKayValues;
		String token = null;
		String tokenValue = null;
		strDilimited = configurations.split(";");
		for (int i = 0; i < strDilimited.length; i++) {
			steKayValues = strDilimited[i].split("=");
			token = steKayValues[0];
			tokenValue = steKayValues[1];
			switch (token) {

			case "Platform":
				this.platForm = tokenValue;
				break;
			case "IE":
				this.browser = tokenValue;
				break;
			case "Version":
				this.version = tokenValue;
				break;
			default:

			}
		}*/

	}

	

}

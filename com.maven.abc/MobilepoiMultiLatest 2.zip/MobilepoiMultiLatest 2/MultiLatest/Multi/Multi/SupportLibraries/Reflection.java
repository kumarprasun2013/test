package SupportLibraries;
import java.lang.reflect.*;
import Driver.DriverScript;
import java.lang.*;
import java.io.*;
import com.thoughtworks.selenium.*;
import SupportLibraries.CRAFT_DB;


public class Reflection 
{
	
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
	}
	@SuppressWarnings("unchecked")
	public static  void execute(String cname,String mname) throws Exception
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		Class cl;
		try {
			cl = Class.forName(cname);
			Object o = cl.newInstance(); 
			String str;
			str=mname;
			String[] temp,temp1 = null;
			String tempnew[] = new String[1];
			String delimiter = "(";
			if (str.toUpperCase().indexOf(delimiter.toUpperCase()) != -1)
			{
				delimiter="\\(";
				temp = str.split(delimiter);
				//mname contains name of function without parameters
				mname=temp[0];
				String tmpstr;
				int tmpcount=0;
				tmpstr = temp[1].substring(0,temp[1].toUpperCase().indexOf(")"));
				if (tmpstr.toUpperCase().indexOf(";")!=-1)
				{
					temp1=tmpstr.split(";");
					
					testConfig.setFunParam(temp1);
				}
				else
				{
					
					tempnew[0]=tmpstr;
					
					testConfig.setFunParam(tempnew);
				}
			
				
				Method m = cl.getDeclaredMethod(mname,null);
				m.invoke(o,null);
				
			}
			else 
			{
				
				
				Method m = cl.getDeclaredMethod(mname,null);
				m.invoke(o,null);
			}
					
			
			}
		catch (Exception e)
		{
			System.out.println(e.toString());
		}
	}
}




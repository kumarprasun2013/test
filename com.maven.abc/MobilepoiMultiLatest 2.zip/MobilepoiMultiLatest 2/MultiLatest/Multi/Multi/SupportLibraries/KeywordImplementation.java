package SupportLibraries;

import io.appium.java_client.TouchAction;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;

import com.perfectomobile.selenium.MobileElement;
import com.perfectomobile.selenium.api.IMobileKeyboard;
import com.perfectomobile.selenium.api.IMobileWebDriver;
//import org.openqa.selenium.WebDriverBackedSelenium;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;
import org.openqa.selenium.support.ui.Wait;

import SeleniumHelper.SeleniumHelper;
import SupportLibraries.CRAFT_Report.Status;

import com.google.common.base.Function;
import com.thoughtworks.selenium.Selenium;
public class KeywordImplementation extends SeleniumHelper
{

	public static String parentWindowHandle;
	public static String parentURL;
	public static String parentBrowser;
//	public static IMobileWebDriver domdriver;

	
	
	 public static void getdomdriver()
		{
		 TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
			testConfig.setDriver(testConfig.getDevice().getDOMDriver());
     	
     	
		}
	 
	 public static void getnativedriver()
		{
		 TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
			testConfig.setDriver(testConfig.getDevice().getNativeDriver());
     	
     	
		}

	/*public enum LocatorType {
	    ID, CLASSNAME, CSSSELECTOR, LINKTEST,
	    NAME, PARTIALLINK, TAGNAME,XPATH 
	}*/
	//====================================================================================================
	// FunctionName    	: getQuery
	// Description     	: Function to get the webElement query from locator
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static   WebElement getQuery(String Locator,String Xpath)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		WebElement webElement = null;
		boolean flagExist=false;
		try
		{
			
			//if(Util.getValue("ExecutionMode", "Perfecto").trim().toUpperCase().equals("PERFECTO")){
			Wait<WebDriver> wait = new FluentWait<WebDriver>(testConfig.getDriver())
					.withTimeout(30, TimeUnit.SECONDS)
					.pollingEvery(5, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class);
		//	}
			
			final String path = Xpath;
			if(Locator.trim().equalsIgnoreCase("ID"))
			{
				webElement = wait.until(new Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver driver) {
						WebElement element =null;							
						element = driver.findElement(By.id(path));
						return element;
					}
				});

			}else if(Locator.trim().equalsIgnoreCase("NAME"))
			{
				webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver driver) {
						WebElement element =null;
						element = driver.findElement(By.name(path));
						return element;
						
					}
				});

			}else if(Locator.trim().equalsIgnoreCase("XPATH"))
			{
				
				webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
					
					public WebElement apply(WebDriver driver) {
						WebElement element=null;
						element =driver.findElement(By.xpath(path));
						return element;
					}
				});
				System.out.println("Web Element's tag is "+webElement.getTagName());

			}else if(Locator.trim().equalsIgnoreCase("LINK"))
			{
				webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver driver) {
						WebElement element = null;
						element = driver.findElement(By.linkText(path));
						return element;
					}
				});

			}else if(Locator.trim().equalsIgnoreCase("PARTIALLINK"))
			{
				webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver driver) {
						WebElement element =null;
						//webElement = driver.findElement(By.partialLinkText(path));
						return driver.findElement(By.partialLinkText(path));
					}
				});

			}
			else if(Locator.trim().equalsIgnoreCase("TAGNAME"))
			{
				webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver driver) {
						WebElement element =null;
						element = driver.findElement(By.tagName(path));
						return element;
					}
				});

			}
			else if(Locator.trim().equalsIgnoreCase("CSS"))
			{
				webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
					public WebElement apply(WebDriver driver) {
						WebElement element = null;
						element = driver.findElement(By.cssSelector(path));
						return element;
					}
				});

			}
			
		}
		catch(Exception e)
		{

		}
		

		return webElement;

	}
	
	//====================================================================================================
		// FunctionName    	: getQuery
		// Description     	: Function to get the webElement query from locator
		// Input Parameter 	: None
		// Return Value    	: 
		// Date Created		: 
		//====================================================================================================
		public static   WebElement getappiumQuery(String Locator,String Xpath)
		{
			TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
			WebElement webElement = null;
			boolean flagExist=false;
			try
			{
				
				//if(Util.getValue("ExecutionMode", "Perfecto").trim().toUpperCase().equals("PERFECTO")){
				Wait<WebDriver> wait = new FluentWait<WebDriver>(testConfig.getDriver1())
						.withTimeout(30, TimeUnit.SECONDS)
						.pollingEvery(5, TimeUnit.SECONDS)
						.ignoring(NoSuchElementException.class);
			//	}
				
				final String path = Xpath;
				if(Locator.trim().equalsIgnoreCase("ID"))
				{
					webElement = wait.until(new Function<WebDriver, WebElement>() {
						public WebElement apply(WebDriver driver) {
							WebElement element =null;							
							element = driver.findElement(By.id(path));
							return element;
						}
					});

				}else if(Locator.trim().equalsIgnoreCase("NAME"))
				{
					webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
						public WebElement apply(WebDriver driver) {
							WebElement element =null;
							element = driver.findElement(By.name(path));
							return element;
							
						}
					});

				}else if(Locator.trim().equalsIgnoreCase("XPATH"))
				{
					
					webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
						
						public WebElement apply(WebDriver driver) {
							WebElement element=null;
							element =driver.findElement(By.xpath(path));
							return element;
						}
					});
					System.out.println("Web Element's tag is "+webElement.getTagName());

				}else if(Locator.trim().equalsIgnoreCase("LINK"))
				{
					webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
						public WebElement apply(WebDriver driver) {
							WebElement element = null;
							element = driver.findElement(By.linkText(path));
							return element;
						}
					});

				}else if(Locator.trim().equalsIgnoreCase("PARTIALLINK"))
				{
					webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
						public WebElement apply(WebDriver driver) {
							WebElement element =null;
							//webElement = driver.findElement(By.partialLinkText(path));
							return driver.findElement(By.partialLinkText(path));
						}
					});

				}
				else if(Locator.trim().equalsIgnoreCase("TAGNAME"))
				{
					webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
						public WebElement apply(WebDriver driver) {
							WebElement element =null;
							element = driver.findElement(By.tagName(path));
							return element;
						}
					});

				}
				else if(Locator.trim().equalsIgnoreCase("CSS"))
				{
					webElement = wait.until(new com.google.common.base.Function<WebDriver, WebElement>() {
						public WebElement apply(WebDriver driver) {
							WebElement element = null;
							element = driver.findElement(By.cssSelector(path));
							return element;
						}
					});

				}
				
			}
			catch(Exception e)
			{

			}
			

			return webElement;

		}
		
	
	
	public static void switchParentWindow()
	{

		driver.switchTo().window(parentBrowser); 
	}


	//====================================================================================================
	// FunctionName    	: Stop Application
	// Description     	: Function to Stop the Application
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================	
	public static  void StopApplication()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			
			String device=testConfig.getBrowser();
			testConfig.getPerfectodriver().getDevice(device).getNativeDriver("Wells fargo").close();			
				if(testConfig.getPerfectodriver()!=null)
				{
					testConfig.getPerfectodriver().quit();
					CRAFT_Report.LogInfo("StopApplication","Device Closed sucessfully ", Status.DONE);
				}
				
			
				
			
			
		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("StopApplication", e.getMessage(), Status.FAIL);
		}

	}
	
	//====================================================================================================
	// FunctionName    	: Stop Application
	// Description     	: Function to Stop the Application
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================	
	public static  void StopappiumApplication()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			
			String device=testConfig.getBrowser();
						
				if(testConfig.getDriver1()!=null)
				{
					testConfig.getDriver1().closeApp();
					testConfig.getDriver1().quit();
					CRAFT_Report.LogInfo("StopApplication","Device Closed sucessfully ", Status.DONE);
				}
				
			
				
			
			
		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("StopApplication", e.getMessage(), Status.FAIL);
		}

	}


	//====================================================================================================
	// FunctionName    	: StartApplication
	// Description     	: Function to Start the Application
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================	
	public  static   void StartApplication(String input)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			String strBrowser=testConfig.getBrowser();
		
				testConfig.setDriver(SeleniumHelper.getDriver(strBrowser)); 
				
				
			
//			testConfig.getDriver().get(input);
			CRAFT_Report.LogInfo("StartApplication",input+ " :application opened sucessfully ", Status.DONE);
		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("StartApplication", e.getMessage(), Status.FAIL);
		}

	}
	
	
	public  static   void StartApplication()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			String strBrowser=testConfig.getBrowser();
		
			if(Util.getValue("ExecutionMode", "Perfecto").trim().toUpperCase().equals("PERFECTO")){
				testConfig.setDriver(SeleniumHelper.getDriver(strBrowser)); 
			}
			
			if(Util.getValue("ExecutionMode", "Perfecto").trim().toUpperCase().equals("APPIUM")){
				testConfig.setDriver1(SeleniumHelper.getappiumdriver(strBrowser)); 
			}
				
				
			CRAFT_Report.LogInfo("StartApplication", "Device opened sucessfully ", Status.DONE);
		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("StartApplication", e.getMessage(), Status.FAIL);
		}

	}
	public  static   void StartApplication(String input,String browser)
	{
		 DesiredCapabilities cap;
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			
			String strBrowser=testConfig.getBrowser();
			String hub=Util.getValue("GridHubAddress", "127.0.0.1");
			if(Util.getValue("killprocess", "").equalsIgnoreCase("true"))
			{
			//	Util.killProcess();

			}
			
				testConfig.setDriver(SeleniumHelper.getDriver(strBrowser)); 
				
				
		
		//	testConfig.getDriver().get(input);
			CRAFT_Report.LogInfo("StartApplication",strBrowser+ " :application opened sucessfully ", Status.DONE);
		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("StartApplication", e.getMessage(), Status.FAIL);
		}

	}
	//====================================================================================================
	// FunctionName    	: Entertext
	// Description     	: Function to Enter text in Element
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================	
	public static  void Entertext(String locatortype,String Xpath,String input,String objname)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			testConfig.setQuery(getQuery(locatortype, Xpath));
			testConfig.getQuery().clear();
			testConfig.getQuery().sendKeys(input.trim()); 
//			if(testConfig.getQuery()..getAttribute("value").equalsIgnoreCase(input))
			CRAFT_Report.LogInfo("Entertext",input+ " :Entered in "+objname, Status.PASS);
		}
		catch(Exception e)
		{
			CRAFT_Report.LogInfo("Entertext", e.getMessage(), Status.FAIL);
		}

	}
	
	
	//====================================================================================================
		// FunctionName    	: Entertext
		// Description     	: Function to Enter text in Element
		// Input Parameter 	: None
		// Return Value    	: 
		// Date Created		: 
		//====================================================================================================	
		public static  void appiumEntertext(String locatortype,String Xpath,String input,String objname)
		{
			TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
			try
			{
				testConfig.setQuery(getappiumQuery(locatortype, Xpath));
				testConfig.getQuery().clear();
				testConfig.getQuery().sendKeys(input.trim()); 
//				if(testConfig.getQuery()..getAttribute("value").equalsIgnoreCase(input))
				CRAFT_Report.LogInfo("Entertext",input+ " :Entered in "+objname, Status.PASS);
			}
			catch(Exception e)
			{
				CRAFT_Report.LogInfo("Entertext", e.getMessage(), Status.FAIL);
			}

		}
	
	//====================================================================================================
		// FunctionName    	: Entertext
		// Description     	: Function to Enter text in Element
		// Input Parameter 	: None
		// Return Value    	: 
		// Date Created		: 
		//====================================================================================================	
		public static  void EnterPasswordiOS(String input,String objname)
		{
			TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
			try
			{
				IMobileKeyboard keyboard = testConfig.getDevice().getMobileKeyboard();
				keyboard.sendKeys(input.trim()); 
				CRAFT_Report.LogInfo("Entertext",input+ " :Entered in "+objname, Status.PASS);
			}
			catch(Exception e)
			{
				CRAFT_Report.LogInfo("Entertext", e.getMessage(), Status.FAIL);
			}

		}
		
		
		//====================================================================================================
				// FunctionName    	: Entertext
				// Description     	: Function to Enter text in Element
				// Input Parameter 	: None
				// Return Value    	: 
				// Date Created		: 
				//====================================================================================================	
				public static  void EnterUsernameiOS(String input,String objname)
				{
					TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
					try
					{
						IMobileKeyboard keyboard = testConfig.getDevice().getMobileKeyboard();
						keyboard.sendKeys(input.trim()); 
						CRAFT_Report.LogInfo("Entertext",input+ " :Entered in "+objname, Status.PASS);
					}
					catch(Exception e)
					{
						CRAFT_Report.LogInfo("Entertext", e.getMessage(), Status.FAIL);
					}

				}

	//====================================================================================================
	// FunctionName    	: VerifyText
	// Description     	: Function to Verify the Text on Screen of Application
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  boolean VerifyText(String locatortype,String input)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		boolean flag = false;
		boolean VerFlag=true;

		VerFlag = GlobalVariables.getVerificationFlag();
		try
		{
			testConfig.setQuery(getQuery(locatortype, "body"));
			//driver.getPageSource().contains(input);
			String BodyContent=testConfig.getQuery().getText();
			if(BodyContent.contains(input) & VerFlag)
			{
				CRAFT_Report.LogInfo("VerifyText","Text: " + input + " display on Screen",Status.PASS);
				flag = true;
			}else
			{
				if(VerFlag)
				{
					CRAFT_Report.LogInfo("VerifyText","Text " + input + " not display on Screen",Status.FAIL);

				}
				else
				{
					CRAFT_Report.LogInfo("VerifyText","Text " + input + " not display on Screen",Status.PASS);	
				}

			}

		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("VerifyText", "Object" +" " + input +" " + "not present on Screen", Status.FAIL);

		}
		GlobalVariables.setVerificationFlag(true);
		return flag;
	}


	//====================================================================================================
	// FunctionName    	: Click
	// Description     	: Function to Click any object
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  void Click(String locatortype,String Xpath,String objname)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

		try
		{
			
			//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement element =getQuery(locatortype, Xpath);
			if(element!=null)
			{
			testConfig.setQuery(element);
			WebDriver driver = testConfig.getDriver();
			if(driver instanceof InternetExplorerDriver)
			{
				JavascriptExecutor js = (JavascriptExecutor) driver;
				((JavascriptExecutor)driver).executeScript("arguments[0].click();",  testConfig.getQuery());
				driver = (WebDriver)js;
			}
			else
			{
				testConfig.getQuery().click();
			}
			
			CRAFT_Report.LogInfo("Click","Clicked on: " +objname,Status.PASS);
			}
			else
			{
				CRAFT_Report.LogInfo("Click", "Could not find element "+objname, Status.FAIL);	
			}
		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("Click", e.getMessage(), Status.FAIL);
		}

	}

	
	//====================================================================================================
		// FunctionName    	: Click
		// Description     	: Function to Click any object
		// Input Parameter 	: None
		// Return Value    	: 
		// Date Created		: 
		//====================================================================================================
		public static  void appiumClick(String locatortype,String Xpath,String objname)
		{
			TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

			try
			{
				
				//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement element =getappiumQuery(locatortype, Xpath);
				if(element!=null)
				{
				testConfig.setQuery(element);
				WebDriver driver = testConfig.getDriver1();
				if(driver instanceof InternetExplorerDriver)
				{
					JavascriptExecutor js = (JavascriptExecutor) driver;
					((JavascriptExecutor)driver).executeScript("arguments[0].click();",  testConfig.getQuery());
					driver = (WebDriver)js;
				}
				else
				{
					testConfig.getQuery().click();
				}
				
				CRAFT_Report.LogInfo("Click","Clicked on: " +objname,Status.PASS);
				}
				else
				{
					CRAFT_Report.LogInfo("Click", "Could not find element "+objname, Status.FAIL);	
				}
			}catch(Exception e)
			{
				CRAFT_Report.LogInfo("Click", e.getMessage(), Status.FAIL);
			}

		}
		
		//====================================================================================================
				// FunctionName    	: Click
				// Description     	: Function to Click any object
				// Input Parameter 	: None
				// Return Value    	: 
				// Date Created		: 
				//====================================================================================================
				public static  void appiumadvancedClick(String locatortype,String Xpath,String objname)
				{
					TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

					try
					{
						
						//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						WebElement element =getappiumQuery(locatortype, Xpath);
						if(element!=null)
						{
						testConfig.setQuery(element);
						WebDriver driver = testConfig.getDriver1();
							testConfig.getQuery().click();
							if (element.isDisplayed()){
								
								
								if(testConfig.getPlatForm().trim().toUpperCase().equals("IOS")){
								Point point = element.getLocation();
								Dimension size=element.getSize();
								int tapX = point.getX()+(size.getWidth()/2);
								int tapY = point.getY()+(size.getHeight()/2);
								String originalContext = testConfig.getDriver1().getContext();
								testConfig.getDriver1().context("NATIVE_APP");
								TouchAction action = new TouchAction(testConfig.getDriver1());
								action.tap(tapX, tapY).perform();
								System.out.println("Pass:  " +"The element is  clicked");
								testConfig.getDriver1().context(originalContext);
								Thread.sleep(10000);
								}
								else if(testConfig.getPlatForm().trim().toUpperCase().equals("ANDROID")){
									testConfig.getQuery().click();
									Thread.sleep(10000);
									
								}
					
						CRAFT_Report.LogInfo("Click","Clicked on: " +objname,Status.PASS);
						}
						}
						else
						{
							CRAFT_Report.LogInfo("Click", "Could not find element "+objname, Status.FAIL);	
						}
					}catch(Exception e)
					{
						CRAFT_Report.LogInfo("Click", e.getMessage(), Status.FAIL);
					}

				}

	
	public static void jsClick(String locatortype,String Xpath,String objname,String...args)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			testConfig.setQuery(getQuery(locatortype, Xpath));
			WebDriver driver = testConfig.getDriver();
			
			if(testConfig.getQuery()==null){
				CRAFT_Report.LogInfo("Click",objname+" does not exist or is hidden", Status.FAIL,args);
			}
			else{
				


						JavascriptExecutor js = (JavascriptExecutor) driver;
						((JavascriptExecutor)driver).executeScript("arguments[0].click();",  testConfig.getQuery());
						js =null;
					
					CRAFT_Report.LogInfo("Click","Clicked on: " +objname,Status.DONE);
				}

			
			
		}

		catch(Exception e){
			if(e instanceof StaleElementReferenceException)
			{
				CRAFT_Report.LogInfo("Element Existence error", "the element no longer appears on the page.", Status.FAIL,args);
			}
		}	
	}
	
	
	//====================================================================================================
	// FunctionName    	: ClickPopup
	// Description     	: Function to Click any object and handle the popup that appears
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  void ClickPopup(String locatortype,String Xpath,String objname,String PopupAction)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			testConfig.setQuery(getQuery(locatortype, Xpath));
			if (Util.getValue("Browser", "firefox").equalsIgnoreCase("IE"))
			{
				JavascriptExecutor js = (JavascriptExecutor) testConfig.getDriver();
				((JavascriptExecutor)testConfig.getDriver()).executeScript("arguments[0].click();",  testConfig.getQuery());
				CRAFT_Report.LogInfo("Click","Clicked on: " +objname,Status.DONE);

			}
			else
			{
				testConfig.getQuery().click();
				CRAFT_Report.LogInfo("Click","Clicked on: " +objname,Status.DONE);

			}

			try
			{
				//To handle pop up
				Alert alert = testConfig.getDriver().switchTo().alert();
				String str=alert.getText();
				if(PopupAction.contains("Accept"))
				{
					alert.accept();
					CRAFT_Report.LogInfo("Popup",str+": Popup accepted"+"", Status.DONE);
				}
				if(PopupAction.contains("Dismiss"))
				{
					alert.dismiss();
					CRAFT_Report.LogInfo("Popup",str+": Popup Dismissed"+"", Status.DONE);
				}
			}
			catch(Exception e)
			{}

			//Code to handle the synchronization in page
			JavascriptExecutor js = (JavascriptExecutor) testConfig.getDriver();
			String str;
			try
			{
				do
				{
					Thread.sleep(1000);
					str=(String) js.executeScript("return document.readyState");
				}while(!str.equals("complete"));
			}catch(Exception e)
			{

			}

			//query.sendKeys(Keys.ENTER);

		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("Click", e.getMessage(), Status.FAIL);
		}
	}
	//====================================================================================================
	// FunctionName    	: VerifyElement
	// Description     	: Function to Verify the Element/Object on Screen of Application
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  boolean VerifyElement(String locatortype,String Xpath,String objname)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		boolean flag = false;
		boolean VerFlag=true;
		VerFlag = GlobalVariables.getVerificationFlag();
		try
		{
			testConfig.setQuery(getQuery(locatortype, Xpath));
			WebElement element = testConfig.getQuery();
            if(element==null ){
                if(VerFlag==false)
                {
                       CRAFT_Report.LogInfo("Verify Element",objname+ ":  is not present on Screen ,ideally should not be on screen", Status.PASS);
                       flag=true;
                }
                else
                {
                       CRAFT_Report.LogInfo("Verify Element",objname+ ":  is not present on screen,should be on screen", Status.FAIL);
                       flag=false;
                }
          }
          else
          {
                if(VerFlag==false)
                {
                       CRAFT_Report.LogInfo("Verify Element",objname+ ":  is present on Screen ,which is not expected", Status.FAIL);   
                       flag=false;

                }
                else
                {
                       CRAFT_Report.LogInfo("Verify Element",objname+ ":  is present on Screen which is expected", Status.PASS); 
                       flag=true;
                }


          }


			
		}
		catch(Exception e)
		{
			
		}
		GlobalVariables.setVerificationFlag(true);
		return flag;
	}
	
	
	
	
	//====================================================================================================
		// FunctionName    	: VerifyElement
		// Description     	: Function to Verify the Element/Object on Screen of Application
		// Input Parameter 	: None
		// Return Value    	: 
		// Date Created		: 
		//====================================================================================================
		public static  boolean appiumVerifyElement(String locatortype,String Xpath,String objname)
		{
			TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
			boolean flag = false;
			boolean VerFlag=true;
			VerFlag = GlobalVariables.getVerificationFlag();
			try
			{
				testConfig.setQuery(getappiumQuery(locatortype, Xpath));
				WebElement element = testConfig.getQuery();
	            if(element==null ){
	                if(VerFlag==false)
	                {
	                       CRAFT_Report.LogInfo("Verify Element",objname+ ":  is not present on Screen ,ideally should not be on screen", Status.PASS);
	                       flag=true;
	                }
	                else
	                {
	                       CRAFT_Report.LogInfo("Verify Element",objname+ ":  is not present on screen,should be on screen", Status.FAIL);
	                       flag=false;
	                }
	          }
	          else
	          {
	                if(VerFlag==false)
	                {
	                       CRAFT_Report.LogInfo("Verify Element",objname+ ":  is present on Screen ,which is not expected", Status.FAIL);   
	                       flag=false;

	                }
	                else
	                {
	                       CRAFT_Report.LogInfo("Verify Element",objname+ ":  is present on Screen which is expected", Status.PASS); 
	                       flag=true;
	                }


	          }


				
			}
			catch(Exception e)
			{
				
			}
			GlobalVariables.setVerificationFlag(true);
			return flag;
		}
	//====================================================================================================
	// FunctionName    	: Waitforpageload
	// Description     	: Function to Wait for page to load
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  void Waitforpageload(int input)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			testConfig.getDriver().manage().timeouts().implicitlyWait(input, TimeUnit.SECONDS);
			//selenium.waitForPageToLoad(input);
			CRAFT_Report.LogInfo("Waitforpageload","Page load wait for "+input+ "", Status.DONE);
		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("Waitforpageload", e.getMessage(), Status.FAIL);
		}
	}

	//====================================================================================================
	// FunctionName    	: SelectList
	// Description     	: Function to Select the Label in List
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  void SelectList(String locatortype,String Xpath,String input,String objname)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			
			WebElement query = getQuery(locatortype, Xpath);
			if(query==null){
				CRAFT_Report.LogInfo("Verify Drop down list box",input+" does not exist or is hidden", Status.FAIL);
			}
			else
			{

				Select comboBox = new Select(query);
				boolean matchFlag=false;
				try
				{
					comboBox.selectByVisibleText(input.trim());
					matchFlag=true;
				}
				catch(Exception e)
				{
					List<WebElement> options  = comboBox.getOptions();
					for(int i=0;i<options.size();i++)
					{
						WebElement option = options.get(i);
						if(option.getText().trim().equals(input))
						{
							comboBox.selectByIndex(i);
							matchFlag=true;
							break;
						}
					}
					
					
					
				}
				if(matchFlag)
				{
					CRAFT_Report.LogInfo("Select List",input+ ": option selected from "+objname, Status.DONE);
				}
				else
				{
					CRAFT_Report.LogInfo("Select List","Option "+input+" not listed or matching other options in the list "+objname, Status.FAIL);
				}

			}
		}catch(Exception e)
		{
			if(e instanceof UnexpectedTagNameException)
			{
				CRAFT_Report.LogInfo("Select List", objname+" is not a SELECT", Status.FAIL);
			}

		}
	}
	//====================================================================================================
	// FunctionName    	: VerifySelectListItems
	// Description     	: Function to Select the Label in List
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  boolean VerifySelectListItems(String locatortype,String Xpath,String input,String objname)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		boolean flag=false;
		boolean VerFlag=true;
		//verFlag false means checking for negative scenario
		VerFlag = GlobalVariables.getVerificationFlag();
		try
		{
			testConfig.setQuery(getQuery(locatortype, Xpath));
			List<WebElement> options = testConfig.getQuery().findElements(By.tagName("option"));
			for(WebElement option : options){
				if(option.getText().equals(input)) {
					flag= true;
					break;
				}
			}
			if(flag & VerFlag)
			{
				CRAFT_Report.LogInfo("VerifySelectListItems",input+ " :element is present in "+objname, Status.PASS);	
			}else
			{
				if(VerFlag)
				{
					CRAFT_Report.LogInfo("VerifySelectListItems",input+ " :element is not present in "+objname, Status.FAIL);	
				}else
				{
					CRAFT_Report.LogInfo("VerifySelectListItems",input+ " :element is not present in "+objname, Status.PASS);
				}

			}

		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("VerifySelectListItems", "SelectList" +" " + objname +" " + "not present ", Status.FAIL);
			flag = false;

		}
		GlobalVariables.setVerificationFlag(true);
		return flag;

	}


	//====================================================================================================
	// FunctionName    	: GetText
	// Description     	: Function to get Text
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static   String GetText(String locatortype,String Xpath,String objname)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		String text="";
		try
		{

			testConfig.setQuery(getQuery(locatortype, Xpath));
			text=testConfig.getQuery().getText();
			if(objname.equalsIgnoreCase("Do not log"))
			{}
			else
			{
				CRAFT_Report.LogInfo("GetText",text + " : fetched  from "+objname, Status.DONE);
			}

		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("GetText", e.getMessage(), Status.FAIL);
		}
		return text;
	}


	//====================================================================================================
	// FunctionName    	: GetAttributeValue
	// Description     	: Function to get Text
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		:
	//====================================================================================================
	public static  String GetAttributeValue(String locatortype,String Xpath,String attribute,String objname)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		String text="";
		try
		{

			testConfig.setQuery(getQuery(locatortype, Xpath));
			text=testConfig.getQuery().getAttribute(attribute.trim());

			CRAFT_Report.LogInfo("GetAttributeValue",text+ "fetched  from :"+objname, Status.DONE);

		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("GetAttributeValue", e.getMessage(), Status.FAIL);
		}
		return text;
	}
	//====================================================================================================
	// FunctionName    	: switchWindow
	// Description     	: Function to switch the focus to other window/page
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  void switchWindow(String urlContent, String windowName)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			WebDriver driver = testConfig.driver;
		parentWindowHandle = driver.getWindowHandle();
		Set<String> handlers = driver.getWindowHandles();  
		boolean winPresent=false;
		if (driver.getWindowHandles().size()>= 1)
		{  
			for(String handler : handlers)
			{  
				driver.switchTo().window(handler);  
				if(driver.getTitle().contains(windowName))
				{

					CRAFT_Report.LogInfo("switchWindow", "Window switch to "+windowName, Status.DONE);
					if(driver instanceof FirefoxDriver)
					{
						driver.manage().window().maximize();
					}
					winPresent=true;
					break;   
				}
			}  
			if(!winPresent)
			{
				CRAFT_Report.LogInfo("switchWindow", "Window "+windowName+" not present", Status.FAIL);
			}
		}  
		else CRAFT_Report.LogInfo("switchWindow", "Window "+windowName+" not present", Status.FAIL);
		}
		catch(Exception e)
		{
			CRAFT_Report.LogInfo("switchWindow", "Window switch to "+windowName, Status.DONE);
		}
	}


	public static  void switchToParentWindow()
	{

		KeywordImplementation.getMultiThreadDriver().switchTo().window(parentWindowHandle); 
	}

	//====================================================================================================
	// FunctionName    	: switchWindowTittle
	// Description     	: Function to switch the focus to other window/page
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  void switchWindowTittle(String tittle, String windowName)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

		Set<String> handlers = testConfig.getDriver().getWindowHandles();  
		if (testConfig.getDriver().getWindowHandles().size()>= 1)
		{  
			for(String handler : handlers)
			{  
				testConfig.getDriver().switchTo().window(handler);  
				if (testConfig.getDriver().getTitle().contains(tittle))
				{  

					CRAFT_Report.LogInfo("switchWindow", "Window switch to "+windowName, Status.DONE);
					break;  
				}  
			}  
		}  
		else CRAFT_Report.LogInfo("switchWindow", "Window "+windowName+" not present", Status.FAIL);
	}
	//====================================================================================================
	// FunctionName    	: verifyAllLinks
	// Description     	: Function to verify the link on screen
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  void verifyAllLinks(String[] linkArr)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		List<WebElement> anchorsinTD=testConfig.getDriver().findElements(By.xpath("//a[parent::td]"));
		List<WebElement> anchors = testConfig.getDriver().findElements(By.tagName("a"));
		Iterator<WebElement> i = anchors.iterator();
		List<String> anchorText = new ArrayList<String>();
		while(i.hasNext())
		{
			WebElement anchor = i.next();
			//ignore invisible and disabled links
			if(anchor.isDisplayed() && anchor.isEnabled()) 
			{
				anchorText.add(anchor.getText());
			}
		}
		for(int arrCount=0;arrCount<linkArr.length;arrCount++)
		{
			boolean linkCheckFlag =false;
			for (int listCounter = 0; listCounter < anchorText.size(); listCounter++)
			{
				if(anchorText.get(listCounter).trim().equalsIgnoreCase(linkArr[arrCount]))
				{
					linkCheckFlag=true;
					break;
				}
			}
			if(linkCheckFlag)
			{
				CRAFT_Report.LogInfo("PensionDynamics",linkArr[arrCount]+"Link Verification", Status.PASS);
			}
			else
			{
				CRAFT_Report.LogInfo("PensionDynamics",linkArr[arrCount]+"Link Verification", Status.FAIL);
			}
		}
	}

	//====================================================================================================
	// FunctionName    	: HandleHttpLinkIE
	// Description     	: Function to Handle the Https link in InternetExplorer
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  void HandleHttpLinkIE()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		if (Util.getValue("Browser", "firefox").equalsIgnoreCase("IE"))
		{
			testConfig.getDriver().navigate().to("javascript:document.getElementById('overridelink').click()");
		}
	}

	//====================================================================================================
	// FunctionName    	:HandleAuthenticationAlert
	// Description     	: Function to Handle Authentication Alert
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static  void HandleAuthenticationAlert(){
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try{
			//driver = ((WrapsDriver) selenium).getWrappedDriver();
			if(testConfig.getDriver().switchTo().alert()!=null){
				testConfig.getDriver().switchTo().alert(). accept();
				WebElement alert = testConfig.getDriver().switchTo().activeElement();
				Thread.sleep(5000);
				alert.sendKeys("u173451");
				Thread.sleep(5000);
				alert.sendKeys(Keys.TAB);
				Thread.sleep(5000);
				alert.sendKeys("Jun$2012");
				Thread.sleep(5000);
				testConfig.getDriver().switchTo().alert().accept();
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}

	}

	public  static  Hashtable getTestData(String data,Hashtable ht)
	{
		Hashtable testData;
		if(ht==null)
		{
			testData=new Hashtable();
		}
		else
		{
			testData=ht;

		}
		String[] strDilimited;
		String[] steKayValues;
		strDilimited=data.split(";");
		for(int i=0;i<strDilimited.length;i++)
		{
			steKayValues=strDilimited[i].split("=");
			if(steKayValues[1].contains("Loan"))
			{

				System.out.println("Loan found in ");
			}
			testData.put(steKayValues[0],steKayValues[1]);	
		}

		return testData;
	}

	//	$$$$$$$$$$$$$$$$$$
	public  static   Hashtable getTestData(String data)
	{

		Hashtable  testData=new Hashtable();


		String[] strDilimited;
		String[] steKayValues;
		strDilimited=data.split(";");
		for(int i=0;i<strDilimited.length;i++)
		{
			steKayValues=strDilimited[i].split("=");
			if(steKayValues[1].contains("Loan"))
			{

				System.out.println("Loan found in ");
			}
			testData.put(steKayValues[0],steKayValues[1]);	
		}

		return testData;
	}
	//====================================================================================================
	// FunctionName    	:CheckList
	// Description     	: Function to Select the Label in List
	// Input Parameter 	: None
	// Return Value    	: 
	// Date Created		: 
	//====================================================================================================
	public static   void CheckList(String locatortype,String Xpath,ArrayList<String> arr,String objname)
	{  
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		boolean flag = false;
		ArrayList<String> listValues=new ArrayList();
		try
		{
			if (Util.getValue("Browser", "firefox").equalsIgnoreCase("IE")||Util.getValue("Browser", "firefox").equalsIgnoreCase("CHROME"))
			{

				testConfig.setQuery(getQuery(locatortype, Xpath));
				Select comboBox = new Select(testConfig.getQuery());
			}
			else
			{
				testConfig.setQuery(getQuery(locatortype, Xpath));
				List<WebElement> options = testConfig.getQuery().findElements(By.tagName("option"));
				for(WebElement option :options)
				{
					listValues.add(option.getText());

				}
				for(int i=0;i<arr.size();i++)
				{


					if(listValues.contains(arr.get(i)))
					{
						CRAFT_Report.LogInfo("checkList", "Element Verifiaction Passed for"+arr.get(i), Status.PASS);
					}
					else
					{
						CRAFT_Report.LogInfo("checkList", "Element Verifiaction Failed for"+arr.get(i), Status.FAIL);
					}
				}
			}	


		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("checkList", e.getMessage(), Status.FAIL);
		}

	}

	//====================================================================================================
	// FunctionName    	:getBackedSelenium
	// Description     	: Function to get Selenium object from Webdriver object
	// Input Parameter 	: Webdriver driver
	// Return Value    	: Selenium selenium
	// Date Created		:
	//================================================================================================

	public static  Selenium getBackedSelenium(WebDriver driver)
	{

		Selenium selenium=null;
		try
		{
			selenium = new WebDriverBackedSelenium(driver, "http://www.yoursite.com");
		}

		catch(Exception e)
		{

			CRAFT_Report.LogInfo("getBackedSelenium", e.getMessage(), Status.FAIL);
		}
		return selenium;
	}


	//====================================================================================================
	// FunctionName    	:getWebDriverObject
	// Description     	: Function to get WebDriver object from Selenium object
	// Input Parameter 	: Selenium sel
	// Return Value    	: WebDriver driver
	// Date Created		:
	//================================================================================================

	public static  IMobileWebDriver getWebDriverObject(Selenium  sel)
	{

		IMobileWebDriver driver=null;
		try
		{
			driver = (IMobileWebDriver) ((WebDriverBackedSelenium) sel).getWrappedDriver();

		}

		catch(Exception e)
		{

			CRAFT_Report.LogInfo("getWebDriverObject", e.getMessage(), Status.FAIL);
		}
		return driver;
	}

	public static  void verifyListOptions(String locatortype,String location,String option,String desc)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		try
		{
			testConfig.setQuery(getQuery(locatortype,location));
			List<WebElement> options = testConfig.getQuery().findElements(By.tagName("option"));
			boolean present_flag=false;
			for(WebElement listOption : options)
			{
				if(listOption.getText().equals(option)) 
				{
					present_flag=true;
					CRAFT_Report.LogInfo("Verify list option",option+ ": present in "+desc, Status.DONE);
					break;
				}
			}
			if(present_flag==false)
			{
				CRAFT_Report.LogInfo("Verify list option",option+ ": not present in  "+desc, Status.FAIL);
			}
		}
		catch(Exception e)
		{
			CRAFT_Report.LogInfo("Verify list option",option+ ": not present in  "+desc, Status.FAIL);
		}

	}
	//====================================================================================================
	// FunctionName    	:getMultiThreadDriver
	// Description     	: Function to get WebDriver object
	// Input Parameter 	: 
	// Return Value    	: WebDriver driver
	// Date Created		:
	//================================================================================================
	public static  WebDriver getMultiThreadDriver()
	{
		WebDriver driver=null;
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		driver=testConfig.getDriver();
		return driver;
	}
	//====================================================================================================
	// FunctionName    	:setMultiThreadDriver
	// Description     	: Function to set WebDriver object
	// Input Parameter 	: WebDriver
	// Return Value    	: void
	// Date Created		:
	//================================================================================================
	public static   void setMultiThreadDriver(IMobileWebDriver driver)
	{

		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		testConfig.setDriver(driver);

	}
	
	public static void CheckCheckBox(String value,String checkBoxName) 
	{
		try
		{
			Selenium sel = KeywordImplementation.getBackedSelenium(getMultiThreadDriver());
			sel.check("name="+value);
			sel.isChecked(value);
			if(sel.isChecked(value))
				CRAFT_Report.LogInfo("CheckCheckBox",checkBoxName+ ": Checked Successfully ", Status.PASS);
			else
			
				CRAFT_Report.LogInfo("CheckCheckBox",checkBoxName+ ": did not checked ", Status.FAIL);
		}
		catch(Exception ex)
		{
			
			CRAFT_Report.LogInfo("CheckCheckBox",ex.getMessage(), Status.FAIL);
		}
	}
	//====================================================================================================
		// FunctionName    	:isAlertPresent
		// Description     	: Function is to check Alert is present or not
		// Input Parameter 	: 
		// Return Value    	: boolean
		
		//================================================================================================
	public static boolean isAlertPresent() {
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		boolean statusAlert=false;
		Selenium sel = KeywordImplementation.getBackedSelenium(testConfig.getDriver());
		statusAlert=sel.isAlertPresent();
		return statusAlert;
	}
	
	
	public static void enterPasswordField(String locatortype,String Xpath,String input,String objname)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		WebDriver driver = testConfig.getDriver();
		try
		{
			testConfig.setQuery(getQuery(locatortype, Xpath));
			testConfig.getQuery().clear();
			if(testConfig.getQuery()==null){
				CRAFT_Report.LogInfo("Enter Text",objname+" does not exist or is hidden", Status.FAIL);
			}
			else
			{
				testConfig.getQuery().clear();
				testConfig.getQuery().sendKeys(input.trim()); 
				System.out.println("Input "+input);
				StringBuffer encriptedPassword = new StringBuffer();
				for(int i=1;i<=input.length();i++)
				{
					encriptedPassword.append("*");
				}
				if(testConfig.getQuery().getAttribute("value").equals(input))
				{
					CRAFT_Report.LogInfo("Enter Text",encriptedPassword+":Entered in "+objname, Status.DONE);
				}
				else
				{
					CRAFT_Report.LogInfo("Enter Text",encriptedPassword+ " :Not entered in properly "+objname, Status.FAIL);
				}
			}

		}catch(Exception e)
		{
			CRAFT_Report.LogInfo("Error in entering text", e.getMessage(), Status.FAIL);
		}
	}

	
	
	
	public static void waitForPageLoading()
	{
		while(!isPageLoadingCompleted())
		{
			
		}
	}
	
	 public static void waitforpageloading()
		{
     	try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	public static boolean isPageLoadingCompleted()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		WebDriver driver = testConfig.getDriver();
		String state="loading";
		try
		{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		state = (String)((JavascriptExecutor)driver).executeScript("return document.readyState;");
		System.out.println(state);
		}
		catch(Exception e)
		{
			
		}
		if(state.contains("complete"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public static void waitUntillPageisInteractive()
	{
		while(!isPageInteractive())
		{
			
		}
	}
public static void killDriverObjectIfAny()
	{
		try
		{
			if(driver!=null)
			{
				driver.quit();
				driver =null;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public static boolean isPageInteractive()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		WebDriver driver = testConfig.getDriver();
		String state="loading";
		try
		{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		state = (String)((JavascriptExecutor)driver).executeScript("return document.readyState;");
		System.out.println(state);
		}
		catch(Exception e)
		{
			
		}
		if(state.contains("complete") || state.contains("interactive"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	public static WebElement advancedgetQuery(String Locator,String Xpath)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		WebElement element1 =null;
		WebElement element =null;
		//boolean flagExist=false;
		try
		{
			
			final String path = Xpath;
			
			
			if(Locator.trim().equalsIgnoreCase("XPATH"))
    			{
					
				try
				{
					
//				element =testConfig.getDriver().findElement(By.xpath(path));
					element=testConfig.getDriver().findElementByXPath(path);
				}
				catch(UnhandledAlertException e)
				{
					try
					{
						testConfig.getDriver().switchTo().alert().accept();
						Thread.sleep(3000);
						element = (MobileElement) testConfig.getDriver().findElement(By.xpath(path));
					}
					catch(Exception ee){
						
					}
				}
				
						return element;
				
    			}
			
		}catch(Exception ee){
			
		}
		return element1;
		
	}
	
	 public static void advanceClick(String locatortype,String Xpath,String objname,String...args)
		{

			try
			{
				WebElement query1;

				query1 = advancedgetQuery(locatortype, Xpath);
			
				if(query1==null){
					CRAFT_Report.LogInfo("Click", "Could not find element "+objname, Status.FAIL);	
				}
				else{
					query1.click();

					
					CRAFT_Report.LogInfo("Click","Clicked on: " +objname,Status.PASS);
				

				}
			}

			catch(Exception e){
				if(e instanceof StaleElementReferenceException)
				{
					CRAFT_Report.LogInfo("Click", e.getMessage(), Status.FAIL);
				}
			}
		}
	 
	 public static void advanceEntertext(String locatortype,String Xpath,String input,String objname,String...args)
		{
			try
			{
				WebElement query=null;
				query= advancedgetQuery(locatortype, Xpath);
				if(query==null){
					CRAFT_Report.LogInfo("Enter Text",objname+" does not exist or is hidden", Status.FAIL);
				}
				else
				{
					query.sendKeys(input); 
					if(input.equalsIgnoreCase("") || input.equalsIgnoreCase(null))
						input="---BLANK SPACE---";
					CRAFT_Report.LogInfo("Enter Text",input+ " :Entered in "+objname, Status.PASS);
					System.out.println("Input "+input);
				}

			}catch(Exception e)
			{
				CRAFT_Report.LogInfo("Error in entering text", e.getMessage(), Status.FAIL);
			}

		}
		
		



	
		
	}

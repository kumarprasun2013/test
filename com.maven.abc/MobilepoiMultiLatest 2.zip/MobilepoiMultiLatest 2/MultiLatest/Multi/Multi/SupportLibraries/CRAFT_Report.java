package SupportLibraries;
import java.awt.Dimension;
import java.io.*;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.text.html.HTML;



import Driver.DriverScript;


public class CRAFT_Report
{
	
	public enum Status {
		PASS,FAIL,Failed_to_fetch_data,DONE,WARNING,Failed_to_update_data
	}
	public void testMain(Object[] args) 
	{
		// TODO Insert code here
	}

	//#############################################################################
	//Function Name    	: createSummaryHeader
	//Description     	: Function to create the summary header
	//Input Parameters 	: HtmlSummaryFile,ExcelSummaryFile
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################
	public synchronized static void createSummaryHeader(String HtmlSummaryFile,String ExcelSummaryFile)
	{

		CRAFT_HTMLResults.createSummaryHeader(HtmlSummaryFile);
		//CRAFT_ExcelResults.createSummaryHeader(ExcelSummaryFile);
	}

	//#############################################################################
	//Function Name    	: createTestcaseHeader
	//Description     	: Function to create testcase header
	//Input Parameters 	: HtmlTestcaseFile, ExcelTestCaseFile,ScreenshotPath
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################
	public static synchronized void createTestcaseHeader(String HtmlTestcaseFile,String ExcelTestCaseFile,String ScreenshotPath)
	{
		CRAFT_HTMLResults.createTestCaseHeader(HtmlTestcaseFile,ScreenshotPath);
		//CRAFT_ExcelResults.createTestCaseHeader(ExcelTestCaseFile);
	}

	//#############################################################################
	//Function Name    	: closeTestcaseReportandUpdateSummary
	//Description     	: Function to  close the testcase report and update the summary
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################
	public static synchronized void closeTestcaseReportandUpdateSummary()
	{
		CRAFT_HTMLResults.closeTestCase();
		//CRAFT_ExcelResults.closeTestCase();
		updateSummary();
	}

	//#############################################################################
	//Function Name    	: closeTestcaseReport
	//Description     	: Function to close the testcase report
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################
	public static synchronized void closeTestcaseReport()
	{
		CRAFT_HTMLResults.closeTestCase();
		//CRAFT_ExcelResults.closeTestCase();

	}

	//#############################################################################
	//Function Name    	: updateSummary
	//Description     	: Function to update the summary
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	private synchronized static void updateSummary()
	{
		CRAFT_HTMLResults.addRowtoSummary();
		//CRAFT_ExcelResults.addRowtoSummary();
	}

	//#############################################################################
	//Function Name    	: closeSummary
	//Description     	: Function to close summary
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		:
	//Date Created	: 
	//#############################################################################
	public synchronized static void closeSummary()
	{
		CRAFT_HTMLResults.closeSummary();
		//CRAFT_ExcelResults.closeSummary();
	}

	//#############################################################################
	//Function Name    	: LogInfo, strDescription, strStatus
	//Description     	: Function to LogInfo into the reports
	//Input Parameters 	:  strStepName
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public synchronized static void LogInfo(String strStepName,String strDescription,Status strStatus,String... args)
	{

		//TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		boolean st = true;
		try
		{
			CRAFT_HTMLResults.addRowtoTestCase(strStepName,strDescription,strStatus);
			//CRAFT_ExcelResults.addRowtoTestCase(strStepName, strDescription, strStatus);
			if(strStatus.equals(Status.FAIL)||strStatus.equals(Status.Failed_to_fetch_data))
			{
				st= false;
			}
			//logTestResult(strStepName, st, strDescription);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	//#############################################################################
	//Function Name    	: insertIteration
	//Description     	: Function to insert an Iteration
	//Input Parameters 	: iteration
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################
	public synchronized static void insertIteration(int iteration)
	{
		CRAFT_HTMLResults.insertIteration(((Integer)iteration).toString());
	}

	//#############################################################################
	//Function Name    	: LogError
	//Description     	: Function to Log the Error
	//Input Parameters 	: Errordesc
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public synchronized static void LogError(String Errordesc)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		testConfig.setCraftReportError(true);
		LogInfo("Error",Errordesc,Status.FAIL);
	}

	

	//#############################################################################
	//Function Name    	: closeRep
	//Description     	: Function to close the rep
	//Input Parameters 	: businesscomp
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public static synchronized void closeRep(String businesscomp)
	{
		LogInfo("End Component", "Exiting BusinessComponent:"+businesscomp,Status.DONE);
		closeTestcaseReport();
		String path = Util.homePath;
	}
	
	

}


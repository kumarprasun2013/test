package SupportLibraries;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URL;

import SupportLibraries.CRAFT_Report.Status;

import com.itextpdf.text.Anchor;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class CRAFT_PDFResults {
	
	private String pdfOutputFilePath=null;
	private String htmlFileContent=null;
	private PdfPTable resultTable=null;
	private Document document =null;
	public static String pdfSummaryFile=null;
	public static Document summaryDoc=null;
	public static PdfPTable summaryResultTable=null;
	public static String pdfResultFolderPath=null;
	public CRAFT_PDFResults(String outputFile)
	{
		try
		{
		pdfOutputFilePath = outputFile;
//		System.out.println("PDF Output file "+pdfOutputFilePath);
		File pdfOutputFile =new File(pdfOutputFilePath);
		pdfOutputFile.createNewFile();
		OutputStream file = new FileOutputStream(pdfOutputFile);
		
		document = new Document();
		PdfWriter.getInstance(document, file);
		resultTable=new PdfPTable(5);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public synchronized static void createPDFSummaryHeader()
	{
		try
		{
//			System.out.println("Pdf summary file path is "+pdfSummaryFile);
			File pdfSummaryOutputFile =new File(pdfSummaryFile);
			pdfSummaryOutputFile.createNewFile();
			OutputStream file = new FileOutputStream(pdfSummaryOutputFile);
			summaryDoc = new Document();
			PdfWriter.getInstance(summaryDoc, file);
			summaryResultTable = new PdfPTable(7);
			PdfPCell summaryHeaderRow = new PdfPCell (new Paragraph (Util.getValue("ProjectName", "CRAFT Project")+" Automation Execution Results ",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10)));
			summaryHeaderRow.setColspan(7);
			summaryHeaderRow.setHorizontalAlignment(Element.ALIGN_CENTER);
			summaryHeaderRow.setPadding(10.0f);
			summaryHeaderRow.setBackgroundColor(new BaseColor(140, 221, 8));
			PdfPCell timeDateRow = new PdfPCell (new Paragraph ("Date:"+Util.getCurrentDatenTime("dd MMMMM yyyy")));
			timeDateRow.setColspan(7);
			PdfPCell columnTestCaseFlow = new PdfPCell (new Paragraph ("Test Automation Flow",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			columnTestCaseFlow.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnTestCaseID = new PdfPCell (new Paragraph ("TestCase ID",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			columnTestCaseID.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnDescription = new PdfPCell (new Paragraph ("Description",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			columnDescription.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnExecution = new PdfPCell (new Paragraph ("Execution Time",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			columnExecution.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnBrowser = new PdfPCell (new Paragraph ("DeviceID",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			columnBrowser.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnPlatform = new PdfPCell (new Paragraph ("Platform",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			columnPlatform.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnStatus = new PdfPCell (new Paragraph ("Status",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			columnStatus.setBackgroundColor(new BaseColor(240, 236, 216));
			
			summaryResultTable.addCell(summaryHeaderRow);
			summaryResultTable.addCell(timeDateRow);
			summaryResultTable.addCell(columnTestCaseFlow);
			summaryResultTable.addCell(columnTestCaseID);
			summaryResultTable.addCell(columnDescription);
			summaryResultTable.addCell(columnExecution);
			summaryResultTable.addCell(columnBrowser);
			summaryResultTable.addCell(columnPlatform);
			summaryResultTable.addCell(columnStatus);
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public synchronized static void addRowToSummaryResult(String currentTestCase,String testcaseID,String description,String executionTime,String Browser,String platform,String status)
	{
		try
		{
			Paragraph textStatus = new Paragraph (status,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8));
			if(status.contains("PASS"))
			{
				textStatus.getFont().setColor(BaseColor.GREEN);
			}
			else if(status.contains("FAIL"))
			{
				textStatus.getFont().setColor(BaseColor.RED);
				
			}
			          			     
			Chunk pdfLink = new Chunk(currentTestCase,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8));
			pdfLink.setRemoteGoto(currentTestCase+".pdf", "1");
			Paragraph p = new Paragraph(pdfLink);
			
			PdfPCell columnTestCaseFlow = new PdfPCell (p);
			PdfPCell columnTestCaseID = new PdfPCell (new Paragraph (testcaseID,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			PdfPCell columnDescription = new PdfPCell (new Paragraph (description,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			PdfPCell columnExecution = new PdfPCell (new Paragraph (executionTime,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			PdfPCell columnBrowser = new PdfPCell (new Paragraph (Browser,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			PdfPCell columnPlatform = new PdfPCell (new Paragraph (platform,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			PdfPCell columnStatus = new PdfPCell (textStatus);
			summaryResultTable.addCell(columnTestCaseFlow);
			summaryResultTable.addCell(columnTestCaseID);
			summaryResultTable.addCell(columnDescription);
			summaryResultTable.addCell(columnExecution);
			summaryResultTable.addCell(columnBrowser);
			summaryResultTable.addCell(columnPlatform);
			summaryResultTable.addCell(columnStatus);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static synchronized void closeSummaryResult(String actualDuration,String totalDuration,int passCount, int failCount)
	{
		try
		{
			System.out.println("Total fail is "+failCount);
			PdfPCell cellActualDuration = new PdfPCell (new Paragraph("Actual Duration: "+actualDuration));
			cellActualDuration.setColspan(7);
			cellActualDuration.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cellTotalDuration = new PdfPCell (new Paragraph ("Total Duration: "+totalDuration));
			cellTotalDuration.setColspan(7);
			cellTotalDuration.setHorizontalAlignment(Element.ALIGN_CENTER);
			Paragraph failCountText = new Paragraph ("Fail Count: "+failCount);
			failCountText.getFont().setColor(BaseColor.RED);
			PdfPCell cellFailCount = new PdfPCell (failCountText);
			cellFailCount.setColspan(4);
			
			cellFailCount.setHorizontalAlignment(Element.ALIGN_CENTER);
			Paragraph passCountText = new Paragraph ("Pass Count: "+passCount);
			passCountText.getFont().setColor(BaseColor.GREEN);
			PdfPCell cellPassCount = new PdfPCell (passCountText);
			cellPassCount.setColspan(3);
			PdfPCell test = new  PdfPCell(new Paragraph("Paragph"));
			test.setColspan(4);
			cellFailCount.setHorizontalAlignment(Element.ALIGN_CENTER);
			summaryResultTable.addCell(cellTotalDuration);
			summaryResultTable.addCell(cellActualDuration);
			summaryResultTable.addCell(cellFailCount);
			summaryResultTable.addCell(cellPassCount);
			
			
			summaryDoc.open();
			summaryDoc.add(summaryResultTable);
			summaryDoc.newPage();  
			summaryDoc.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public  void createPDFTestCaseHeader()
	{
		try
		{
			TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
			float[] columnWidths = new float[] {5f, 15f, 40f, 10f,10f};
		
			
			
			PdfPCell headerRow = new PdfPCell (new Paragraph (testConfig.getCurrentTestCase()+" Automation Execution Results"));
			headerRow.setColspan(5);
			headerRow.setHorizontalAlignment(Element.ALIGN_CENTER);
			headerRow.setPadding(10.0f);
			headerRow.setBackgroundColor(new BaseColor(140, 221, 8));
			
			PdfPCell timeDateRow = new PdfPCell (new Paragraph ("Date:"+Util.getCurrentDatenTime("dd MMMMM yyyy")+" Platform:"+testConfig.getPlatForm()+" DeviceID:"+testConfig.getBrowser()));
			timeDateRow.setColspan(5);
			
			PdfPCell columnStepNo = new PdfPCell (new Paragraph ("Step no.",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9)));
			columnStepNo.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnStepName = new PdfPCell (new Paragraph ("Step Name",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9)));
			columnStepName.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnDescription = new PdfPCell (new Paragraph ("Description",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9)));
			columnDescription.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnStatus = new PdfPCell (new Paragraph ("Status",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9)));
			columnStatus.setBackgroundColor(new BaseColor(240, 236, 216));
			PdfPCell columnTime = new PdfPCell (new Paragraph ("Execution time",FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9)));
			columnTime.setBackgroundColor(new BaseColor(240, 236, 216));
			
			resultTable.addCell(headerRow);
			resultTable.addCell(timeDateRow);
			resultTable.addCell(columnStepNo);
			resultTable.addCell(columnStepName);
			resultTable.addCell(columnDescription);
			resultTable.addCell(columnStatus);
			resultTable.addCell(columnTime);
			resultTable.setWidths(columnWidths);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void createPDFTestCaseRow(String strStepName,String strDescription,Status strStatus,int stepNo,String timeStamp,String screenshotPath)
	{
		try
		{
			String status =strStatus.toString();
			Chunk chunk = new Chunk(status);
			if(status.contains("PASS"))
			{
				chunk.setFont(FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.GREEN));
			}
			else if(status.contains("FAIL"))
			{
				chunk.setFont(FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.RED));
				chunk.setRemoteGoto(screenshotPath, "1");
			}
			else
			{
				chunk.setFont(FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8));
			}
			
			
	        Paragraph parStatus = new Paragraph (chunk);
	        parStatus.setFont(FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8));
			PdfPCell cellStepNo = new PdfPCell (new Phrase (String.valueOf(stepNo),FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			PdfPCell cellStepName = new PdfPCell (new Phrase (strStepName,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			PdfPCell cellDescription = new PdfPCell (new Phrase (strDescription,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			PdfPCell cellStatus = new PdfPCell (new Phrase (chunk));
			PdfPCell celltime = new PdfPCell (new Phrase (timeStamp,FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8)));
			
			resultTable.addCell(cellStepNo);
			resultTable.addCell(cellStepName);
			resultTable.addCell(cellDescription);
			resultTable.addCell(cellStatus);
			resultTable.addCell(celltime);
			
				
		}
		catch(Exception e)
		{
			
		}
	}
	public void closePDFTestCase(String duration,int passCount,int failCount)
	{
		try
		{
			PdfPCell cellTotalDuration = new PdfPCell (new Paragraph("Total Duration: "+duration));
			cellTotalDuration.setColspan(5);
			cellTotalDuration.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cellPassCount = new PdfPCell (new Paragraph ("Pass Count: "+passCount));
			cellPassCount.setColspan(5);
			cellPassCount.setHorizontalAlignment(Element.ALIGN_CENTER);
			PdfPCell cellFailCount = new PdfPCell (new Paragraph ("Fail Count: "+failCount));
			cellFailCount.setColspan(5);
			cellFailCount.setHorizontalAlignment(Element.ALIGN_CENTER);
			resultTable.addCell(cellTotalDuration);
			resultTable.addCell(cellPassCount);
			resultTable.addCell(cellFailCount);
			document.open();
			 document.add(resultTable);
	         document.newPage();  
	         document.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void insertIterationToRow(String iteration)
	{
		try
		{
			PdfPCell cellIteration = new PdfPCell (new Paragraph("Iteration-"+iteration));
			cellIteration.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellIteration.setColspan(5);
			resultTable.addCell(cellIteration);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

}

 package SupportLibraries;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

import javax.swing.JOptionPane;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.os.WindowsUtils;
import org.openqa.selenium.remote.Augmenter;

import com.perfectomobile.httpclient.MediaType;
import com.perfectomobile.httpclient.utils.FileUtils;
import com.perfectomobile.selenium.MobileDriver;
import com.perfectomobile.selenium.options.MobileScreenshotOptions;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;


 public class Util 
 {
	
	static Calendar cc = null;
	public static String homePath = "";
	public static Boolean debug = false;
	
	//#############################################################################
	//Function Name    	: SetValue
	//Description     	: Function to set the value for a key in the config file.
	//Input Parameters 	: key,  val
	//Return Value    	: None

	//#############################################################################
	public static synchronized void setValue(String key, String val)
    {
		BufferedReader br = null;
        BufferedWriter bw = null;

        String path = Util.homePath+"\\CRAFT.ini";
        String newpath = path+"1";
        String line = "";
        File f = null;
        File f1 = null;
        try
        {
            f = new File(path);
            f.createNewFile();
            f1 = new File(newpath);
            f1.createNewFile();

            br = new BufferedReader(new FileReader(path));
            bw = new BufferedWriter(new FileWriter(newpath));
            String regex = "=";
            boolean found = false;
            String keyval = key+"="+val;

            while ((line = br.readLine())!=null)
            {
                if (line.trim().length()>0)
                {
                    String[] pairs = line.split(regex);

                    if (pairs[0].trim().equals(key))
                    {
                        bw.newLine();
                        bw.write(keyval);
                        found = true;
                    }
                    else
                    {
                        bw.newLine();
                        bw.write(line);
                    }
                }
            }

            if (!found)
            {
                bw.newLine();
                bw.write(keyval);
            }
        }
        catch (Exception ex)
        {
        }
        finally
        {
            try
            {
                bw.close();
            }
            catch (Exception ex)
            {
            }
            try
            {
                br.close();
            }
            catch (Exception ex)
            {
            }
        }

        try
        {
            //FileCopy(newpath, path);
        }
        catch (Exception ex)
        {
        }
        try
        {
        	f1.delete();
        }
        catch (Exception ex)
        {
        	
        }
    }


    //#############################################################################
	//Function Name    	: GetValue
	//Description     	: Function to get the value from the config file
	//Input Parameters 	: key, def
	//Return Value    	: Value
	
	//#############################################################################
    public static synchronized String getValue(String key, String def)
    {
        BufferedReader br = null;
       // String Browser = null;
    
    	String Path1= null;
		try {
			Path1 = new File(".").getCanonicalPath();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        String path =Path1+Util.getFileSeparator()+"CRAFT.ini";
        if (Util.debug)
        {
//        	System.out.println("get val path="+path+", key = "+key);
        }
        String line = "";
        String val = "";
        Boolean found = false;
        try
        {
            File f = new File(path);
            f.createNewFile();

            br = new BufferedReader(new FileReader(path));

            String regex = "=";

            while ((line = br.readLine())!=null)
            {
                if (line.trim().length()>0)
                {
                    String[] pairs = line.split(regex);

                    if (pairs[0].trim().equals(key))
                    {
                        val = pairs[1];
                        found = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }
        finally
        {
            try
            {
                br.close();
            }
            catch (Exception ex)
            {
            }
            if (!found)
            {
            
                val = def;
                try
                {
                }
                catch (Exception ex)
                {
                }
            }
        }
//System.out.print(val);
        return val;
    }
    
    
    
    
    
  //#############################################################################
  	//Function Name    	: GetValue
  	//Description     	: Function to get the value from the config file
  	//Input Parameters 	: key, def
  	//Return Value    	: Value
  	//#############################################################################
      public static synchronized String getValues(String key, String def)
      {
          BufferedReader br = null;
         // String Browser = null;
      
      	String Path1= null;
  		try {
  			Path1 = new File(".").getCanonicalPath();
  		} catch (IOException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
          String path =Path1+"\\CRAFT.ini";
          if (Util.debug)
          {
          	System.out.println("get val path="+path+", key = "+key);
          }
          String line = "";
          String val = "";
          Boolean found = false;
          try
          {
              File f = new File(path);
              f.createNewFile();

              br = new BufferedReader(new FileReader(path));

              String regex = "=";

              while ((line = br.readLine())!=null)
              {
                  if (line.trim().length()>0)
                  {
                      String[] pairs = line.split(regex);

                      if (pairs[0].trim().equals(key))
                      {
                          val = pairs[1];
                          found = true;
                      }
                  }
              }
          }
          catch (Exception ex)
          {
          }
          finally
          {
              try
              {
                  br.close();
              }
              catch (Exception ex)
              {
              }
              if (!found)
              {
                  val = def;
                  try
                  {
                  	//Util.SetValue(key, def);
                  }
                  catch (Exception ex)
                  {
                  }
              }
          }
  System.out.print(val);
          return val;
      }

    //#############################################################################
	//Function Name    	: FileCopy
	//Description     	: Function to Copy a file
	//Input Parameters 	:  source dest

	//#############################################################################
    public static synchronized  void fileCopy(String source, String dest)
    {
        File inputFile = new File(source);
        File outputFile =  new File(dest);

        FileInputStream in = null;
        FileOutputStream out = null;
        try
        {
        	//new File(source).createNewFile();
        	new File(dest).createNewFile();
            in = new FileInputStream(inputFile);
            out = new FileOutputStream(outputFile);
            int c;

            while ((c = in.read()) != -1)
            {
            	
                out.write(c);
            }
        }
        catch (Exception ex)
        {
        	ex.toString();
        	ex.printStackTrace();
        }

        try
        {
            in.close();
        }
        catch (Exception ex)
        {
        }
        try
        {
            out.close();
        }
        catch (Exception ex)
        {
        }
    }
    

   //#############################################################################
	//Function Name    	: copyDirectory
	//Description     	: Function to copy directory
	//Input Parameters 	:  src,  dest
	//Return Value    	: None
	//#############################################################################
    public static synchronized void copyDirectory(String src, String dest)
    {
    	File[] f = new File(src).listFiles();
    	if (Util.debug)
    	{
    		JOptionPane.showMessageDialog(null, "Inside directorycopy function"+src+" to "+dest, "Message", JOptionPane.OK_OPTION);
    	}
  
    }
    

    //#############################################################################
	//Function Name    	: getCurrentDatenTime
	//Description     	: Function to get Current Date and Time
	//Input Parameters 	: format
	//Return Value    	: Current Time
	//Author		    :
	//Date Created		: 
	//#############################################################################
    public static synchronized String getCurrentDatenTime(String format)
    {
    	Calendar cal = Calendar.getInstance();
    	cc = cal;
    	SimpleDateFormat sdf = new SimpleDateFormat(format);
	    return sdf.format(cal.getTime());
    }
    
    public static synchronized String getFileSeparator() {
		return System.getProperty("file.separator");
	}

   //#############################################################################
	//Function Name    	: getLastsetTimeinmili
	//Description     	: Function to get Last set Time in miliseconds
	//Input Parameters 	: None
	//Return Value    	: Last set Time 
	//#############################################################################
    public static synchronized long getLastsetTimeinmili()
    {
    	return cc.getTimeInMillis();
    }
    

    //#############################################################################
	//Function Name    	: getFormattedTime
	//Description     	: Function to get Formatted Time
	//Input Parameters 	: time
	//Return Value    	: FormattedTime
	//#############################################################################
    public static synchronized String getFormattedTime(long time)
    {
    	long timeMillis = time;   
    	long time1 = timeMillis / 1000;   
    	String seconds = Integer.toString((int)(time1 % 60));   
    	String minutes = Integer.toString((int)((time1 % 3600) / 60));   
    	String hours = Integer.toString((int)(time1 / 3600));   
    	for (int i = 0; i < 2; i++) {   
    	if (seconds.length() < 2) {   
    	seconds = "0" + seconds;   
    	}   
    	if (minutes.length() < 2) {   
    	minutes = "0" + minutes;   
    	}   
    	if (hours.length() < 2) {   
    	hours = "0" + hours;   
    	}   
    	}  
    	return hours+": "+minutes+": "+seconds;

    	/*
    	Calendar cal = Calendar.getInstance();
    	DateFormat d = null;
    	cc = cal;
    	
	    SimpleDateFormat sdf = new SimpleDateFormat(format);
	    d = sdf.getInstance();
	    cal.setTimeInMillis(diff);
	    return sdf.format(cal.getTime());*/
    }

	
	
	
	 //#############################################################################
	//Function Name    	: ReadFlagFile
	//Description     	: Read the Flag test.txt File
	//Input Parameters 	: Path
	//Return Value    	: None
	//#############################################################################
	public static synchronized  boolean ReadFlagFile()
	{
		 BufferedReader br = null;
		 boolean flagValue = false;
		 String path ="C:\\WRS_Automation\\test.txt";
		 try {
			br = new BufferedReader(new FileReader(path));
			flagValue = Boolean.parseBoolean(br.readLine());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		 
		 return flagValue;
	}
	 //#############################################################################
	//Function Name    	: setFlagFile
	//Description     	: Set the Flag false in flag file after using it
	//Input Parameters 	: Path
	//Return Value    	: None
	//#############################################################################
	public static synchronized void setFlagFile()
	{
		BufferedWriter writer = null;
		 String path ="C:\\WRS_Automation\\test.txt";
		 try {
			 writer = new BufferedWriter(new FileWriter(path));
			 writer.write("false");
			 writer.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		 
	}
	 //#############################################################################
	//Function Name    	: GenerateRandom
	//Description     	: function to generate random number
	//Input Parameters 	: range
	//Return Value    	: None
	//#############################################################################
	public static synchronized  BigInteger GenerateRandom(BigInteger range)
	{
			Random rand = new Random();
		    BigInteger result = new BigInteger(range.bitLength(), rand);
		    while( result.compareTo(range) >= 0 ) {
		        result = new BigInteger(range.bitLength(), rand);
		    }
		    return result;
	}
	//#############################################################################
			//Function Name    	: base64encode
			//Description     	: function to encode a String
			//Input Parameters 	: String
			//Return Value    	: Encoded String
			//#############################################################################
		public static synchronized String base64encode(String text)
		   {
			    String DEFAULT_ENCODING="UTF-8"; 
			    BASE64Encoder enc=new BASE64Encoder();
			   
		      try 
		      {
		         String rez = enc.encode( text.getBytes( DEFAULT_ENCODING ) );
		         return rez;         
		      }
		      catch ( Exception e )
		      {
		         return null;
		      }
		   }

		//#############################################################################
				//Function Name    	: base64decode
				//Description     	: function to decode a String
				//Input Parameters 	: String
				//Return Value    	: Decoded String
				//#############################################################################
			
		   public static synchronized String base64decode(String text)
		   {
			   BASE64Decoder dec=new BASE64Decoder();
			   String DEFAULT_ENCODING="UTF-8"; 
		         try 
		         {
		            return new String(dec.decodeBuffer( text ),DEFAULT_ENCODING);
		         }
		         catch ( Exception e )
		         {
		           return null;
		         }

		      }
		
		 //#############################################################################
			//Function Name    	: killProcess
			//Description     	: function to Kill Unwanted processes
			//Input Parameters 	: None
			//Return Value    	: None
			//#############################################################################
		

		   public static synchronized void killProcess()
			{
				
				try
				{
					
				
				String strTaskKill=	WindowsUtils.findTaskKill();
				String strFilter =" /FI ";
				
				String imgnameExcel= "\"IMAGENAME  eq  EXCEL.exe\"";
				String imgnameIE= "\"IMAGENAME  eq  iexplore.exe\"";
				String imgnameFF= "\"IMAGENAME  eq  firefox.exe\"";
				String imgnameChrome= "\"IMAGENAME  eq  chrome.exe\"";
				String imgIeDriver= "\"IMAGENAME  eq  IEDriverServer_32bit.exe\"";
				String imgChromeDriver= "\"IMAGENAME  eq  chromedriver.exe\"";
				String imgSafari= "\"IMAGENAME  eq  Safari.exe\"";
				
				
				
				String killExcel=strTaskKill+strFilter+imgnameExcel;
				String killIE=strTaskKill+strFilter+imgnameIE;
				String killFF=strTaskKill+strFilter+imgnameFF;
				String killIeDriver=strTaskKill+strFilter+imgIeDriver;
				String killChromeDriver=strTaskKill+strFilter+imgChromeDriver;
				String killSafari=strTaskKill+strFilter+imgSafari;
				
				Runtime.getRuntime().exec(killExcel);
				Runtime.getRuntime().exec(killIE);
				Runtime.getRuntime().exec(killFF);
				Runtime.getRuntime().exec(killSafari);
				//Runtime.getRuntime().exec(killIeDriver);
				//Runtime.getRuntime().exec(killChromeDriver);
			    }
				catch (Exception err)
			    {
			        err.printStackTrace();
			    }

				
			}
		   
		   
		 //function to download perfecto report
			
			public static void downloadReport(MobileDriver driver, String pdfReport) {
				
				TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
				try{
								
				InputStream reportStream = testConfig.getPerfectodriver().downloadReport(MediaType.PDF);
				if (reportStream != null) {
					File reportFile = new File(pdfReport);
					try {
						FileUtils.write(reportStream, reportFile);
					} catch (IOException e) {
				
						e.printStackTrace();
					}

				}
				}
				catch(Exception ex){
					ex.printStackTrace();
					try {
						throw new Exception(
								"Failed to download PDF report for Perfecto");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			
	
}


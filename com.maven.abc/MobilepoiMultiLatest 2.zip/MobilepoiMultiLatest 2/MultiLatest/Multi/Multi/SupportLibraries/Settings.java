package SupportLibraries;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;


public class Settings {
	public static Properties properties = loadFromPropertiesFile();

	public static Properties getInstance() {
		return properties;
	}

	public static Properties loadFromPropertiesFile() {
		

		if (Util.homePath == null) {
			try {
				throw new Exception(
						"FrameworkParameters.relativePath is not set!");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		Properties properties = new Properties();

		try {
			properties.load(new FileInputStream(Util.homePath
					+ System.getProperty("file.separator")
					+ "mobile.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			try {
				throw new Exception(
						"FileNotFoundException while loading the Global Settings file");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
			try {
				throw new Exception(
						"IOException while loading the Global Settings file");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		return properties;
	}

}
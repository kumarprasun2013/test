package SupportLibraries;
import java.io.File;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.sql.Statement;



import Driver.*;
import SupportLibraries.CRAFT_Report.Status;
public class CRAFT_ExcelResults 
{


	static long start = 0;
	//static long end = 0;
	//static String duration = "";
	//static int Pass =0;
	//static int Fail = 0;
	//static int overallPass = 0;
	//static int overallFail = 0;
	//public static String SummaryExcelfile = null;
//	//public static String TestCaseExcelfile = null;


	public  CRAFT_ExcelResults() {
		// TODO Auto-generated constructor stub
	}

	//#############################################################################
	//Function Name    	: addRowtoSummary
	//Description     	: Function to add a row to summary
	//Input Parameters 	: None
	//Return Value    	: None
	//#############################################################################

	public static synchronized void addRowtoSummary()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		TestConfigurations mainTestConfig= GlobalVariables.getConfigMap().get("main");
		String strReportedEventSheet = "ReportedEvents";
		String time = Util.getCurrentDatenTime("H:mm:ss");
		Connection c1 = null;
		Statement st1 = null;
		String query =null;
		try {
			String s =mainTestConfig.getExcelResultSummaryFile();
			String status = "";

			if (testConfig.getCraftHtmlResultFailCount()>0)
			{
				//overallFail++;
				//mainTestConfig.setCraftExcelResultOverallFailCount(mainTestConfig.getCraftExcelResultOverallFailCount()+1);
				
				status = "FAIL";
	
			}
			else if(testConfig.getCraftHtmlResultPassCount() > 0)
			{
				//overallPass++;
				//mainTestConfig.setCraftExcelResultOverallPassCount(mainTestConfig.getCraftExcelResultOverallPassCount()+1);
				
				status = "PASS";
			}
			else
			{
				status = "DONE";
			}
			//query = "INSERT INTO ["+strReportedEventSheet+"$] values ('"+DriverScript.testcase+"','"+DriverScript.desc+"','"+ duration +"','"+status+"')";

			query = "INSERT INTO ["+strReportedEventSheet+"$] values ('"+testConfig.getCurrentTestCase()+"','"+testConfig.getTestCaseDesc()+"','"+ testConfig.getCraftHtmlResultDuration() +"','"+status+"')";
			// Pass = 0;
			//Fail =0;
			testConfig.setCraftHtmlResultPassCount(0);
			testConfig.setCraftHtmlResultFailCount(0);
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver");
			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+s+";READONLY=FALSE");
			st1 = c1.createStatement();
			st1.executeUpdate(query);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				st1.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
			try {
				c1.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

	}
	//#############################################################################
	//Function Name    	: addRowtoTestCase
	//Description     	: Function to add a row to TestCase  report
	//Input Parameters 	: strStepName, strDescription, strStatus
	//Return Value    	:None
	//#############################################################################

	public synchronized static void addRowtoTestCase(String strStepName,String strDescription,Status strStatus)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		//TestConfigurations mainTestConfig= GlobalVariables.getConfigMap().get("main");
		/*if (strStatus.equals(Status.PASS))
		{
			//Pass++;
			testConfig.setCraftExcelResultPassCount(testConfig.getCraftExcelResultPassCount()+1);
		}
		if (strStatus.equals(Status.FAIL))
		{
			//Fail++;
			testConfig.setCraftExcelResultFailCount(testConfig.getCraftExcelResultFailCount()+1);
		}*/
		String strReportedEventSheet = "ReportedEvents";
		String time = Util.getCurrentDatenTime("H:mm:ss");
		Connection c1 = null;
		Statement st1 = null;
		String query =null;
		try {
			//String s = testConfig.getExcelTestCaseResultFile();
			//query = "INSERT INTO ["+strReportedEventSheet+"$] values ('"+DriverScript.iteration+"','"+ strStepName +"','"+strDescription+"','"+strStatus +"','"+time+"')";
			query = "INSERT INTO ["+strReportedEventSheet+"$] values ('"+testConfig.getCurrentIteration()+"','"+ strStepName +"','"+strDescription+"','"+strStatus +"','"+time+"')";
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver");

			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+testConfig.getExcelTestCaseResultFile()+";READONLY=FALSE");
			st1 = c1.createStatement();
			st1.executeUpdate(query);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				st1.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
			try {
				c1.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
	}
	//#############################################################################
	//Function Name    	: createTestCaseHeader
	//Description     	: Function to create a TestCase Header
	//Input Parameters 	: TestCaseExcelfile
	//Return Value    	: None
	//#############################################################################


	public synchronized static void createTestCaseHeader(String TestCaseExcelFile)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

		testConfig.setCraftExcelResultTestCaseExcelfile(TestCaseExcelFile);
		new File(testConfig.getCraftExcelResultTestCaseExcelfile());
		String strReportedEventSheet = "ReportedEvents";
		Connection c1 =null;
		Statement st1 = null;
		String query = null;
		Util.getCurrentDatenTime("dd MMMMM yyyy");
		//start = Util.getLastsetTimeinmili();
		//testConfig.setCraftExcelResultStartCount(Util.getLastsetTimeinmili());
		try {
			//String s = testConfig.getCraftExcelResultTestCaseExcelfile();
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver");
			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+testConfig.getCraftExcelResultTestCaseExcelfile()+";READONLY=FALSE");
			query = "Create table ["+strReportedEventSheet+"] (Iteration varchar(200),Step_Name varchar(200),Description varchar(200),Status varchar(200),Time_Stamp varchar(200))";
			st1 = c1.createStatement();
			st1.executeUpdate(query); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				c1.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

	}
	//#############################################################################
	//Function Name    	:  createSummaryHeader
	//Description     	: Function to create a Summary Header
	//Input Parameters 	: SummaryExcelfile
	//Return Value    	: None
	//#############################################################################

	public synchronized static void createSummaryHeader(String SummaryExcelFile)
	{
		//TestConfigurations mainTestConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());

		String summaryExcelFile=SummaryExcelFile;
		new File(summaryExcelFile);
		String strReportedEventSheet = "ReportedEvents";
		Connection c1 =null;
		Statement st1 = null;
		String query = null;
		Util.getCurrentDatenTime("dd MMMMM yyyy");
		start = Util.getLastsetTimeinmili();
		//testConfig.setCraftExcelResultStartCount(Util.getLastsetTimeinmili());
		try {
			
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver");
			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+summaryExcelFile+";READONLY=FALSE");
			if (summaryExcelFile.endsWith("Summary.xls"))
			{
				query = "Create table ["+strReportedEventSheet+"] (TC_ID  varchar(200),Description varchar(200),Execution_Time varchar(200),Status varchar(200))";
			}
			else
			{
				query = "Create table ["+strReportedEventSheet+"] (Iteration varchar(200),Subiteration varchar(200),Step_Name varchar(200),Description varchar(200),Status varchar(200),Time_Stamp varchar(200))";
			}
			st1 = c1.createStatement();
			st1.executeUpdate(query); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				c1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


	}
	//#############################################################################
	//Function Name    	: closeTestCase
	//Description     	: Function to close the testcase report file
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################

	public synchronized static void closeTestCase()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		//TestConfigurations mainTestConfig= GlobalVariables.getConfigMap().get("main");
		//end = Util.getLastsetTimeinmili();
		//testConfig.setCraftExcelResultEndCount(Util.getLastsetTimeinmili());
		long dur=testConfig.getCraftHtmlResultEndCount()-testConfig.getCraftHtmlResultStartCount();
		//duration = Util.getFormattedTime(diff);
		//testConfig.setCraftExcelResultDuration( Util.getFormattedTime(dur));
		String strReportedEventSheet = "ReportedEvents";
		//String time = Util.getCurrentDatenTime("H:mm:ss");
		Connection c1 = null;
		Statement st1 = null;
		try {
			//String s = testConfig.getCraftExcelResultTestCaseExcelfile();
			String query = "INSERT INTO ["+strReportedEventSheet+"$] values ('','','Execution Duration','','"+testConfig.getCraftHtmlResultDuration()+"')";
			Class.forName( "sun.jdbc.odbc.JdbcOdbcDriver");
			c1 = java.sql.DriverManager.getConnection( "jdbc:odbc:Driver={Microsoft Excel Driver (*.xls)};DBQ="+testConfig.getCraftExcelResultTestCaseExcelfile()+";READONLY=FALSE");
			st1 = c1.createStatement();
			st1.executeUpdate(query);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				st1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				c1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
	//#############################################################################
	//Function Name    	: closeSummary
	//Description     	: Function to close the summary report file
	//Input Parameters 	: None
	//Return Value    	: None
	//Author		: 
	//Date Created	: 
	//#############################################################################


	public static synchronized void closeSummary()
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		//overallFail = 0;
		//overallPass = 0;
		
		testConfig.setCraftHtmlResultOverallPassCount(0);
		testConfig.setCraftHtmlResultOverallFailCount(0);
	}
}


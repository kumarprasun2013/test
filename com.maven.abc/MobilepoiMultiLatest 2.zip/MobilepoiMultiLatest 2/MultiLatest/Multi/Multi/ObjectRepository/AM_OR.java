package ObjectRepository;

public class AM_OR 
{
	
	//******************************object Repository for Android Mobile *********************************************///
	
	
		//*************   Login page ******************///
	public static String androidmobile_username="//*[@resourceid='com.wf.wellsfargomobile:id/username']";
	public static String androidmobile_password="//*[@resourceid='com.wf.wellsfargomobile:id/password']";
	public static String androidmobile_signonbutton="//*[@resourceid='com.wf.wellsfargomobile:id/signOn']";
	
	
	//*************   Landing Page *******************//
	public static String androidmobile_moremenu= "//button[@class='more-menu']/i";
	public static String androidmobile_accountsummarylink= "//span[text()='Account Summary']";
	public static String androidmobile_accountsummarypage="//h1[text()='Account Summary']";
	public static String androidmobile_transferandpaylink="//*[text()='Transfer & Pay']";
	public static String androidmobile_signoffmoremenulink="//*[text()='Sign Off']";
	public static String androidmobile_transfermoneylink="//span[text()='Transfer Money']";
	public static String androidmobile_transfermoneypage="//h1[text()='Transfer Money']";
	public static String androidmobile_paybillslinknew="//*[text()='Pay Bills']";
	public static String androidmobile_paybillspage="//h1[contains(text(),' Bill Pay')]";
	public static String androidmobile_paybillspayeedetails="//ul[@class='panel payee-tile-list all single-tile']";
	public static String androidmobile_surepaylink="//*[contains(text(),'Send Money (WF SurePay)')]";
	public static String androidmobile_surepaypage="//p[contains(text(),'How')]";
	public static String androidmobile_fromaccount="/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/p[1]/p[1]/span[1]";
	public static String androidmobile_toaccount="/html[1]/body[1]/main[1]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[2]/div[1]/div[1]/div[1]/p[1]/p[1]/span[1]";
	public static String androidmobile_fromaccountselect="//p[contains(text(),'CHK52600901')]";
	public static String androidmobile_toaccountselect="//p[contains(text(),'MMC52600903')]";
	public static String androidmobile_amountinputbox="(//input[@id='homeTransferAmount'])[1]";
	public static String androidmobile_amountinputboxpaybills="(//input[@id='makePaymentAmount'])[1]";
	public static String androidmobile_paybutton="//button[contains(text(),'Pay')]";
	public static String androidmobile_continuebutton="//button[contains(text(),'Continue')]";
	public static String androidmobile_maketransferbutton="//button[contains(text(),'Make Transfer')]";
	public static String androidtablet_submitbutton="//button[@id='verifyDetailsSubmit']";
	public static String androidtablet_transferconfirmationpage="//h1[contains(text(),'Transfer Confirmation')]";
	
	
	//**************  Signofflink *********************//
	
	public static String androidmobile_moremenusignofflink="//ul//span[contains(text(),'Sign Off')]";
	public static String androidmobile_logoutsignonbutton="//button[text()='Sign On']";
	public static String androidmobile_signoffpage="//*[text()='Online & Mobile Security']";
	public static String androidtablet_yesbutton="//button[contains(text(),'Yes')]";
	public static String androidmobile_footersignofflink="//button//span[contains(text(),'Sign Off')]";
	
	
	
	
	
	
}

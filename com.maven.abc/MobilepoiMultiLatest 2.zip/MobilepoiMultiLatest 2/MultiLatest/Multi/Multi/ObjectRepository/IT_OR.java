package ObjectRepository;

public class IT_OR 
{
	
	//******************************object Repository for Android Tablet *********************************************///
	
	
	//*************   Login page ******************///
	public static String androidtablet_username="com.wf.wellsfargomobile.tablet:id/username";
	public static String androidtablet_password="com.wf.wellsfargomobile.tablet:id/password";
	public static String androidtablet_signonbutton="com.wf.wellsfargomobile.tablet:id/signOn";
	
	
	//*************   Landing Page *******************//
	public static String androidtablet_moremenu="//li[@class='MORE_LINK']/a";
	public static String androidtablet_accountandsettingslink="//h2[contains(text(),'Accounts')]";
	public static String androidtablet_statementsanddocumentslink="//span[contains(text(),'Statements')]";
	public static String androidtablet_statementsanddocumentspage="//h1[contains(text(),'Statements and Documents')]";
	
	//**************  Signofflink *********************//
	
	public static String androidtablet_signofflink="/html[1]/body[1]/footer[1]/div[1]/div[1]/ul[2]/li[1]/a[1]/span[1]";
	public static String androidtablet_yesbutton="//button[contains(text(),'Yes')]";
	public static String androidtablet_signonpage="//*[text()='View Your Accounts']";
	
	
	
	
	//*******************object repository for android mobile  *******************************************/////
	
	
	//*************   Login page ******************///
	public static String androidmobile_username="//*[@resourceid='com.wf.wellsfargomobile:id/username']";
	public static String androidmobile_password="//*[@resourceid='com.wf.wellsfargomobile:id/password']";
	public static String androidmobile_signonbutton="//*[@resourceid='com.wf.wellsfargomobile:id/signOn']";
	
	
	//*************   Landing Page *******************//
	public static String androidmobile_moremenu= "//button[@class='more-menu']";
	public static String androidmobile_transferandpaylink="//span[text()='Transfer & Pay']";
	public static String androidmobile_transfermoneylink="//span[text()='Transfer Money']";
	public static String androidmobile_transfermoneypage="//h1[text()='Transfer Money']";
	
	//**************  Signofflink *********************//
	
	public static String androidmobile_signofflink="//a[text()='Sign Off']";
	public static String androidmobile_logoutsignonbutton="//button[text()='Sign On']";
	public static String androidmobile_signoffpage="//*[text()='Online Security Guarantee']";
	
	
	
	
	
	
}

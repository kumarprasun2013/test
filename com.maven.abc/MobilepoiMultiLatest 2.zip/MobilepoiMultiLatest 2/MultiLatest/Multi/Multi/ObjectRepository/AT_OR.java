package ObjectRepository;

public class AT_OR 
{
	
	//******************************object Repository for Android Tablet *********************************************///
	
	
	//*************   Login page ******************///
	public static String androidtablet_username="com.wf.wellsfargomobile.tablet:id/username";
	public static String androidtablet_password="com.wf.wellsfargomobile.tablet:id/password";
	public static String androidtablet_signonbutton="com.wf.wellsfargomobile.tablet:id/signOn";
	
	
	//*************   Landing Page *******************//
	
	public static String androidtablet_opentransferandpaymenubutton="/html[1]/body[1]/header[1]/div[1]/div[2]/ul[1]/li[2]/a[1]";
	
	
	
	//*************** Transfer and pay flow****************//
	public static String androidtablet_transfermoneylink="//nav//ul//span[contains(text(),'Transfer Money')]";
	public static String androidtablet_transfermoneypage="//h1[contains(text(),'Transfer Money')]";
	public static String androidtablet_showtransferandpaymenubutton="/html[1]/body[1]/div[3]/header[1]/div[1]/div[2]/ul[1]/li[1]";
	public static String androidtablet_paybillslink="//a[@class='samloutbound']/span[contains(text(),'Pay Bills')]";
	public static String androidtablet_paybillslinknew="//span[contains(text(),'Pay Bills')]";
	public static String androidtablet_paybillspage="//h1[contains(text(),'Bill Pay')][1]";
	public static String androidtablet_verifypaypage="//h1[contains(text(),'Verify Payment')]";
	public static String androidtablet_confirmationpaypage="//h1[contains(text(),'Payment Confirmation')]";
	public static String androidtablet_sendondate="(//div[@id='sendOnDate'])[2]";
	public static String androidtablet_paybillspage_amount="//div//input[@id]";
	public static String androidtablet_SendMoneylink="//nav//ul//span[contains(text(),'Send Money')]";
	public static String androidtablet_SendMoneyPage="//h2[contains(text(),'Wells Fargo SurePay Service')]";
	public static String androidtablet_SendMoneyAgreebutton="//button[contains(text(),'Agree')]";
	public static String androidtablet_fromaccount="(//span[@id='selectedAccount'])[1]";
	public static String androidtablet_toaccount="(//span[@id='selectedAccount'])[2]";
	public static String androidtablet_fromaccount1="//*[@class='mwf-select-list-target']";
	public static String androidtablet_toaccount1="//*[@class='toAccountList mwf-select-list-target']";
	public static String androidtablet_fromaccountselect="//li[contains(text(),' CHK52600901')]";
	public static String androidtablet_toaccountselect="//li[contains(text(),'MMC52600903')]";
	public static String androidtablet_fromaccountselect1="//*[@class='mm payment-app selfpay-app']/div[5]/div[1]/section[1]/ul[1]/li[1]/div[1]/p[1]/span[1]";
	public static String androidtablet_toaccountselect1="//*[@class='mm payment-app selfpay-app']/div[5]/div[1]/section[1]/ul[1]/li[2]/div[1]/p[1]/span[1]";
	
	
	public static String androidtablet_amountinputbox="(//input[@id='paymentAmount'])[1]";
	public static String androidtablet_continuebutton="//button[contains(text(),'Continue')]";
	public static String androidtablet_paybutton="//*[text()='Pay']";
	public static String androidtablet_submitbutton="//button[@id='verifyDetailsSubmit']";
	public static String androidtablet_submitbutton1="//*[@class='mwf-button-container mwf-payments-non-2fa-button-container']//*[@class='mwf-button primary']";
	public static String androidtablet_transferconfirmationpage="//h1[contains(text(),'Transfer Confirmation')]";
	
	//********************** More Menu button **********************************///
	
	public static String androidtablet_moremenu="//li[@class='MORE_LINK']/a";
	public static String androidtablet_openmenu="/html[1]/body[1]/header[1]/div[1]/div[2]/ul[1]/li[2]/a[1]";
	public static String androidtablet_accountandsettings="//h2[contains(text(),'Accounts and Settings')]";
	public static String androidtablet_accontsummarylink="//span[contains(text(),'Account Summary')]";
	public static String androidtablet_accontsummarypage="//h1[contains(text(),'Account Summary')]";
	public static String androidtablet_depositchecklink="//span[contains(text(),'Deposit Checks')]";
	public static String androidtablet_depositcheckspage="//*[contains(text(),'Mobile Deposit')]";
	public static String androidtablet_backtohome="//*[contains(text(),'Account Summary')]";
	
	
	
	public static String androidtablet_accountandsettingslink="//h2[contains(text(),'Accounts')]";
	public static String androidtablet_statementsanddocumentslink="//span[contains(text(),'Statements')]";
	public static String androidtablet_statementsanddocumentspage="//h1[contains(text(),'Statements and Documents')]";
	public static String androidtablet_statementsanddisclosures="//*[contains(text(),'Statements and Disclosures')]";
	public static String androidtablet_statementsanddisclosurespdf="//p/following-sibling::div[1]//a[contains(text(),'PDF')]";
	public static String androidtablet_statementsanddocumentstaxdoc="//*[contains(text(),'Tax Doc')]";
	public static String androidtablet_statementsanddocumentstaxdoccheck="//p[contains(text(),'no tax documents')]";
	
	public static String androidtablet_messagecentrelink="//span[contains(text(),'Message Center')]";
	public static String androidtablet_messagecentrepage="//h1[contains(text(),'Message Center')]";
	
	
	public static String androidtablet_profileandsettingslink="//span[contains(text(),'Profile and')]";
	public static String androidtablet_profileandsettingspage="//h1[contains(text(),'Profile and')]";
	
	
	
	public static String androidtablet_managealertslink="/html[1]/body[1]/div[1]/div[2]/nav[1]/ul[1]/li[1]/ul[1]/li[3]/a[1]/span[1]";
	public static String androidtablet_managealertsspage="//h1[contains(text(),'Manage Alerts')]";
	
	public static String androidtablet_customersupportlink="//h2[contains(text(),'Customer Support')]";
	public static String androidtablet_locationslink="//span[contains(text(),'Locations')]";
	public static String androidtablet_locationspage="//*[contains(text(),'Find ATM')]";
	
	
	//**************  Signofflink *********************//
	
	public static String androidtablet_signofflink="/html[1]/body[1]/footer[1]/div[1]/div[1]/ul[2]/li[1]/a[1]/span[1]";
	public static String androidtablet_signofflinkmoremenu="//a[@class='signoff nospinner']/span[contains(text(),'Sign Off')]";
	public static String androidtablet_signofflinknew="/html[1]/body[1]/div[3]/footer[1]/div[1]/div[1]/ul[2]/li[1]/a[1]/span[1]";
	public static String androidtablet_signofflinkrightpanel="/html[1]/body[1]/div[3]/section[1]/div[2]/div[1]/a[1]/span[1]";
	public static String androidtablet_yesbutton="//button[contains(text(),'Yes')]";
	public static String androidtablet_signonpage="//*[text()='View Your Accounts']";
}
	
	
	
package ObjectRepository;

import org.openqa.selenium.By;

/**
 * UI Map for SignOnPage 
 */
public class Appium_OR {
	
	
	
	//common web objects
	
	public static String moremenubutton="/html/body/div[2]/button[2]/i";
	
	//Android
	public static String usernamemobile="//*[@resource-id='com.wf.wellsfargomobile:id/username']";
	public static String passwordmobile = "//android.widget.RelativeLayout[2]/android.widget.EditText[1]";
	public static String signonbuttonmobile="//*[@resource-id='com.wf.wellsfargomobile:id/signOn']";
	public static String hamburgermenu="//android.webkit.WebView[1]//android.view.View[1]//android.widget.Button[1]";
	public static String signofflink = "//android.view.View[2]/android.widget.ListView[1]/android.widget.Button[1]";
	public static String signoffyesbutton="//android.webkit.WebView[1]/android.view.View[1]/android.view.View[4]/android.widget.Button[2]";
	public static String yesbutton="//android.webkit.WebView[1]/android.view.View[1]/android.app.Dialog[1]/android.widget.Button[2]";
	public static String signoffOKbutton="//android.widget.Button[1]";
	public static String depositchecklink="//android.webkit.WebView[1]/android.view.View[1]/android.view.View[2]/android.widget.ListView[1]/android.view.View[3]";
	public static String continuebutton="//android.webkit.WebView[1]/android.view.View[1]/android.view.View[2]/android.view.View[2]";
	public static String depositcheckpage="//android.webkit.WebView[1]/android.view.View[1]/android.view.View[2]/android.view.View[1]";
	public static String openhamburger="//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[3]/android.widget.Button[1]";
	
	//Android_tablet 
	
	public static String usernametablet="//*[@resource-id='com.wf.wellsfargomobile.tablet:id/username']";
	public static String passwordtablet= "//*[@resource-id='com.wf.wellsfargomobile.tablet:id/password']";
	public static String signonbuttontablet="//*[@resource-id='com.wf.wellsfargomobile.tablet:id/signOn']";
	public static String moremenutablet="//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[2]/android.widget.Button[1]";
	public static String signofftablet="//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[3]/android.widget.Button[1]";
	public static String yesbuttontablet="//android.webkit.WebView[1]/android.view.View[1]/android.view.View[1]/android.view.View[3]/android.view.View[2]/android.view.View[1]/android.widget.Button[2]";
	public static String accountsummarypage="//android.webkit.WebView[1]/android.view.View[3]/android.view.View[1]/android.view.View[2]/android.view.View[1]";
	public static String accountsettingslink="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]/android.widget.Button[1]";
	public static String accountserviceslink="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]/android.view.View[2]/android.view.View[2]/android.view.View[1]";
	public static String accountservicespage="//android.webkit.WebView[1]/android.view.View[3]/android.view.View[1]";
	public static String profileandsettingslink="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]/android.view.View[2]/android.view.View[7]/android.view.View[1]";	
	public static String profileandsettingspage="//android.webkit.WebView[1]/android.view.View[3]/android.view.View[1]";
	public static String transferandpaylink="//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]/android.widget.Button[1]";
	public static String transfermoneylink="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]/android.view.View[1]";
	public static String transfermoneypage="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[2]/android.view.View[1]/android.view.View[1]/android.view.View[1]";
	public static String selectfromaccount="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[2]/android.view.View[1]/android.view.View[4]/android.view.View[1]/android.view.View[2]/android.widget.Spinner[1]";
	public static String selecttoaccount="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[2]/android.view.View[1]/android.view.View[4]/android.view.View[3]/android.view.View[2]/android.widget.Spinner[1]";
	public static String fromaccount="//android.webkit.WebView[1]/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]";
	public static String toaccount="//android.webkit.WebView[1]/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]";
	public static String amount="//android.view.View[2]/android.view.View[2]/android.view.View[1]/android.view.View[4]/android.view.View[6]/android.widget.EditText[1]";
	public static String continuebuttontablet="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[2]/android.view.View[1]/android.view.View[4]/android.view.View[8]/android.widget.Button[2]";
	public static String verifytransfer="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[2]/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.view.View[1]";
	public static String submitbutton="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[2]/android.view.View[1]/android.view.View[1]/android.view.View[13]/android.widget.Button[3]";
	public static String transferconfirmation="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[2]/android.view.View[1]/android.view.View[1]/android.view.View[2]/android.view.View[1]";
	public static String accountsummarynavigate="//android.webkit.WebView[1]/android.view.View[2]/android.view.View[1]/android.view.View[1]/android.view.View[1]/android.view.View[1]";


	
	
	
	
	//login ios mobile
	
	public static String usernamemobileios="//*[@label='Online Username']";
	public static String passwordmobileios= "//*[@label='Online Password']";
	public static String signonbuttonmobileios="//text[contains(text(),'Sign On')]";
	
	
	
	
	//login ios tablet
		public static String usernameios="//UIAApplication[1]/UIAWindow[1]/UIATextField[1]";
		public static String passwordios= "//UIAApplication[1]/UIAWindow[1]/UIASecureTextField[1]";
		public static String signonbuttonios="//UIAApplication[1]/UIAWindow[1]/UIAButton[3]";
		
	//ios landingpage	
	
		public static String moremenuios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIASwitch[2]";
		public static String signofftabletios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIALink[1]";
		public static String yesbuttontabletios="//*[@name='Yes']";
		public static String accountsummarypageios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAStaticText[1]";
		public static String accountsettingslinkios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAButton[6]";
		public static String accountserviceslinkios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAButton[8]";
		public static String accountservicespageios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAStaticText[1]";
		public static String profileandsettingslinkios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIALink[12]/UIAStaticText[1]";	
		public static String profileandsettingspageios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAStaticText[1]";
		public static String transferandpaylinkios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAButton[1]";
		public static String transfermoneylinkios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIALink[2]/UIAStaticText[1]";
		public static String transfermoneypageios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAStaticText[1]";
		public static String selectfromaccountios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAElement[1]";
		public static String selecttoaccountios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAElement[2]";
		public static String fromaccountios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAElement[1]";
		public static String toaccountios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAElement[1]";
		public static String amountios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIATextField[1]";
		public static String continuebuttontabletios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAButton[9]";
		public static String verifytransferios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAStaticText[1]";
		public static String submitbuttonios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAButton[6]";
		public static String transferconfirmationios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAStaticText[1]";
		public static String accountsummarynavigateios="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIALink[2]/UIAStaticText[1]";

		
		
		
	
	
}
package ObjectRepository;

public class IM_OR 
{
	
	//******************************object Repository for Android Tablet *********************************************///
	
	
	public static String iosmobile_amountinputbox="(//input[@id='homeTransferAmount'])[1]";
	
	//*************   Landing Page *******************//

	
}

package BusinessComponents;

import java.util.Hashtable;

import SupportLibraries.CRAFT_DB;
import SupportLibraries.KeywordImplementation;
import SupportLibraries.TestConfigurations;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import java.sql.Driver;
import java.util.Hashtable;






//import org.apache.commons.jxpath.servlet.KeywordVariables;
import org.hamcrest.core.Is;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.perfectomobile.selenium.MobileCoordinates;
import com.perfectomobile.selenium.MobilePoint;
import com.perfectomobile.selenium.api.IMobileKeyboard;
import com.perfectomobile.selenium.api.IMobileTouchScreen;
import com.perfectomobile.selenium.options.touch.MobileTouchOptions;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.internal.WrapsDriver;
import org.openqa.selenium.support.events.internal.EventFiringKeyboard;
import org.openqa.selenium.support.ui.Select;

import com.thoughtworks.selenium.Selenium;

import ObjectRepository.*;
import SeleniumHelper.SeleniumHelper;
import SupportLibraries.CRAFT_DB;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.CRAFT_Report.Status;
import SupportLibraries.GlobalVariables;
import SupportLibraries.CRAFT_Report.Status;
import SupportLibraries.KeywordImplementation;


public class AT_Wrapper extends SeleniumHelper {
	
	// ====================================================================================================
	// FunctionName : AndroidTablet
	// Description : LoginLogout
	// Date Created : 27/06/2016
	// Author : Kumar Prasun
	// ====================================================================================================
	public static void AT_TC_001() {

		AT.ATlogin();
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.Click("xpath",AT_OR.androidtablet_opentransferandpaymenubutton ,"Transfer and pay button");
//		KeywordImplementation.Click("xpath",AT_OR.androidtablet_transfermoneylink,"Transfer Money Link");
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_transfermoneypage, "Transfer Money Page");
//		KeywordImplementation.Click("xpath",AT_OR.androidtablet_showtransferandpaymenubutton,"Transfer and Pay button");
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.Click("xpath",AT_OR.androidtablet_paybillslink,"Pay Bills Link");
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_paybillspage, "Pay Bills Page");
//		KeywordImplementation.Click("xpath",AT_OR.androidtablet_showtransferandpaymenubutton,"Transfer and Pay button");
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.Click("xpath",AT_OR.androidtablet_SendMoneylink,"Send Money Link");
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.Click("xpath",AT_OR.androidtablet_SendMoneyAgreebutton,"Agree button");
//		KeywordImplementation.waitforpageloading();
//		
//
//		KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflink,"Signoff Link");
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.getnativedriver();
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");

	}
	
	// ====================================================================================================
		// FunctionName : AndroidTablet
		// Description : LoginLogout
		// Date Created : 27/06/2016
		// Author : Kumar Prasun
		// ====================================================================================================
		public static void AT_TC_002() {

			AT.ATlogin();
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_opentransferandpaymenubutton ,"Transfer and pay button");
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_transfermoneylink,"Transfer Money Link");
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_transfermoneypage, "Transfer Money Page");
//			
//			//From Account
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_fromaccount1 ,"From Account select list");
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_fromaccountselect1,"Account from list");
//			KeywordImplementation.waitforpageloading();
//			
//			//To account
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_toaccount1 ,"To Account select list");
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_toaccountselect1,"Account To list");
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.waitforpageloading();
//			
//			//Amount Input box
//			KeywordImplementation.Entertext("xpath",AT_OR.androidtablet_amountinputbox,"1.50","Amount Input Box");
//			
//			//Continue Button
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_continuebutton ,"Continue Button");
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.waitforpageloading();
//			
//			
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_submitbutton1 ,"Submit Button");
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_transferconfirmationpage, "Transfer Confirmation Page");
//			KeywordImplementation.waitforpageloading();
//			
//
//			
//
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflinknew,"Signoff Link");
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.getnativedriver();
//			KeywordImplementation.waitforpageloading();
//			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");

		}
		
		
		// ====================================================================================================
		// FunctionName : AndroidTablet
		// Description : LoginLogout
		// Date Created : 27/06/2016
		// Author : Kumar Prasun
		// ====================================================================================================
		public static void AT_TC_003() {

			AT.ATlogin();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_opentransferandpaymenubutton ,"Transfer and pay button");
			KeywordImplementation.waitforpageloading();
			
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_paybillslink,"Pay Bills Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_paybillspage, "Pay Bills Page");
			

			KeywordImplementation.Entertext("xpath", AT_OR.androidtablet_paybillspage_amount, "1.50","Amount");
			KeywordImplementation.waitforpageloading();
			//Continue Button
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_continuebutton ,"Continue Button");
			KeywordImplementation.waitforpageloading();
			
			
			//Pay button
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_verifypaypage, "Verify Pay Page");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_paybutton ,"Continue Button");
			KeywordImplementation.waitforpageloading();
			
			//Confirmation page
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_confirmationpaypage, "Confirmation Pay Page");
			KeywordImplementation.GetText("xpath", AT_OR.androidtablet_sendondate, "Send on Date");
			
			
			
			
			//Sign Off
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflink,"Signoff Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.getnativedriver();
			KeywordImplementation.waitforpageloading();
			
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");

		}

		
	
		

		// ====================================================================================================
		// FunctionName : AndroidTablet
		// Description : LoginLogout
		// Date Created : 27/06/2016
		// Author : Kumar Prasun
		// ====================================================================================================
		public static void AT_TC_004() {

			AT.ATlogin();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_opentransferandpaymenubutton ,"Transfer and pay button");
			KeywordImplementation.waitforpageloading();
			
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_SendMoneylink,"Send Money Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_SendMoneyAgreebutton,"Agree button");
			KeywordImplementation.waitforpageloading();
			

			KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflink,"Signoff Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.getnativedriver();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");

		}
		
		// ====================================================================================================
		// FunctionName : AndroidTablet
		// Description : LoginLogout
		// Date Created : 27/06/2016
		// Author : Kumar Prasun
		// ====================================================================================================
		public static void AT_TC_005() {

			AT.ATlogin();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_moremenu, "More Menu");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_moremenu,"More Menu Link");
			KeywordImplementation.waitforpageloading();
			
			//Account and Settings
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_accountandsettings,"Account and Settings Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_accontsummarylink,"Account Summary Link");
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_accontsummarypage, "Account Summary page");
			
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_openmenu,"More Menu Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_accountandsettings,"Account and Settings Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_depositchecklink,"Deposit Check Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_depositcheckspage, "Deposit Check page");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_backtohome,"Deposit Check Link");
			
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_openmenu,"More Menu Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_accountandsettings,"Account and Settings Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_statementsanddocumentslink,"Statements and Documents Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_statementsanddocumentspage, "Statements and Documents page");
			KeywordImplementation.waitforpageloading();
			
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_moremenu,"More Menu Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_accountandsettings,"Account and Settings Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_messagecentrelink,"Message Centre Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_messagecentrepage, "Message Centre page");
			
			
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_openmenu,"More Menu Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_accountandsettings,"Account and Settings Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_managealertslink,"Manage alerts Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_managealertsspage, "Manage alerts page");
			
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_openmenu,"More Menu Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_accountandsettings,"Account and Settings Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_profileandsettingslink,"Profile and settings Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_profileandsettingspage, "Profile and settings page");
			
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_openmenu,"More Menu Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_customersupportlink,"Customer Support Link");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_locationslink,"Locations Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_locationspage, "Locations page");
			
			
			
			
			KeywordImplementation.waitforpageloading();
			
			
			
		}

		
		
		
		// ====================================================================================================
		// FunctionName : AndroidTablet
		// Description : LoginLogout
		// Date Created : 27/06/2016
		// Author : Kumar Prasun
		// ====================================================================================================
		public static void AT_TC_006() {

			AT.ATlogin();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_moremenu, "More Menu");
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_moremenu,"More Menu Link");
			KeywordImplementation.waitforpageloading();
			
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflinkmoremenu,"Signoff Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.getnativedriver();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");
			KeywordImplementation.waitforpageloading();
			
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Entertext("id",AT_OR.androidtablet_username, CRAFT_DB.getData("Username"),"Username field");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Entertext("id",AT_OR.androidtablet_password, CRAFT_DB.getData("Password"),"Password field");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("id",AT_OR.androidtablet_signonbutton, "Sign On Button");
			KeywordImplementation.getdomdriver();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflink,"Signoff Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.getnativedriver();
			KeywordImplementation.waitforpageloading();
			
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");
			KeywordImplementation.waitforpageloading();
			
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Entertext("id",AT_OR.androidtablet_username, CRAFT_DB.getData("Username"),"Username field");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Entertext("id",AT_OR.androidtablet_password, CRAFT_DB.getData("Password"),"Password field");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("id",AT_OR.androidtablet_signonbutton, "Sign On Button");
			KeywordImplementation.getdomdriver();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflinkrightpanel,"Signoff Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.getnativedriver();
			KeywordImplementation.waitforpageloading();
			
			KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");
			KeywordImplementation.waitforpageloading();
			
			
		}
		
		
		
		
		
		// ====================================================================================================
				// FunctionName : AndroidTablet
				// Description : LoginLogout
				// Date Created : 27/06/2016
				// Author : Kumar Prasun
				// ====================================================================================================
				public static void AT_TC_007() {

					AT.ATlogin();
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_moremenu, "More Menu");
					KeywordImplementation.Click("xpath",AT_OR.androidtablet_moremenu,"More Menu Link");
					KeywordImplementation.waitforpageloading();
					
				
					KeywordImplementation.Click("xpath",AT_OR.androidtablet_accountandsettings,"Account and Settings Link");
					KeywordImplementation.Click("xpath",AT_OR.androidtablet_statementsanddocumentslink,"Statements and Documents Link");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_statementsanddocumentspage, "Statements and Documents page");
					KeywordImplementation.waitforpageloading();
					
					KeywordImplementation.Click("xpath",AT_OR.androidtablet_statementsanddisclosures,"Statements and disclosures Link");
					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_statementsanddisclosurespdf, "PDF validation");
					KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflink,"Signoff Link");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.getnativedriver();
					KeywordImplementation.waitforpageloading();
					
					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");
					KeywordImplementation.waitforpageloading();
					
					
				}
		
				
				// ====================================================================================================
				// FunctionName : AndroidTablet
				// Description : LoginLogout
				// Date Created : 27/06/2016
				// Author : Kumar Prasun
				// ====================================================================================================
				public static void AT_TC_008(){

					AT.ATlogin();
//					KeywordImplementation.waitforpageloading();
//					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_moremenu, "More Menu");
//					KeywordImplementation.Click("xpath",AT_OR.androidtablet_moremenu,"More Menu Link");
//					KeywordImplementation.waitforpageloading();
//					KeywordImplementation.waitforpageloading();
//					
//				
//					KeywordImplementation.Click("xpath",AT_OR.androidtablet_accountandsettings,"Account and Settings Link");
//					KeywordImplementation.Click("xpath",AT_OR.androidtablet_statementsanddocumentslink,"Statements and Documents Link");
//					KeywordImplementation.waitforpageloading();
//					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_statementsanddocumentspage, "Statements and Documents page");
//					KeywordImplementation.waitforpageloading();
//					KeywordImplementation.Click("xpath",AT_OR.androidtablet_statementsanddocumentstaxdoc,"Tax and Documents Link");
//					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_statementsanddocumentstaxdoccheck, "Document validation");
//					KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflink,"Signoff Link");
//					KeywordImplementation.waitforpageloading();
//					KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
//					KeywordImplementation.waitforpageloading();
//					KeywordImplementation.getnativedriver();
//					KeywordImplementation.waitforpageloading();
//					
//					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");
					KeywordImplementation.waitforpageloading();
					
					
				}
				
				// ====================================================================================================
				// FunctionName : iOSTablet
				// Description : LoginLogout
				// Date Created : 27/06/2016
				// Author : Kumar Prasun
				// ====================================================================================================
			public static void AT_TC_009() {
				TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
				String strBrowser=testConfig.getBrowser();
				AT.ATlogin();
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.Click("xpath","//*[text()='Online Security Guarantee']","Accounts and Settings Link");
				KeywordImplementation.waitforpageloading();
				testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver("Chrome").open();
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.getdomdriver();
				KeywordImplementation.VerifyElement("xpath","//*[text()='Online Security Guarantee']", "Online Security Gurantee");
//				System.out.println("safari1 "  + driver.findElement(By.xpath("//*[text()='Online Security Guarantee']")).isDisplayed());
				testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver("Chrome").close();
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.waitforpageloading();
				
				testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver("Wells fargo").open();
			

				KeywordImplementation.waitforpageloading();
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.Click("xpath",AT_OR.androidtablet_signofflink,"Signoff Link");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.Click("xpath",AT_OR.androidtablet_yesbutton,"Yes button ");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.getnativedriver();
				KeywordImplementation.waitforpageloading();
				
				KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_signonpage, "Logout Page");
				KeywordImplementation.waitforpageloading();

				 }
				

		
	


	}


package BusinessComponents;

import java.util.Hashtable;

import SupportLibraries.CRAFT_DB;
import SupportLibraries.KeywordImplementation;
import SupportLibraries.TestConfigurations;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import java.sql.Driver;
import java.util.Hashtable;

//import org.apache.commons.jxpath.servlet.KeywordVariables;
import org.hamcrest.core.Is;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.perfectomobile.selenium.MobileCoordinates;
import com.perfectomobile.selenium.MobilePoint;
import com.perfectomobile.selenium.api.IMobileKeyboard;
import com.perfectomobile.selenium.api.IMobileTouchScreen;
import com.perfectomobile.selenium.options.touch.MobileTouchOptions;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.internal.WrapsDriver;
import org.openqa.selenium.support.events.internal.EventFiringKeyboard;
import org.openqa.selenium.support.ui.Select;

import com.thoughtworks.selenium.Selenium;

import ObjectRepository.*;
import SeleniumHelper.SeleniumHelper;
import SupportLibraries.CRAFT_DB;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.CRAFT_Report.Status;
import SupportLibraries.GlobalVariables;
import SupportLibraries.CRAFT_Report.Status;
import SupportLibraries.KeywordImplementation;


public class AT extends SeleniumHelper {
	
	// ====================================================================================================
	// FunctionName : AndroidTablet
	// Description : LoginLogout
	// Date Created : 27/06/2016
	// Author : Kumar Prasun
	// ====================================================================================================
	public static void ATlogin() {

		KeywordImplementation.StartApplication();
		KeywordImplementation.waitforpageloading();
		KeywordImplementation.waitforpageloading();
		KeywordImplementation.waitforpageloading();
		KeywordImplementation.Entertext("id",AT_OR.androidtablet_username, CRAFT_DB.getData("Username"),"Username field");
		KeywordImplementation.waitforpageloading();
		KeywordImplementation.Entertext("id",AT_OR.androidtablet_password, CRAFT_DB.getData("Password"),"Password field");
		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.Click("id",AT_OR.androidtablet_signonbutton, "Sign On Button");
//		KeywordImplementation.waitforpageloading();
//		KeywordImplementation.getdomdriver();
	
	}

	}


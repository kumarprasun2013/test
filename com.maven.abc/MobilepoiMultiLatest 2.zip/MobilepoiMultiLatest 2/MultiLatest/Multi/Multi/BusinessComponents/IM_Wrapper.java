package BusinessComponents;

import io.appium.java_client.TouchAction;

import java.util.Hashtable;

import SupportLibraries.CRAFT_DB;
import SupportLibraries.KeywordImplementation;
import SupportLibraries.TestConfigurations;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import java.sql.Driver;
import java.util.Hashtable;













//import org.apache.commons.jxpath.servlet.KeywordVariables;
import org.hamcrest.core.Is;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;

import com.perfectomobile.selenium.MobileCoordinates;
import com.perfectomobile.selenium.MobilePoint;
import com.perfectomobile.selenium.api.IMobileKeyboard;
import com.perfectomobile.selenium.api.IMobileTouchScreen;
import com.perfectomobile.selenium.options.touch.MobileTouchOptions;
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.internal.WrapsDriver;
import org.openqa.selenium.support.events.internal.EventFiringKeyboard;
import org.openqa.selenium.support.ui.Select;

import com.thoughtworks.selenium.Selenium;

import ObjectRepository.*;
import SeleniumHelper.SeleniumHelper;
import SupportLibraries.CRAFT_DB;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.CRAFT_Report.Status;
import SupportLibraries.GlobalVariables;
import SupportLibraries.CRAFT_Report.Status;
import SupportLibraries.KeywordImplementation;


public class IM_Wrapper extends SeleniumHelper {
	


	
	// ====================================================================================================
			// FunctionName : AndroidTablet
			// Description : LoginLogout
			// Date Created : 27/06/2016
			// Author : Kumar Prasun
			// ====================================================================================================
			public static void IM_TC_001() {

			    IM.IMlogin();
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_moremenu,"More button");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_transferandpaylink ,"Transfer and pay button");
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_transfermoneylink,"Transfer Money Link");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.VerifyElement("xpath", AM_OR.androidmobile_transfermoneypage, "Transfer Money Page");
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_moremenu,"More button");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_transferandpaylink ,"Transfer and pay button");
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_paybillslinknew,"Pay Bills Link");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.VerifyElement("xpath", AM_OR.androidmobile_paybillspage, "Pay Bills Page");
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_moremenu,"More button");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_transferandpaylink ,"Transfer and pay button");
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_surepaylink,"Sure pay Link");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_surepaypage,"Sure Pay Page");
//				KeywordImplementation.waitforpageloading();
//				
////Sign off
//				
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_footersignofflink,"Signoff Link");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.Click("xpath",AM_OR.androidtablet_yesbutton,"Yes button ");
//			    KeywordImplementation.waitforpageloading();
//			    KeywordImplementation.waitforpageloading();
//			    KeywordImplementation.getnativedriver();
//				 KeywordImplementation.Click("xpath","//*[@label='Sign On']","Sign On link is clicked after signing off");
//				 KeywordImplementation.waitforpageloading();
//				 KeywordImplementation.VerifyElement("xpath","//*[@label='Online Security Guarantee']", "Sign Off Page");
//				 KeywordImplementation.waitforpageloading();
				
				
				
			}
			
			
			// ====================================================================================================
			// FunctionName : AndroidTablet
			// Description : LoginLogout
			// Date Created : 27/06/2016
			// Author : Kumar Prasun
			// ====================================================================================================
			public static void IM_TC_002() {

			    IM.IMlogin();
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_moremenu,"More button");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_transferandpaylink ,"Transfer and pay button");
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_transfermoneylink,"Transfer Money Link");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.VerifyElement("xpath", AM_OR.androidmobile_transfermoneypage, "Transfer Money Page");
				KeywordImplementation.waitforpageloading();
				//From Account
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_fromaccount ,"From Account select list");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_fromaccountselect,"Account from list");
				KeywordImplementation.waitforpageloading();
				
				//To account
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_toaccount ,"To Account select list");
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_toaccountselect,"Account To list");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.waitforpageloading();
				
				//Amount Input box
				KeywordImplementation.Entertext("xpath",AM_OR.androidmobile_amountinputbox,"1.50","Amount Input Box");
				
				//Continue Button
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_continuebutton ,"Continue Button");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.waitforpageloading();
				
				
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_maketransferbutton ,"Make transfer Button");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_transferconfirmationpage, "Transfer Confirmation Page");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.waitforpageloading();
				
				//Sign off
				
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_footersignofflink,"Signoff Link");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.Click("xpath",AM_OR.androidtablet_yesbutton,"Yes button ");
			    KeywordImplementation.waitforpageloading();
			    KeywordImplementation.waitforpageloading();
			    KeywordImplementation.getnativedriver();
				 KeywordImplementation.Click("xpath","//*[@label='Sign On']","Sign On link is clicked after signing off");
				 KeywordImplementation.waitforpageloading();
				 KeywordImplementation.waitforpageloading();
				 KeywordImplementation.VerifyElement("xpath","//*[@label='Online Security Guarantee']", "Sign Off Page");
				
				
				
			}
			
			
			// ====================================================================================================
			// FunctionName : AndroidTablet
			// Description : LoginLogout
			// Date Created : 27/06/2016
			// Author : Kumar Prasun
			// ====================================================================================================
			public static void IM_TC_003() {

				   IM.IMlogin();
					KeywordImplementation.Click("xpath",AM_OR.androidmobile_moremenu,"More button");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.Click("xpath",AM_OR.androidmobile_transferandpaylink ,"Transfer and pay button");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.Click("xpath",AM_OR.androidmobile_paybillslinknew,"Pay Bills Link");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.VerifyElement("xpath", AM_OR.androidmobile_paybillspage, "Pay Bills Page");
					KeywordImplementation.Click("xpath","//div[@class='payee-details']//span[contains(text(),'01test')]" ,"Payee Details link");
					//Amount Input box
					
					//div[@class='payee-details']//span[contains(text(),'01test')] click on payee
					
					
					
					KeywordImplementation.Entertext("xpath",AM_OR.androidmobile_amountinputboxpaybills,"1.50","Amount Input Box");
					
					
					KeywordImplementation.waitforpageloading();
					//Continue Button
					KeywordImplementation.Click("xpath",AT_OR.androidtablet_continuebutton ,"Continue Button");
					KeywordImplementation.waitforpageloading();
					
					
					//Pay button
					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_verifypaypage, "Verify Pay Page");
					KeywordImplementation.Click("xpath",AT_OR.androidtablet_paybutton ,"Continue Button");
					KeywordImplementation.waitforpageloading();
					
					//Confirmation page
					KeywordImplementation.VerifyElement("xpath", AT_OR.androidtablet_confirmationpaypage, "Confirmation Pay Page");
					
				
				
				//Sign Off
				KeywordImplementation.Click("xpath",AM_OR.androidmobile_footersignofflink,"Signoff Link");
				KeywordImplementation.waitforpageloading();
				KeywordImplementation.Click("xpath",AM_OR.androidtablet_yesbutton,"Yes button ");
			    KeywordImplementation.waitforpageloading();
			    KeywordImplementation.waitforpageloading();
			    KeywordImplementation.getnativedriver();
				 KeywordImplementation.Click("xpath","//*[@label='Sign On']","Sign On link is clicked after signing off");
				 KeywordImplementation.waitforpageloading();
				 KeywordImplementation.VerifyElement("xpath","//*[@label='Online Security Guarantee']", "Sign Off Page");
				 KeywordImplementation.waitforpageloading();

			}
			
			
			// ====================================================================================================
			// FunctionName : AndroidTablet
			// Description : LoginLogout
			// Date Created : 27/06/2016
			// Author : Kumar Prasun
			// ====================================================================================================
			public static void IM_TC_004() {

				 IM.IMlogin();
					KeywordImplementation.Click("xpath",AM_OR.androidmobile_moremenu,"More button");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.Click("xpath",AM_OR.androidmobile_transferandpaylink ,"Transfer and pay button");
					KeywordImplementation.waitforpageloading();
			
					KeywordImplementation.Click("xpath",AM_OR.androidmobile_surepaylink,"Sure pay Link");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.Click("xpath",AM_OR.androidmobile_surepaypage,"Sure Pay Page");
					KeywordImplementation.Click("xpath",AT_OR.androidtablet_SendMoneyAgreebutton,"Agree button");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.waitforpageloading();
				

					//Sign Off
					KeywordImplementation.Click("xpath",AM_OR.androidmobile_footersignofflink,"Signoff Link");
					KeywordImplementation.waitforpageloading();
					KeywordImplementation.Click("xpath",AM_OR.androidtablet_yesbutton,"Yes button ");
				    KeywordImplementation.waitforpageloading();
				    KeywordImplementation.waitforpageloading();
				    KeywordImplementation.getnativedriver();
					 KeywordImplementation.Click("xpath","//*[@label='Sign On']","Sign On link is clicked after signing off");
					 KeywordImplementation.waitforpageloading();
					 KeywordImplementation.VerifyElement("xpath","//*[@label='Online Security Guarantee']", "Sign Off Page");
					 KeywordImplementation.waitforpageloading();

			}
			
			
			// ====================================================================================================
			// FunctionName : iOSMobile
			// Description : LoginLogout
			// Date Created : 27/06/2016
			// Author : Kumar Prasun
			// ====================================================================================================
		public static void IM_TC_005() {
			
			IM.IMlogin();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AM_OR.androidmobile_footersignofflink,"Signoff Link");
			KeywordImplementation.waitforpageloading();
			KeywordImplementation.Click("xpath",AM_OR.androidtablet_yesbutton,"Yes button ");
		    KeywordImplementation.waitforpageloading();
		    KeywordImplementation.waitforpageloading();
		    KeywordImplementation.getnativedriver();
			 KeywordImplementation.Click("xpath","//*[@label='Sign On']","Sign On link is clicked after signing off");
			 KeywordImplementation.waitforpageloading();
			 KeywordImplementation.VerifyElement("xpath","//*[@label='Online Security Guarantee']", "Sign Off Page");
			 KeywordImplementation.waitforpageloading();
			 }

			
			// ====================================================================================================
						// FunctionName : AndroidTablet
						// Description : LoginLogout
						// Date Created : 27/06/2016
						// Author : Kumar Prasun
						// ====================================================================================================
						public static void IM_TC_006() {

							 IM.IMlogin();
								//Sign Off
								KeywordImplementation.Click("xpath",AM_OR.androidmobile_footersignofflink,"Signoff Link");
								KeywordImplementation.waitforpageloading();
								KeywordImplementation.Click("xpath",AM_OR.androidtablet_yesbutton,"Yes button ");
							    KeywordImplementation.waitforpageloading();
							    KeywordImplementation.waitforpageloading();
							    KeywordImplementation.getnativedriver();
								 KeywordImplementation.Click("xpath","//*[@label='Sign On']","Sign On link is clicked after signing off");
								 KeywordImplementation.waitforpageloading();
								 KeywordImplementation.VerifyElement("xpath","//*[@label='Online Security Guarantee']", "Sign Off Page");
								 KeywordImplementation.waitforpageloading();
								 
								 KeywordImplementation.waitforpageloading();
									KeywordImplementation.Click("xpath", "//*[@label='Online Username']","Username Field");
									KeywordImplementation.EnterUsernameiOS( CRAFT_DB.getData("Username"), "Username Field");
									KeywordImplementation.Click("xpath", "//*[@label='Online Password']","Password Field");
									KeywordImplementation.EnterPasswordiOS(CRAFT_DB.getData("Password"), "Password");
									KeywordImplementation.advanceClick("xpath", "//text[contains(text(),'Sign On')]","Sign On Button");
									KeywordImplementation.waitforpageloading();
									KeywordImplementation.waitforpageloading();
						
									KeywordImplementation.getdomdriver();
								 
								 
								 
									KeywordImplementation.Click("xpath",AM_OR.androidmobile_moremenu,"More button");
									KeywordImplementation.waitforpageloading();
									KeywordImplementation.Click("xpath",AM_OR.androidmobile_moremenusignofflink,"Signoff Link"); 
									KeywordImplementation.waitforpageloading();
									KeywordImplementation.waitforpageloading();
									KeywordImplementation.Click("xpath",AM_OR.androidtablet_yesbutton,"Yes button ");
								    KeywordImplementation.waitforpageloading();
								    KeywordImplementation.waitforpageloading();
								    KeywordImplementation.getnativedriver();
									 KeywordImplementation.Click("xpath","//*[@label='Sign On']","Sign On link is clicked after signing off");
									 KeywordImplementation.waitforpageloading();
									 KeywordImplementation.VerifyElement("xpath","//*[@label='Online Security Guarantee']", "Sign Off Page");
									 KeywordImplementation.waitforpageloading();
							
						}
						
						

						// ====================================================================================================
							// FunctionName : iOSMobile
							// Description : LoginLogout
							// Date Created : 27/06/2016
							// Author : Kumar Prasun
							// ====================================================================================================
						public static void IM_TC_007() {
							TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
							
							IM.IMlogin();
							KeywordImplementation.waitforpageloading();
							String strBrowser=testConfig.getBrowser();
							KeywordImplementation.Click("xpath","//*[text()='Online Security Guarantee']","Accounts and Settings Link");
							KeywordImplementation.waitforpageloading();
							KeywordImplementation.waitforpageloading();
							testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver("Safari").open();
							KeywordImplementation.waitforpageloading();
							KeywordImplementation.waitforpageloading();
							KeywordImplementation.getdomdriver();
							KeywordImplementation.VerifyElement("xpath","//h1[contains(text(),'Online Security Guarantee ')]", "Online Security Gurantee");
							testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver("Safari").close();
			                KeywordImplementation.waitforpageloading();
							testConfig.getPerfectodriver().getDevice(strBrowser).getNativeDriver("Wells fargo").open();
					        KeywordImplementation.waitforpageloading();
							KeywordImplementation.waitforpageloading();
						
							
							KeywordImplementation.Click("xpath",AM_OR.androidmobile_footersignofflink,"Signoff Link");
							KeywordImplementation.waitforpageloading();
							KeywordImplementation.Click("xpath",AM_OR.androidtablet_yesbutton,"Yes button ");
						    KeywordImplementation.waitforpageloading();
						    KeywordImplementation.waitforpageloading();
						    KeywordImplementation.waitforpageloading();
						    KeywordImplementation.waitforpageloading();
						    KeywordImplementation.getnativedriver();
							 KeywordImplementation.Click("xpath","//*[@label='Sign On']","Sign On link is clicked after signing off");
							 KeywordImplementation.waitforpageloading();
							 KeywordImplementation.VerifyElement("xpath","//*[@label='Online Security Guarantee']", "Sign Off Page");
							 KeywordImplementation.waitforpageloading();
							 }

						
						

			// ====================================================================================================
				// FunctionName : iOSMobile
				// Description : LoginLogout
				// Date Created : 27/06/2016
				// Author : Kumar Prasun
				// ====================================================================================================
			public static void IM_TC_008() {
				
				IM.IMlogin();
				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_moremenu,"More button");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_accountsummarylink,"Account Summary Link");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.VerifyElement("xpath", AM_OR.androidmobile_accountsummarypage, "Account Summary Page");
//				
//				KeywordImplementation.Click("xpath",AM_OR.androidmobile_footersignofflink,"Signoff Link");
//				KeywordImplementation.waitforpageloading();
//				KeywordImplementation.Click("xpath",AM_OR.androidtablet_yesbutton,"Yes button ");
//			    KeywordImplementation.waitforpageloading();
//			    KeywordImplementation.waitforpageloading();
//			    KeywordImplementation.getnativedriver();
//				 KeywordImplementation.Click("xpath","//*[@label='Sign On']","Sign On link is clicked after signing off");
//				 KeywordImplementation.waitforpageloading();
//				 KeywordImplementation.VerifyElement("xpath","//*[@label='Online Security Guarantee']", "Sign Off Page");
//				 KeywordImplementation.waitforpageloading();
				 }

			
			// ====================================================================================================
			// FunctionName : iOSMobile
			// Description : LoginLogout
			// Date Created : 27/06/2016
			// Author : Kumar Prasun
			// ====================================================================================================
		public static void IM_Appium_TC_001() {
			
			
			KeywordImplementation.StartApplication();
			
//		
//	  		driver1.findElement(By.xpath(APPIUM_OR.accountsettingslinkios)).click();
////	  		driver1.context("WEBVIEW_");
//	  		try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
//	  		
//	  		
//	  		//code to click on accounr services link
//	  		WebElement obj=driver1.findElement(By.xpath(APPIUM_OR.accountserviceslinkios));
//	  		
//	  		if (obj.isDisplayed()){
//				//Select the object
//				Point point = obj.getLocation();
//				Dimension size=obj.getSize();
//				int tapX = point.getX()+(size.getWidth()/2);
//				
//				int tapY = point.getY()+(size.getHeight()/2);
//				// Execute tap
//				String originalContext = driver1.getContext();
//				driver1.context("NATIVE_APP");
//				TouchAction action = new TouchAction(driver1);
//				//StringBuilder descBuillder = new StringBuilder();
//				//descBuillder.append(objName);
//				//descBuillder.append(" is Clicked.");
//				//stepsStatus.setDesc(descBuillder.toString());
//				action.tap(tapX, tapY).perform();
//				//stepsStatus.setStatus(ICommonConstants.PASS);
//				System.out.println("Pass:  " +"The element is  clicked");
//				//descBuillder.append(objName);
//				//descBuillder.append(" is Clicked.");
//				//stepsStatus.setDesc(descBuillder.toString());
//				driver1.context(originalContext);
//				
//	  		}
//	  		
////	  		Set <String> contextNames=driver1.getContextHandles();
////
////
////			Iterator<String> contextIterator=contextNames.iterator();
////			while(contextIterator.hasNext()){
////				String contextName = contextIterator.next().toString();
////				System.out.println(contextName);
////				if (contextName.contains("WEBVIEW_")|| contextName.contains("WEBVIEW_com") )
////				{
////					driver1.context(contextName);
////					System.out.println("The context is changed to" +contextName);
////					
////
////				}
////
////			}
//	  		
//	  		try {
//	  			//driver1.findElement(By.xpath(APPIUM_OR.accountserviceslinkios)).click();
//	  			} 
//	  		catch (Exception e) 
//	  		{
//	  			e.printStackTrace();
//	  			}
//	  		
//	  		try {Thread.sleep(20000);
//	  		
//	  	boolean a=driver1.findElement(By.xpath(APPIUM_OR.accountservicespageios)).isDisplayed();
//	  		
//	  		} catch (InterruptedException e) {e.printStackTrace();}  		
//	  		
//	  	
////			KeywordImplementation.waitforpageloading();
////			KeywordImplementation.appiumClick("xpath", "//UIAStaticText[@name='Privacy']","Privacy");
////			KeywordImplementation.waitforpageloading();
//		//	driver.findElement(By.name("Privacy")).click();
//			//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAStaticText[1]
//			 }
//
//
//
//
//	
//	
	
	}
}


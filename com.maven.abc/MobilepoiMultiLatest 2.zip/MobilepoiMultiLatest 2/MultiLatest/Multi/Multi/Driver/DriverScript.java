package Driver;




import java.io.*;

import commonMethods.CommonMethodsInPOI;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import javax.sql.rowset.CachedRowSet;

import SeleniumHelper.SeleniumHelper;
import SupportLibraries.CRAFT_DB;
import SupportLibraries.CRAFT_Report;
import SupportLibraries.CRAFT_Report.Status;
import SupportLibraries.GlobalVariables;
import SupportLibraries.KeywordImplementation;
import SupportLibraries.Reflection;
import SupportLibraries.Settings;
import SupportLibraries.TestConfigurations;
import SupportLibraries.Util;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

/**
 * Description   : Functional Test Scriptp
 * @author 163497, 163392
 */
public class DriverScript extends SeleniumHelper implements Runnable 
{
	/**
	 * Script Name   : <b>DriverScript</b>
	 * Generated     : <b>Mar 6, 2009 2:55:47 PM</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 5.1  Build 2600 (S)
	 * 
	 * @since  2009/03/06
	 * @author 163497, 163392
	 */
	//public static int iteration =0;
	//public static int subiteration = 1;
	
	//public static String testcaseID="";
	//public static String desc = null;
	//public static boolean error = false;
	public String key;
	public DriverScript(String key)
	{
		this.key=key;

	}
	public void testMain(Object[] args) 
	{
		//To run a TestCase directly, give Scenario, test case, description, iteration start, and iteration end.
		//		String Scenario = "Scenario3";
		//		testcase = "SEL_TC1";
		//		desc ="desc";
		//		int start = 1;
		//		int end =1;
		//		
		//		String path = Util.homePath;
		//		String dbpath =path+"\\Datatables\\"+Scenario+".xls";
		//		String timestamp = "Run_"+Util.getCurrentDatenTime("dd-MM-yy")+"_"+Util.getCurrentDatenTime("H-mm-ss a");
		//		String resultPath = path+"\\Results\\"+timestamp;
		//		String ExcelResPath = resultPath+"\\Excel Results";
		//		String HtmlResPath = resultPath+"\\HTML Results";
		//		String ScreenshotsPath = resultPath+"\\Screenshots";
		//		
		//		try 
		//		{        
		//			new File(ExcelResPath).mkdirs();
		//			new File(HtmlResPath).mkdirs();
		//		}
		//		catch (Exception ex){}
		//		
		//		CRAFT_Report.createTestcaseHeader(HtmlResPath+"\\"+testcase+".html", ExcelResPath+"\\"+testcase+".xls",ScreenshotsPath);
		//		executeTestCase(dbpath,start,end);
		//		CRAFT_Report.closeTestcaseReport();
		//		  
		//		try
		//		{
		//			String src =path+"_logs\\Driver.DriverScript";
		//			//System.out.println(src);
		//		    //Util.copyDirectory(src, dest);
		//		}
		//		catch (Exception e1)
		//	    {
		//		}
	}
	public static void setParam(String TestCase,String TestCaseID,String desc)
	{
		//DriverScript.testcase = TestCase;
		//DriverScript.testcaseID = TestCaseID;
		//DriverScript.desc =desc;
	}

	public void executeTestCase(String dbpath,int startIteration,int endIteration)
	{
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		//error = false;
		testConfig.setError(false);
		ArrayList<String> bc = new ArrayList<String>();
		String onError = Util.getValue("OnError", "NextIteration");
		String bsf = Util.getValue("BusinessFlowSheet","BusinessFlow");
		String testDataSheet =Util.getValue("TestDataSheet", "TestData");

		String testcase=testConfig.getCurrentTestCase();
		String parameterizedCheckPt =null;
	

		try
		{
			//String bsfRow[] = new String[20];
			ArrayList<String> bsfRow = new ArrayList<String>();
			FileInputStream file = new FileInputStream(new File(dbpath));
			HSSFWorkbook workbookDatatable = new HSSFWorkbook(file);
		 
			HSSFSheet bussinesssFlowsheet = workbookDatatable.getSheet(bsf);
			
			int rowCount = bussinesssFlowsheet.getLastRowNum();
			Iterator<Row> rowIterator = bussinesssFlowsheet.iterator();
			String scenario = null;
			int t = 0;
			
			while(t<=rowCount)
			{
				CommonMethodsInPOI a = new CommonMethodsInPOI();
				int columnindex = a.getIndex(bussinesssFlowsheet, "TC_ID");
				String tcID = bussinesssFlowsheet.getRow(t).getCell(columnindex).getStringCellValue();
				if(tcID.equals(testcase))
				{
					Row row = bussinesssFlowsheet.getRow(t);
					Iterator<Cell> cellIterator = row.cellIterator();
					int i =0;
					while(cellIterator.hasNext())
					{ 	
						Cell cell = cellIterator.next();
						System.out.println(cell.getStringCellValue());
						if(cell.getStringCellValue().length()!=0)
						{
							bsfRow.add(cell.getStringCellValue());
							System.out.println(bsfRow.get(i));
							i++;
						}
					}
				}
				t++;
			}
			int col = bsfRow.size();
			for(int i = 0;i<col;i++)
			{
				System.out.println("val : "+bsfRow.get(i));
			}
		/*try
		{
			rs2.next();
			int colcount=rs2.getMetaData().getColumnCount();
			String[] classnmethod = new String[colcount];
			System.out.println("column "+colcount);*/
			
			String[] classnmethod = new String[col];
			int p,q;
			for(p=1,q=0;p<col;p++,q++)
			{
				/*if(rs2.getString(p)==null)
					break;*/
				if(bsfRow.get(p)==null)
					break;
				classnmethod[q]= bsfRow.get(p);
				System.out.println(classnmethod[q]);
			}
			
			//no change blow
			col= q;
			for (int j =startIteration;j<=endIteration;j++)
			{
				if (testConfig.getError()||testConfig.isCraftReportError())
				{
					//error = false;
					testConfig.setError(false);
					testConfig.setCraftReportError(false);
					break;
				}
				//iteration = j;
				testConfig.setCurrentIteration(j);


				CRAFT_Report.insertIteration(j);
				for (int i=0;i<col;i++)
				{
					//if (error||CRAFT_Report.error)
					if (testConfig.getError()||testConfig.isCraftReportError())
					{
						if (onError.equals("nextIteration"))
						{
							//error = false;
							testConfig.setError(false);
							testConfig.setCraftReportError(false);
						}
						break;
					}
					String[] clnm = classnmethod[i].split(",");
					int iterno = 1;
					if (clnm.length>1)
					{
						iterno = Integer.valueOf(clnm[1]);
					}
					
					//no change below
					bc.add(clnm[0]);
					if (iterno!=0)
					{
						for (int l=1;l<iterno+1;l++)
						{
							if (testConfig.getError()||testConfig.isCraftReportError())
							{
								break;
							}
							for (int k = 0;k<bc.size();k++ )
							{
								if (testConfig.getError()||testConfig.isCraftReportError())
								{
									break;
								}
								//CRAFT_DB.setParameters(testcase, j, testdatasheet,l,parameterizedcheckpt);
								//CRAFT_DB.setParameters(testConfig.getCurrentTestCase(), j, testdatasheet,l,parameterizedcheckpt);
								//subiteration = l+1;
								testConfig.setCraftDbIterationNo(j);
								testConfig.setCraftDbsubIteration(l);
								testConfig.setDriverScripTestDataSheet(testDataSheet);
								testConfig.setDriverScriptParameterizedCheckPt(parameterizedCheckPt);
								testConfig.setCraftDbPSheet(parameterizedCheckPt);
								testConfig.setDriverScriptsubIteration(l+1);
								CRAFT_Report.LogInfo("Start Component","Invoking Business component: "+bc.get(k),Status.DONE);

								GlobalVariables.setCurrentIteration(testConfig.getCurrentIteration());

								try
								{
									String str;
									str = bc.get(k);
									String[] temp;
									String delimiter = ":";
									if (str.toUpperCase().indexOf(delimiter.toUpperCase()) != -1)
									{
										temp = str.split(delimiter);
										//Reflection.execute("BusinessComponents."+temp[0],temp[1]);
										
										Reflection.execute("BusinessComponents."+temp[0].trim(),temp[1].trim());
									}
									else 
									{
										Reflection.execute("BusinessComponents."+ bc.get(k),"ExecuteComponent");
									}

								}

								catch (Exception ex)
								{
									ex.printStackTrace();
									//error = true;
									testConfig.setError(true);
									CRAFT_Report.LogInfo("Unhandled Exception occured while exectuing "+ bc.get(k),ex.toString(),Status.FAIL);
								}
								if (!testConfig.getError()&&!testConfig.isCraftReportError())
								{
									CRAFT_Report.LogInfo("End Component","Exiting Business component: "+bc.get(k),Status.DONE);
								}
								else
								{
									reportError(onError);
								}
							}
						}	
						bc.clear();
					}
				}
				String Executionmode=Util.getValue("ExecutionMode", "Perfecto");
				if(Executionmode.trim().toUpperCase().equals("PERFECTO"))
				{
				KeywordImplementation.StopApplication();
				}else if(Executionmode.trim().toUpperCase().equals("APPIUM"));{
					KeywordImplementation.StopappiumApplication();
				}
			}

		}
		catch (Exception ee)
		{
			ee.printStackTrace();
		}
	}
	private void reportError(String onError)
	{
		if (onError.equals("nextIteration"))
		{
			CRAFT_Report.LogInfo("Error found", "Moving to next Iteration", Status.DONE);
		}
		else if (onError.equals("nextTestCase"))
		{
			CRAFT_Report.LogInfo("Error found", "Moving to next TestCase", Status.DONE);
		}
		else if (onError.equals("stop"))
		{
			CRAFT_Report.LogInfo("Error found", "Stopping the execution", Status.DONE);
			CRAFT_Report.closeTestcaseReportandUpdateSummary();
			CRAFT_Report.closeSummary();
			//selenium.stop();
		}
	}
	@Override
	public void run()
	{
		Properties properties = null;
		properties = Settings.getInstance();
		Thread.currentThread().setName(this.key);
		TestConfigurations testConfig= GlobalVariables.getConfigMap().get(Thread.currentThread().getName());
		CRAFT_Report.createTestcaseHeader(testConfig.getHtmlTestCaseResultFile(), testConfig.getExcelTestCaseResultFile(),testConfig.getScreenshotsPath());
		this.executeTestCase(testConfig.getDbDatatablePath(), testConfig.getStartIteration(), testConfig.getEndIteration());
		CRAFT_Report.closeTestcaseReportandUpdateSummary();
		if(Util.getValue("ExecutionMode", "Perfecto").trim().toUpperCase().equals("PERFECTO")){
		SeleniumHelper.downloadAddtionalReport();
		}
		SeleniumHelper.consolidateScreenshotsInWordDoc();
		SeleniumHelper.consolidateScreenshotsInPDF(true);
		//SeleniumHelper.CloseDriver();
		System.out.println("Summary Closed");
	}
}


package commonMethods;

import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import SupportLibraries.GlobalVariables;

public class CommonMethodsInPOI {

	public int getDistinctRowCount(HSSFSheet sheet, String colName, String testcaseID)
	{
		int iterationCount = 0;
		int index = getIndex(sheet, colName);
		Iterator<Row> rowIterator = sheet.iterator();
		while(rowIterator.hasNext())
		{
			Row row = rowIterator.next();
			System.out.println(row.getCell(index).getStringCellValue());
			if((row.getCell(index).getStringCellValue()).equals(testcaseID))
			{
				iterationCount++;
			}
		}
		return iterationCount;
	}

	//get index
	
	public int getIndex(HSSFSheet sheet,String value)
	{
		Iterator<Row> rowIterator = sheet.iterator();
		int index =0;
		mainloop : while(rowIterator.hasNext())
		{
			int count = 0;
			Row row = rowIterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			while(cellIterator.hasNext())
			{
				Cell cell = cellIterator.next();
				count++;
				String cellValue = cell.getStringCellValue().toLowerCase();
				if(cell.getStringCellValue().equalsIgnoreCase(value))
				{
					index = count-1;
					break mainloop;
				}
			}
		}
		return index;
		
	}
	
	public String getCellValue(String testcaseID, String colName, HSSFSheet sheet,int iteration)
	{
		
		int TC_IDindex = getIndex(sheet, "TC_ID");
		int iterationIndex = getIndex(sheet, "Iteration");
		int colindex = getIndex(sheet, colName);
		String value = null;
		Iterator<Row> rowIterator = sheet.iterator();
		int iterationcount =0;
		mainloop : while(rowIterator.hasNext())
		{
			/*if(GlobalVariables.getEndIteration()>1)
			{
				Row row = rowIterator.next();
				if(row.getCell(TC_IDindex).getStringCellValue().equals(testcaseID) && row.getCell(iterationIndex).getStringCellValue().equals(iteration))
				{
					value = row.getCell(colindex).getStringCellValue();
						
				}
			}
			else
			{*/
				Row row = rowIterator.next();
				if(row.getCell(TC_IDindex).getStringCellValue().equals(testcaseID))
				{
					int ItrIndex = (int)Float.parseFloat(row.getCell(iterationIndex).getStringCellValue());
					if(ItrIndex==iteration)
					{
						value = row.getCell(colindex).getStringCellValue();
						break mainloop;
					}
				}
//			}
		}
		return value;
	}
}
